<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
 <HEAD>
  <TITLE> jquery 공부 </TITLE>
  <META NAME="Generator" CONTENT="EditPlus">
  <META NAME="Author" CONTENT="">
  <META NAME="Keywords" CONTENT="">
  <META NAME="Description" CONTENT="">

<SCRIPT type="text/javascript" src="jquery-1.4.2.min.js"></script> 




	<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css"/>

	<script type="text/javascript" src="jquery.autocomplete.js"></script>
	<script> 
var goods = ["전동규","제부도소년","jaweb","삼성","현대","대우","쌍용","기아","아우디","벤츠","벤즈","푸조","폭스바겐","폴크스바겐","부가티","캐딜락","케딜락","씨보레","시보레","크라이슬러","닷지","페라리","혼다","재규어","지프","마세라티","짚","포드","로터스","로투스","마쯔다","미쯔비시","사브","도요타","도요다","포르쉐","포르셰","르노","볼보","지엠","쥐엠","롤스로이스","랜드로버","랜드로바","렌드로버","렌드로바","sm5dream","KIAMOTORS","HYUNDAI","GMDAEWOO","SSANGYONG","AUDI","BENZ","BMW","BUGATTI","CADILLAC","CHEVROLET","CHRYSLER","CITROEN","DODGE","FERRARI","FORD","FIAT","G.M","HONDA","JAGUAR","JEEP","LOTUS","MASERATI","MAZDA","MITSUBISHI","NISSAN","OPEL","PEUGEOT","PORSCHE","RENAULT","ROLLS-ROYCE","LANDROVER","SAAB","TOYOTA","VOLVO","VW","BERTONE","DWTC","GHIA","IDEA","ITAL-DESIGN","PININ-FARINA","ZAGATO","AUBURN","CORD","DUESENBERG","HUDSON","KAISER","LEVASSOR","NASH","PACKARD","STUDEBAKER","DELPHI","VISTEON"];
</script>	<script type="text/javascript">
		$(document).ready(function() {
			$("#search").autocomplete(goods,{
				matchContains: true
			});
			
			/*
			$("#search").autocomplete("data_php.php",{
				minChars: 0,
				width: 310,
				formatItem: function(row, i, max) {
					return i + "/" + max + ": \"" + row.name + "\" [" + row.to + "]";
				},
				formatMatch: function(row, i, max) {
					return row.name + " " + row.to;
				},
				formatResult: function(row) {
					return row.to;
				}
			});
			*/
		});
	</script>
 </HEAD>
 <BODY>
	<input type="text" id="search" autocomplete="off">
 </BODY>
</HTML>
