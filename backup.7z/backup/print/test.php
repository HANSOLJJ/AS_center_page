<?
include "../@config.php";
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 관리자 로그인</title>
<link rel='stylesheet' href='../<? echo("$css");?>' type=text/css>
</head>

<p align='left'><img src='logo1.jpg' width='100'></p>
<table border="0" width="100%" >
    <tr>
        <td width="50%" valign="top">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td colspan="3" width="100%" height='50'>
                        <p align='center'><font size='4'><b>A/S 접수 및 처리 내역서</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="10%" rowspan="4"><p align='center'><b>공<br>급<br>자</b></p></td>
                    <td width="45%" height='30'><p align='center'><b>상호</b></p></td>
                    <td width="45%"><p align='center'>(주)디지탈컴</p></td>
                </tr>
                <tr>
                    <td width="45%"  height='30'><p align='center'><b>사업자등록번호</b></p></td>
                    <td width="45%"><p align='center'>116-81-75974</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>처리지점</b></p></td>
                    <td width="45%"><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>A/S 처리기사</b></p></td>
                    <td width="45%"><p align='center'>&nbsp;</p></td>
                </tr>
            </table>
        </td>
        <td width="50%" valign="top">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td colspan="2" width="50%" height='30'>
                        <p align='center'><b>접수번호</b></p>
                    </td>
                    <td width="50%"><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td colspan="2" width="50%" height='30'><p align='center'><b>일자</b></p></td>
                    <td width="50%"><p align='center'>년 월 일</p></td>
                </tr>
                <tr>
                    <td width="10%"  rowspan="4"><p align='center'><b>접수신청</b></p></td>
                    <td width="45%" height='30'><p align='center'><b>상호</b></p></td>
                    <td width="45%"><p align='center'>귀하</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>연락처</b></p></td>
                    <td width="45%"><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>세금계산서발행</b></p></td>
                    <td width="45%">
                        <p align='center'>□유 □무</p>
                    </td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>사업자등록번호</b></p></td>
                    <td width="45%"><p align='center'>&nbsp;</p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
		
			 <table border="0" width="100%" height='30'>
				<tr>
					<td>
					<p align='left'><font size='3'><b>1.접수내용</b></font></p>
					</td>
				</tr>
			</table>
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="20%" height='30'><p align='center'><b>No.</b></p></td>
                    <td width="20%" height='30'><p align='center'><b>모델명</b></p></td>
                    <td width="20%" height='30'><p align='center'><b>수량</b></p></td>
                    <td width="20%" height='30'><p align='center'><b>증상</b></p></td>
                    <td width="20%" height='30'><p align='center'><b>기타</b></p></td>
                </tr>
                <tr>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                    <td height='30'><p align='center'>&nbsp;</p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
			<table border="0" width="100%" height='30'>
				<tr>
					<td>
					<p align='left'><font size='3'><b>2.A/S 내역 및 비용</b></font></p>
					</td>
				</tr>
			</table>
           <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="20%" rowspan="2"  height='30'><p align='center'><b>No.</b></p></td>
                    <td width="20%" rowspan="2"  height='30'><p align='center'><b>A/S 처리내용</b></p></td>
                    <td width="20%" colspan="2" height='15'><p align='center'><b>소모품신청</b></p></td>
                    <td width="20%" rowspan="2"  height='30'><p align='center'><b>금액</b></p></td>
                    <td width="20%" rowspan="2"  height='30'><p align='center'><b>비고</b></p></td>
                </tr>
                <tr>
                    <td  height="15"><p align='center'><b>품목</b></p></td>
                    <td  height="15"><p align='center'><b>수량</b></p></td>
                </tr>
                <tr>
                     <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                   <td height='30' ><p align='center'>&nbsp;</p></td>
					<td  height='30'><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                   <td height='30' ><p align='center'>&nbsp;</p></td>
					<td  height='30'><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                     <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                   <td height='30' ><p align='center'>&nbsp;</p></td>
					<td  height='30'><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                   <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                   <td height='30' ><p align='center'>&nbsp;</p></td>
					<td  height='30'><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td height='30' ><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                    <td  height='30'><p align='center'>&nbsp;</p></td>
                   <td height='30' ><p align='center'>&nbsp;</p></td>
					<td  height='30'><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td height='30' colspan="4"><p align='center'><b>합계</b></p></td>
                    <td height='30' colspan="2"><p align='center'>\</p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="25%" height='30'><p align='center'><b>입금계좌번호</b></p></td>
                    <td colspan="3" width="75%"><p align='center'><b>신한 140-005-221339 (주)디지탈컴 정용호</b></p></td>
                </tr>
                <tr>
                    <td width="25%" height='30'><p align='center'><b>대금지급</b></p></td>
                    <td width="25%"><p align='center'><b>현금, 무통장 입금</b></p></td>
                    <td width="25%"><p align='center'><b>입금일자</b></p></td>
                    <td width="25%"><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td height='30'><p align='center'><b>발송일</b></p></td>
                    <td><p align='center'>&nbsp;</p></td>
                    <td ><p align='center'><b>택배운송번호</b></p></td>
                    <td><p align='center'>&nbsp;</p></td>
                </tr>
                <tr>
                    <td  height='30'><p align='center'><b>A/S 처리완료일</b></p></td>
                    <td><p align='center'>&nbsp;</p></td>
                    <td ><p align='center'><b>본사입금확인</b></p></td>
                    <td><p align='center'>&nbsp;</p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="100%" colspan="3" height='30'><p align='center'><b>디지탈컴 A/S 센터</b></p></td>
                </tr>
                <tr>
                    <td width="15%" height='30'><p align='center'><b>지점</b></p></td>
                    <td width="60%"><p align='center'><b>주소</b></p></td>
                    <td width="25%" ><p align='center'><b>전화번호</b></p></td>
                </tr>
                <tr>
                    <td  height='30'><p align='center'><b>영등포</b></p></td>
                    <td><p align='left'>서울 영등포구 당산동 2가 30-2 영등포 유통상가 3층 가열 9~10호</p></td>
                    <td><p align='center'>02-2671-9193</p></td>
                </tr>
                <tr>
                    <td height='30' ><p align='center'><b>을지로</b></p></td>
                    <td ><p align='left'>서울 중구 신림동 207-2 대림상가 라열 337호</p></td>
                    <td ><p align='center'>02-2275-9193</p></td>
                </tr>
                <tr>
                    <td  height='30'><p align='center'><b>본사</b></p></td>
                    <td><p align='left'>경기도 부천시 오정구 삼정동 36-1 부천테크노쌍용3차 303동 803호</p></td>
                    <td><p align='center'>032-624-1996</p></td>
                </tr>
                <tr>
                    <td width="75%"  colspan="2" height='30'><p align='center'><b>기술상담문의</b></p></td>
                    <td width="25%" height="0"><p align='center'>1577-9193</p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">※ A/S 택배 접수시 불량증상을 적어서 보내주시면 더욱 신속하게 처리됩니다.</td>
    </tr>
    <tr>
        <td colspan="2">※테두리가 진하게 표시된 네모박스안에 반드시 명기해 주세요.</td>
    </tr>
</table>
<p>&nbsp;</p>
