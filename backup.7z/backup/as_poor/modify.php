<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s16_apid, s16_poor FROM $db16 WHERE s16_apid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s16_apid = $row->s16_apid;
$my_s16_poor = $row->s16_poor;


##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {
	
	if(!form.s16_poor.value) {
      alert('불량 증상을 입력하세요!');
      form.s16_poor.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>


<!------------------------- 이름  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>불량 증상</b>
			</td>
			<td width='70%'>
			<input type="text" name="s16_poor" size="64" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_s16_poor");?>'>
			</td>
		</tr>


</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>