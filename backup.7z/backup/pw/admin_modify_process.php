<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$id = $HTTP_SESSION_VARS["member_id"];

##### 로그인하기 위해 입력한 아이디와 비밀번호가 일치하는 레코드를 검색한다.
$result = mysql_query("SELECT passwd, userlevel FROM 2010_admin_member WHERE id = '$id'");
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$rows = mysql_num_rows($result);

##### 일치하는 회원정보가 없을 경우
if (!$rows) {
   error("LOGIN_ID_NOT_FOUND");
   exit;
} else {

##### 회원정보가 있을 경우 비밀번호 필드값을 가져온다.
$row = mysql_fetch_object($result);

$db_passwd = $row->passwd;
$db_userlevel = $row->userlevel;
   
##### 사용자가 입력한 비밀번호를 암호화한다.
$result = mysql_query("SELECT password('$pre_passwd')");
$user_passwd = mysql_result($result,0,0);
 
##### 두 비밀번호를 비교하여 일치하면 세션을 생성한다.

if(strcmp($db_passwd,$user_passwd)) {     

  error("LOGIN_INVALID_PW");
  exit;
} else {




   ##### 사용자가 입력양식에 입력한대로 회원정보를 갱신한다.
   $query  = "UPDATE 2010_admin_member SET passwd = password('$passwd') WHERE id = '$id'";
   $result = mysql_query($query);
   if(!$result) {
      error("QUERY_ERROR");
      exit;
   }
   
  
   ##### 회원정보가 정상적으로 변경되었음을 알리는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php'>");

}

}
?>
