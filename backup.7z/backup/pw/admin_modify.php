<script language="javascript">
   <!--
   function checkInput (form) {
      	 	  
	  if (!form.pre_passwd.value) {
         alert("비밀번호를 입력하세요!");
         form.pre_passwd.focus();
         return;
      }

	   if (!form.passwd.value) {
         alert("비밀번호를 입력하세요!");
         form.passwd.focus();
         return;
      }

      if(!IsPW(form.passwd.name)) {
         alert("비밀번호는 4 ~ 8자의 영문자나 숫자 또는 조합된 문자열이어야 합니다!");
         form.passwd.focus();
         form.passwd.select();
         return;
      }    

      if (form.passwd.value != form.repasswd.value) {
         alert("입력하신 비밀번호가 일치하지 않습니다.\n다시 확인하시고 입력하여 주십시오.");
         form.repasswd.focus();
         form.repasswd.select();
         return;
      }



		form.submit();
   }

   function IsPW(formname) {
      var form = eval("document.signform." + formname);
      
      if(form.value.length < 4 || form.value.length > 8) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z') && (chr < 'A' || chr > 'Z')) {
            return false;
         }
      }
      return true;   
   }
    
	  //-->
   </script>



<form name="signform" method="post" action="admin_modify_process.php">
<br><br>
<table width='95%'cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
<!------------------------- 비번  --------------------------->

					<tr>
						<td   width='30%' height='40'  bgcolor='#F2F8FB'>
						<p align='center'>기존 비밀번호</p>
						</td>
						<td width='70%' >
						&nbsp;&nbsp;<input type="password" name="pre_passwd" size="20" maxlength="12" style="border-width:1px; border-color:rgb(204,204,204); border-style:solid;">
						</td>
					</tr>
<!------------------------- 비번  --------------------------->

					<tr>
						<td  height='40'  bgcolor='#F2F8FB'>
						<p align='center'>새 비밀번호</p>
						</td>
						<td >
						&nbsp;&nbsp;<input type="password" name="passwd" size="20" maxlength="12" style="border-width:1px; border-color:rgb(204,204,204); border-style:solid;"><font color="red">(최대 8자)</font>&nbsp;&nbsp;비밀번호 확인<input type="password" name="repasswd" size="20" maxlength="8" style="border-width:1px; border-color:rgb(204,204,204); border-style:solid;">
						</td>
					</tr>

<!-------------------------  --------------------------->
				</table>
					<p align='center'><input type="button" value="비밀 번호 수정" onClick="checkInput(this.form)">&nbsp; <input type="reset" value="다시 입력"></p>		


						</form>	



				
