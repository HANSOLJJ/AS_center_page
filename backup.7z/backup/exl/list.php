<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>


<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<?
$title_front = "<table width='95%' border='0' align='center' height='30'><tr><td style='border-bottom-width:2px; border-bottom-color:rgb(233,233,233); border-bottom-style:solid;'><p align='left'><SPAN class='admin_title_big'>■ ";
$title_end = "</span></p></td></tr></table><br>";

$title_b = $title_front ."엑셀파일출력  ". $title_end;

echo"$title_b"; 

switch ($in_code) {

// 일반페이지


case ("") : 	include"list_view.php"; Break;
case ("list_view") : 	include"list_view.php"; Break;
case ("list_view2") : 	include"list_view2.php"; Break;
case ("exl_1") : 	include"exl_1.php"; Break;
case ("exl_2") : 	include"exl_2.php"; Break;
case ("exl_3") : 	include"exl_3.php"; Break;
case ("exl_4") : 	include"exl_4.php"; Break;
case ("exl_5") : 	include"exl_5.php"; Break;
case ("exl_10") : 	include"exl_10.php"; Break;
case ("exl_100") : 	include"exl_100.php"; Break;
}

?>
