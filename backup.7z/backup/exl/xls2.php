<?php
$title = $s_year."년".$s_month."월AS처리현황";

header( "Content-type: application/vnd.ms-excel; charset=utf-8" ); 
header("Content-Disposition: attachment; filename=".$title.".xls");
 header( "Content-Description: PHP4 Generated Data" ); 
 print("<meta http-equiv=\"Content-Type\" content=\"application/vnd.ms-excel; charset=utf-8\">"); 

?>

<html>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=enc-kr">
</head>
<body>
<? echo"$title<br>";?>
<table border="1">
	<tr>
		<td>
		<p align="center">담 당</p>		
		</td>
		<td>
		<p align="center">검 토</p>		
		</td>
		<td>
		<p align="center">승 인</p>		
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
</table>
<? echo"1.$s_year년 $s_month월 AS소모품 판매 및 수리비<br>"; ?>
<table border="1">
	<tr>
        <td >
            <p align="center">No</p>
        </td>
        <td>
            <p align="center">분류</p>
        </td>
        <td>
            <p align="center">수리건수</p>
        </td>
		<td>
            <p align="center">수리비</p>
        </td>
        <td>
            <p align="center">소모품 판매</p>
        </td>
		<td>
            <p align="center">소모품 판매비</p>
        </td>
        <td>
            <p align="center">합계(수리비 + 소모품)</p>
        </td>
    </tr>
<?php
### DB 연결
$mysql_host = 'localhost';     // 호스트명 
$mysql_user = 'mic4u41';     // 사용자 계정 
$mysql_pwd  = 'digidigi';      // 비밀번호 
$mysql_db   = 'mic4u41';       // DB(데이터베이스)명) 
$connect = @mysql_connect($mysql_host, $mysql_user, $mysql_pwd) or die("서버 접속에 실패 했습니다. 계정 또는 패스워드를 확인하세요.");
@mysql_select_db($mysql_db, $connect) or die("DB 연결에 실패 했습니다. 데이터베이스명을 확인하세요.");


####날짜변환
$s_day="1";
$e_day="31";
$s_d = mktime(0,0,0,$s_month, $s_day, $s_year);
$e_d = mktime(0,0,0,$e_month, $e_day, $e_year);

#### 센터명
$query1 = "SELECT s2_cid, s2_center_id,  s2_center  FROM step2_center ORDER BY s2_cid DESC";
$result1= mysql_query($query1);

$no="0";
while($row1 = mysql_fetch_array($result1,MYSQL_ASSOC)) {

// 이부분에 데이터를 출력시킨다.

$no++;
$s1_1 = $row1[s2_cid];
$s2_1 = $row1[s2_center_id];
$s3_1 = $row1[s2_center];

//------------------as정보 (수리건수)
$query2 = mysql_query("Select count(*) FROM step13_as  WHERE s13_as_level LIKE '5' AND s13_as_center  = '$s2_1' AND s13_as_in_date BETWEEN '$s_d' AND '$e_d'");
$total_record2 = mysql_result($query2,0,0);
  
if($total_record2 ==""){$total_record2="0";}

$P_total_record2 =number_format($total_record2);
//------------------as정보 (수리비)
$query3 = mysql_query("Select SUM(ex_total_cost)  FROM step13_as  WHERE s13_as_level LIKE '5' AND s13_as_center  = '$s2_1' AND s13_as_in_date BETWEEN '$s_d' AND '$e_d'");
$total_record3 = mysql_result($query3,0,0);
   
if($total_record3 ==""){$total_record3="0";}

$P_total_record3 =number_format($total_record3);

//------------------as정보 (판매건수)
$query4 = mysql_query("Select count(*) FROM step20_sell  WHERE s20_as_level LIKE '2' AND s20_as_center = '$s2_1' AND s20_sell_in_date  BETWEEN '$s_d' AND '$e_d'");
$total_record4= mysql_result($query4,0,0);
   
if($total_record4 ==""){$total_record4="0";}

$P_total_record4 =number_format($total_record4);
//------------------as정보 (판매건수)
$query5 = mysql_query("Select SUM(s20_total_cost) FROM step20_sell  WHERE s20_as_level LIKE '2' AND s20_as_center = '$s2_1' AND s20_sell_in_date  BETWEEN '$s_d' AND '$e_d'");
$total_record5= mysql_result($query5,0,0);
   
if($total_record5 ==""){$total_record5="0";}

$P_total_record5 =number_format($total_record5);
//-----------------AS 합
$total_record6 = $total_record3 + $total_record5;

$P_total_record6 =number_format($total_record6);

print"<tr><td>$no</td><td>$s3_1</td><td>$P_total_record2</td><td>$P_total_record3</td><td>$P_total_record4</td><td>$P_total_record5</td><td>$P_total_record6</td></tr>";
$N_total_record2 = $N_total_record2 +$total_record2;
$N_total_record3 = $N_total_record3 +$total_record3;
$N_total_record4 = $N_total_record4 +$total_record4;
$N_total_record5 = $N_total_record5 +$total_record5;
$N_total_record6 = $N_total_record6 +$total_record6;
}

$N_total_record2 =number_format($N_total_record2);
$N_total_record3 =number_format($N_total_record3);
$N_total_record4 =number_format($N_total_record4);
$N_total_record5 =number_format($N_total_record5);
$N_total_record6 =number_format($N_total_record6);

$N_no = $no + 1;
print"<tr><td>$N_no</td><td>합계</td><td>$N_total_record2</td><td>$N_total_record3</td><td>$N_total_record4</td><td>$N_total_record5</td><td>$N_total_record6</td></tr>";
?>
</table>

<? echo"2.무상처리내역<br>"; ?>
<table border="1">
	<tr>
        <td >
            <p align="center">구분</p>
        </td>
        <td>
            <p align="center">분류</p>
        </td>
        <td>
            <p align="center">수리건수</p>
        </td>
		<td>
            <p align="center">수리비</p>
        </td>
        <td>
            <p align="center">소모품 판매</p>
        </td>
		<td>
            <p align="center">소모품 판매비</p>
        </td>
        <td>
            <p align="center">합계(수리비 + 소모품)</p>
        </td>
    </tr>
	<tr>
        <td colspan='7'>
            <p align="center">자세한 스펙이 필요합니다.(상의후 작업가능)</p>     
        </td>
    </tr>
</table>
</body>
</html>
