<?php
$title = "출고정보1";

header( "Content-type: application/vnd.ms-excel; charset=utf-8" ); 
header("Content-Disposition: attachment; filename=".$title.".xls");
 header( "Content-Description: PHP4 Generated Data" ); 
print("<meta http-equiv=\"Content-Type\" content=\"application/vnd.ms-excel; charset=utf-8\">"); 

?>

<html>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=enc-kr">
</head>
<body>
<table border=1>
<tr>
<td>No</td>
	<td>입고일</td>
	<td>수탁방법</td>
	<td>접수번호</td>
	<td>업체명</td>
	<td>형태</td>
<!------------------추가 컬럼시작-------------------->
<td>접수일</td>
<td>접수번호</td>

<td align='center'>제품명 | 처리내역 | 사용 부품 | 개수 | 가격</td>
<td>총 수리비</td>
<td>수리날짜</td>
<td>방문</td>
<td>입금방법</td>

<!------------------추가 컬럼끝-------------------->
	<td>주소</td>
	<td>연락처</td>
	<td>입금확인</td>
	<td>세금계산서발행</td>
	<td>택배</td>
</tr>

<?php
### DB 연결
$mysql_host = 'localhost';     // 호스트명 
$mysql_user = 'mic4u41';     // 사용자 계정 
$mysql_pwd  = 'digidigi';      // 비밀번호 
$mysql_db   = 'mic4u41';       // DB(데이터베이스)명) 
$connect = @mysql_connect($mysql_host, $mysql_user, $mysql_pwd) or die("서버 접속에 실패 했습니다. 계정 또는 패스워드를 확인하세요.");
@mysql_select_db($mysql_db, $connect) or die("DB 연결에 실패 했습니다. 데이터베이스명을 확인하세요.");

####날짜변환
$s_d = mktime(0,0,0,$s_month, $s_day, $s_year);
$e_d = mktime(0,0,0,$e_month, $e_day, $e_year);
###하루 더하기
$e_d = $e_d + 86400;

###
$query = "SELECT s13_asid, s13_as_in_date, s13_as_in_how, s13_as_in_no, ex_company, ex_sec1, ex_address, ex_tel, s13_bank_check, s13_tax_code, s13_dex_send_name, s13_dex_send, s13_bankcheck_w  FROM step13_as WHERE s13_as_level LIKE '5'  AND s13_as_center  = '$center' AND s13_as_out_date BETWEEN '$s_d' AND '$e_d' ORDER BY s13_asid DESC";
$result= mysql_query($query);

if (!$result) {
   error("등록된 데이터가 없습니다.");
   exit;
}
//------------------추가 컬럼코드 시작-------------------
$e3 = "0";
//------------------추가 컬럼코드 끝-------------------
while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

	// 이부분에 데이터를 출력시킨다.

$s1 = date("y-m-d",$row[s13_as_in_date]);
$s2 = $row[s13_as_in_how];
$s3 = $row[s13_as_in_no];
$s4 = $row[ex_company];
$s5 = $row[ex_sec1];
$s6 = $row[ex_address];
$s7 = $row[ex_tel];
$s8 = $row[s13_bank_check];
if($s8 ==""){$s8="미입금";}else{$s8=date("y-m-d",$s8);}
$s9 = $row[s13_tax_code];
if($s9 ==""){$s9="미발행";}else{$s9="발행";}
$s10 = $row[s13_dex_send_name];
$s11 = $row[s13_dex_send];
$s13 = $row[s13_bankcheck_w];

if($s13 =='center'){$s13 ="센터 현금납부";}else
if($s13 =='base'){$s13 ="계좌이체";}else
if($s13 ==''){$s13 ="3월 8일 이후  확인가능";}

if($s10 !=""){$s12 ="내방";}
$checked_code=$row[s13_asid];

if($s10==""){$s10 ="-";}else{$s10 = $s10."(".$s11.")";}

//------------------추가 컬럼시작-------------------

$e1= date("m월d일",$row[s13_as_in_date]);
$e2 = $s3;
$e3++;

//------------------추가 컬럼끝-------------------

print"<tr><td>$e3</td><td>$s1</td><td>$s2</td><td>$s3</td><td>$s4</td><td>$s5</td>";
//------------------추가 컬럼시작-------------------
print"<td>$e1</td><td>$e2</td><td>";

//include"test_set2_add_list2.php";
include"xls1_addon1.php";
print"</td><td>";
include"add_sum_total_cost.php";
print"</td><td>$s12</td><td>$s13</td>";
//------------------추가 컬럼끝-------------------
print"<td>$s6</td><td>$s7</td><td>$s8</td><td>$s9</td><td>$s10</td></tr>";


}?>



</table>
</body>
</html>
