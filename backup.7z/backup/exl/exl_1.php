<script language="javascript">
<!--
function sendit() {
	
	if(!form.s_year.value) {
      alert('출력 시작년도를 입력하세요!');
      form.s_year.focus();
      return;
   }

   if(!form.s_month.value) {
      alert('출력 시작월을 입력하세요!');
      form.s_month.focus();
      return;
   }

   if(!form.s_day.value) {
      alert('출력 시작일을 입력하세요!');
      form.s_day.focus();
      return;
   }

   if(!form.e_year.value) {
      alert('출력 종료년도를 입력하세요!');
      form.e_year.focus();
      return;
   }

   if(!form.e_month.value) {
      alert('출력 종료월을 입력하세요!');
      form.e_month.focus();
      return;
   }

   if(!form.e_day.value) {
      alert('출력 종료일을 입력하세요!');
      form.e_day.focus();
      return;
   }

    if(!form.center.value) {
      alert('출력 센터를 입력하세요!');
      form.center.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>

<?
##### 검색 날짜관련
$s_d = mktime(0,0,0,$s_month, $s_day, $s_year);
$e_d = mktime(0,0,0,$e_month, $e_day, $e_year);

$s_year = date("Y"); 
$s_month = date("m"); 
$s_day = date("d"); 
$e_year = date("Y"); 
$e_month = date("m"); 
$e_day = date("d"); 
?>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='xls1.php' enctype='multipart/form-data'>
<!------------------------- 업체명  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>출력기간</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
<?
$men_year = date("Y",time());	

$FIRST_DAY = "2010";		// 시작값
$LAST_DAY = $men_year;			// 마지막값
   echo "<select name='s_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
if($i == $s_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      
   }
   echo "</select> &nbsp;";

   echo "<select name='s_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $s_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}   
   }
   echo "</select> &nbsp;";

   echo "<select name='s_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $s_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>~
<?

$FIRST_DAY = "2010";		// 시작값
$LAST_DAY = $men_year;			// 마지막값
   echo "<select name='e_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
if($i == $e_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      
   }
   echo "</select> &nbsp;";

   echo "<select name='e_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $e_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}    
 
   }
   echo "</select> &nbsp;";

   echo "<select name='e_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $e_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>
&nbsp;<font color='red'><b>출고일 기준</b></font>
			</td>
		</tr>
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>출력 센터</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<select name="center">
			<option value=''>센터를 선택해 주세요.</option>

<?
##### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$result3= mysql_query("SELECT s2_cid, s2_center_id, s2_center FROM step2_center");

if (!$result3) {
   error("QUERY_ERROR");
   exit;
}

while($row3 = mysql_fetch_array($result3,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장한다.   

$my_s2_cid = $row3[s2_cid];
$my_s2_center_id = $row3[s2_center_id];
$my_s2_center = $row3[s2_center];

##### 

echo("<option value='$my_s2_center_id'>$my_s2_center</option>");

}
?>
							
			</select>

			</td>
		</tr>
</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_submit.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>





<p>&nbsp;</p>
<p>&nbsp;</p>