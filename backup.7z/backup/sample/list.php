<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>


<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<table align="center" border="0" cellspacing="0" width="100%">
    <tr>
		<td valign='top'>
<p><img src='sample.jpg'></p>
		</td>
	</tr>
</table>