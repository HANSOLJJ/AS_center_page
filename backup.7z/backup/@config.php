<?
// MySQL 호환성 레이어 로드 (PHP 7.4+)
require_once '@session_inc.php';

// session_start() is already called in @session_inc.php
$admin_email      = "digitalcoms@digitalcoms.net";  //  깅 
$admin_name      = " AS ";    // 
$home                 = "index.php";   //    

$web_title             = "  AS  ";   // 띠濡琉 명
$company            = "";   // 
$explain               = "у, , , ,  , 명 , 源, 源, ,  紐";  //  
$telephone1         = "032-624-1980";  //  1
$fax1					= "032-624-1985";  // 쇱 1


$css                    = "style.css"; //  
$img_dir             = "/../../_img";   // 밸 깅 
$icon_dir             = "/../../_icon";  //  깅 
$UPLOAD_folder  = "/../../_UPLOAD_FILEZ"; // 뱀듭몃몄  
$UPLOAD_folder_admin  = "/../../_UPLOAD_FILEZ"; // 뱀듭몃몄  


### DB 
// Docker 환경 변수 설정
$mysql_host = 'mysql';     // Docker 서비스명
$mysql_user = 'mic4u_user';      // Docker MySQL 사용자
$mysql_pwd  = 'change_me';      // Docker MySQL 비밀번호
$mysql_db   = 'mic4u';       // DB명
$connect = @mysql_connect($mysql_host, $mysql_user, $mysql_pwd) or die(" 몄  ⑹밸.  ㅻ 살뀀 뱀쎌.");
@mysql_select_db($mysql_db, $connect) or die("DB ⑥  ⑹밸. 띕깆 뱀쎌.");
@mysql_query("SET NAMES utf8mb4");
###


$DB_Admin_Member = "2010_admin_member"; //   DB
$DB_web_Member    = "2010_member";        //   DB

$db1 = 'step1_parts';
$db2 = 'step2_center';
$db3 = 'step3_member';
$db4 = 'step4_cart';
$db5 = 'step5_category';
$db6 = 'step6_order';
$db7 = 'step7_center_parts';
$db8 = 'step8_sendbox';
$db9 = 'step9_out';
$db10 = 'step10_tax';
$db11 = 'step11_member';
$db12 = 'step12_sms_sample';
$db13 = 'step13_as';
$db14 = 'step14_as_item';
$db15 = 'step15_as_model';
$db16 = 'step16_as_poor';
$db17 = 'step17_as_item_cure';
$db18 = 'step18_as_cure_cart';
$db19 = 'step19_as_result';
$db20 = 'step20_sell';
$db21 = 'step21_sell_cart';

$Form_style1   ="style='background-color:rgb(250,250,250);border-width:1px; border-color:rgb(158,200,222); border-style:solid;'";
$list_style1   ="style='border-bottom-width:1px; border-bottom-color:rgb(173,208,227); border-bottom-style:solid;'";
$list_style2   ="style='border-top-width:1px; border-bottom-width:1px; border-top-color:rgb(0,204,153); border-bottom-color:rgb(0,204,204); border-top-style:solid; border-bottom-style:solid;'";


$fontcolor1  = "#606060";
$fontcolor2  = "#0f70bb"; //  ▼ 듭
$bgcolor1    = "#FFFFFF";  //   
$bgcolor2    = "#E4F5F9";  //    
$bgcolor3    ="#e2f2ff";
$board_bgcolor2  = "bgcolor='#c2efed'";  //    
$board_bgcolor1  = "bgcolor='d2f2ff'";  //    

$border_bg1 = "../".$icon_dir."/board_blue_border01.gif";

$admin_border_color1 ="#ffd7a2";
$admin_border_color1_1 ="#fff0db";
$admin_border_color2 ="#9de1f9";
$admin_border_color2_1 ="#edfaff";


## 

$title_front = "<table width='95%' border='0' align='center' height='30'><tr><td style='border-bottom-width:2px; border-bottom-color:rgb(233,233,233); border-bottom-style:solid;'><p align='left'><SPAN class='admin_title_big'> ";
$title_end = "</span></p></td></tr></table><br>";

$title_b_1 = $title_front ."AS  ". $title_end;
$title_b_2 = $title_front ."AS   ". $title_end;
$title_b_3 = $title_front ."AS   ". $title_end;
$title_b_4 = $title_front ."AS  移닷怨ㅼ ". $title_end;
$title_b_5 = $title_front ."AS  泥". $title_end;
$title_b_6 = $title_front ."AS   ". $title_end;
$title_b_7 = $title_front ."AS   ". $title_end;
$title_b_8 = $title_front ."κ낀 ". $title_end;
$title_b_9 = $title_front ." ". $title_end;
$title_b_10 = $title_front ."SMS  ". $title_end;
$title_b_11 = $title_front ."AS ". $title_end;
$title_b_12 = $title_front ." ". $title_end;
$title_b_13 = $title_front ."琉  ". $title_end;
$title_b_14 = $title_front ."AS ". $title_end;

$title_b_21 = $title_front ."AS 怨ㅼ ". $title_end;
$title_b_22 = $title_front ."AS ". $title_end;
$title_b_23 = $title_front ."AS  ". $title_end;
$title_b_24 = $title_front ."AS   ". $title_end;
$title_b_25 = $title_front ."AS   ". $title_end;
$title_b_26 = $title_front ."AS    ". $title_end;
$title_b_27 = $title_front ."AS  怨ㅼ  ". $title_end;
$title_b_28 = $title_front ."湲  ". $title_end;

$title_b_29 = $title_front ."  ". $title_end;
$title_b_30 = $title_front ."AS  ㅻ ". $title_end;

$title_b_31= $title_front ."ㅻ 湲  ". $title_end;
