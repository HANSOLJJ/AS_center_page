<?
function popup_msg($msg)
{
   echo ("<script language=\"javascript\"> 
   <!--
   alert('$msg');
   history.back();
   //-->   
   </script>");
}

function error($errcode)
{
   switch ($errcode) {

      // 濡洹몄 대 

      case ("NOT_ALLOWED_ID"):
         popup_msg("ν 대 ⑸吏  臾몄댁.\\n\\n대 5 ~ 10 臾몄臾몄 レ  議고⑸ 臾몄댁댁댁 ⑸.");
         break;

      // 濡洹몄 ⑥ㅼ

      case ("NOT_ALLOWED_PASSWD"):
         popup_msg("ν 鍮諛踰몃 ⑸吏  臾몄댁.\\n\\n鍮諛踰몃 4 ~ 8 臾몄臾몄 レ  議고⑸ 臾몄댁댁댁 ⑸.");
         break;

      // 濡洹몄 대 臾

      case ("LOGIN_ID_NOT_FOUND"):
         popup_msg("ν 대(ID) 깅 吏 듬. \\n\\nㅼ踰 명怨 ν 二쇱.");
         break;

      // 濡洹몄 ⑥ㅼ 留ㅼ

      case ("LOGIN_INVALID_PW"):
         popup_msg(" ν 鍮諛踰멸 留吏 듬. \\n\\nㅼ踰 명怨 ν 二쇱.");
         break;

      // 濡洹몄 李⑤

      case ("LOGIN_ID_BREAK"):
         popup_msg(" 愿由ъ 댁  李⑤⑤듬.. \\n\\n愿由ъ寃 臾몄湲 諛.");
         break;

      // 濡洹몄 몄

      case ("HTTP_HEADERS_SENT"):
         popup_msg("濡洹몃 ㅻ媛 諛듬.\\n\\n愿由ъ寃 臾몄湲 諛.");
         break;

      // 媛 대

      case ("NOT_ALLOWED_NAME"):
         popup_msg("ν 대 ⑸吏  臾몄댁.\\n\\n대 諛 湲濡 怨듬갚 ν ⑸.");
         break;

      // 媛 대쇱 

      case ("NOT_ALLOWED_EMAIL"):
         popup_msg("ν 고몄＜ щ瑜 二쇱媛 . \\n\\nㅼ ν 二쇱.");
         break;

      // 媛 대 

      case ("NOT_ALLOWED_DUPLICATE_ID"):
         popup_msg("泥 대(ID) 대 깅 듬. \\n\\nㅻⅨ 대濡 泥 二쇱.");
         break;

      // 媛 대 鍮踰李얘린 

      case ("LOGIN_INVALID_NOMEACH"):
         popup_msg("대怨 대쇱 쇱 吏 듬. \\n\\n명 ㅼ ν 二쇱.");
         break;

      // 寃 湲 議댁  

      case ("NO_ACCESS_DELETE_THREAD"):
         popup_msg("듬湲 議댁ы⑸. \\n\\n듬湲 癒쇱 二쇱湲 諛.");
         break;

      // 곗댄踰댁 곌껐

      case ("ACCESS_DENIED_DB_CONNECTION"):
         popup_msg("곗댄곕댁 곌껐 ㅽ⑦듬.\\n\\n곌껐怨  踰紐怨 ъ⑹紐, 鍮諛踰몃 명湲 諛.");
         break;

      // 곗댄踰댁 곌껐

      case ("FAILED_TO_SELECT_DB"):
         popup_msg("吏 곗댄곕댁ㅻ  곗댄곕댁ㅻ   듬.\\n\\n吏 곗댄곕댁ㅻ 명湲 諛.");
         break;

      case ("NOT_ALLOWED_MODE"):
         popup_msg("遺 ㅽ듭쇰 명 ㅽ 嫄곕듬.\\n\\n愿由ъ寃 臾몄 二쇱.");
         break;

      case ("NO_ACCESS_MODIFY"):
         popup_msg("ν 몄 쇱吏 쇰濡   듬. \\n\\nㅼ ν 二쇱.");
         break;

      case ("FILE_DELETE_FAILURE"):
         popup_msg("쇱 ㅽ⑦듬.\\n\\n愿由ъ寃 臾몄 二쇱.");
         break;

      // 寃 愿⑥

      case ("NOT_ALLOWED_SUBJECT"):
         popup_msg("湲 紐⑹  紐⑹ .\\n\\n湲 紐⑹ ㅼ 명怨 ν댁＜.");
         break;

      case ("NOT_ALLOWED_COMMENT"):
         popup_msg("湲 댁⑹  댁⑹ .\\n\\n湲 댁⑹ ㅼ 명怨 ν댁＜.");
         break;

      case ("NOT_ALLOWED_FILE"):
         popup_msg("遺 쇱.\\n\\n쇱 ㅼ  二쇱.");
         break;

      case ("NOT_ALLOWED_COMMENT"):
         popup_msg(" 湲 \\n\\n湲 ㅼ 깊 二쇱.");
         break;


      // 踰 愿⑥

      case ("NOT_ALLOWED_BANNER_NAME"):
         popup_msg("댁 대  대 .\\n\\nㅼ 명怨 ν댁＜.");
         break;

      case ("NOT_ALLOWED_HOMEPAGE"):
         popup_msg("댁 二쇱媛  二쇱媛 .\\n\\nㅼ 명怨 ν댁＜.");
         break;

      case ("NOT_ALLOWED_DUPLICATE_ITEM"):
         popup_msg("대 깅 듬.");
         break;

      //ш愿

      case ("NOT_ALLOWED_s1_name"):
         popup_msg("щ  吏 듬.\\n\\nㅼ 명怨 ν댁＜.");
         break;

      case ("NOT_ALLOWED_s1_num"):
         popup_msg("   吏 듬.\\n\\nㅼ 명怨 ν댁＜.");
         break;

      //쇳곌

      case ("NOT_ALLOWED_s2_center"):
         popup_msg("쇳곕  吏 듬.\\n\\nㅼ 명怨 ν댁＜.");
         break;

      //移댄怨由 

      case ("NOT_ALLOWED_CAT1"):
         popup_msg("대 移댄怨由ъ  ы⑤ 듬.\\n\\n癒쇱 대 移댄怨由ъ 깅     二쇱湲 諛.");
         break;

      case ("NOT_ALLOWED_LOWQUANTITY"):
         popup_msg("理 二쇰Ц 媛 1..\\n\\n 곗륫  踰쇱 瑜댁몄.");
         break;


      case ("QUERY_ERROR"):
         $err_no = mysql_errno();
         $err_msg = mysql_error();
         $error_msg = "ERROR CODE " . $err_no . " : " . $err_msg;
         $error_msg = addslashes($error_msg);
         popup_msg($error_msg);
         break;

      default:
   }
}
?>