<?
include "@session_inc.php";
include "@config.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 愿由ъ 濡洹몄</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>

<SCRIPT LANGUAGE='javascript'>
<!--
function login_check(fr) {
    var Fm = document.login;

	if(!Fm.id.value) {
	alert("愿由ъ 대瑜 ν몄.");
	Fm.id.focus();
	return; 
	}
     if(!Fm.passwd.value) {
	alert("愿由ъ 鍮諛踰몃 ν몄.");
	Fm.passwd.focus();
	return; }    
	
    if (fr == "mod1") { 
        Fm.action = "admin_login_process.php"
        Fm.submit(); 
    }
}

function loginEnterDown() {
    if(event.keyCode==13)
    	login_check("mod1");
}

//-->
</SCRIPT>

<script language="javascript">
<!--
function sendit2() {
	var Fm = document.form2;


   if(!form2.as_id.value) {
      alert('ID瑜 ν몄!');
      form2.as_id.focus();
      return;
   }


   if(!form2.as_passwd.value) {
      alert('⑥ㅼ瑜 ν몄!');
      form2.as_passwd.focus();
      return;
   }

          
   form2.submit2();
}

function loginEnterDown2() {
    if(event.keyCode==13)
    	login_check("mod1");
}

//-->
</script>


</head>

<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0'>



<table cellpadding='0' cellspacing='0' width='100%' height='100%'>
    <tr>
        <td>

				<form name='login' method='post'>
				<INPUT type=hidden name=mod value="admin_login_ck">
				<table width='620' height='450' border=0 cellpadding=0 cellspacing=0 align='center' background='<? echo("$icon_dir"); ?>/bg_admin_login.png'>
					<tr>
						<td width='620' height='145' colspan='5' style='padding-left:70px; padding-top:70px;'>
						<SPAN class='admin_name'><? echo("$admin_name");?></span> 								
						</td>
					</tr>
					<tr>
						<td width='620' height='71' colspan='5'>
                            <p>&nbsp;</p>
						</td>
					</tr>
					<tr>
						<td width='119' height='44'>
                            <p>&nbsp;</p>
						</td>
						<td width='131' height='44'>
                            <p><input type='text' name='id' size='15' maxlength='15' onKeyDown='javascript:loginEnterDown();' style='background-color:#ffffff;border:1 solid #00bcff; width:120; height:19; font-size:9pt;'></p>
						</td>
						<td width='69' height='44'>
                            <p>&nbsp;</p>
						</td>
						<td width='131' height='44'>
                            <p><input type='password' name='passwd' size='15' maxlength='15' onKeyDown='javascript:loginEnterDown();' style='background-color:#ffffff;border:1 solid #00bcff; width:120; height:19; font-size:9pt;'></p>
						</td>
						<td width='170' height='44'>
                          <p>&nbsp;<img src="<? echo("$icon_dir"); ?>/button_blue_login.gif" border="0"  onClick="javascript:login_check('mod1');" style="cursor:hand"></p>
						</td>
					</tr>
					<tr>
						<td width='620' colspan='5'>
                            <p>&nbsp;</p>
						</td>
					</tr>
				</table>
				</form>
<iframe name="admin_login" src="index_include.php" width="100%" height="110" scrolling='no' marginwidth="0" marginheight="0" frameborder="no"></iframe>

        </td>
    </tr>
</table>


</body>
                            <p>&nbsp;</p>
						</td>
					</tr>
				</table>
				</form>




        </td>
    </tr>
</table>


</body>