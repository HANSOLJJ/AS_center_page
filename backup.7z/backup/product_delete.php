<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

// 로그인 확인
if (empty($_SESSION['member_id']) || empty($_SESSION['member_sid'])) {
    header('Location: login.php');
    exit;
}

// MySQL 호환성 레이어 로드
require_once 'mysql_compat.php';

// 데이터베이스 연결
$connect = mysql_connect('mysql', 'mic4u_user', 'change_me');
mysql_select_db('mic4u', $connect);

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$confirm = isset($_GET['confirm']) ? $_GET['confirm'] : '';

if ($product_id <= 0) {
    header('Location: products.php');
    exit;
}

// 제품 정보 존재 확인
$result = mysql_query("SELECT s15_amid, s15_model_name FROM step15_as_model WHERE s15_amid = $product_id LIMIT 1");
if (!$result || mysql_num_rows($result) === 0) {
    header('Location: products.php');
    exit;
}

$product = mysql_fetch_assoc($result);

if ($confirm === 'yes') {
    // 삭제 수행
    $delete_query = "DELETE FROM step15_as_model WHERE s15_amid = $product_id";
    $delete_result = mysql_query($delete_query);

    if ($delete_result) {
        // 삭제 완료 - products.php로 리다이렉트
        header('Location: products.php?deleted=1');
        exit;
    } else {
        // 삭제 실패
        $error = '데이터베이스 삭제 오류가 발생했습니다: ' . mysql_error();
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>제품 삭제 - AS 시스템</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            font-size: 24px;
        }

        .header-right {
            display: flex;
            gap: 30px;
            align-items: center;
        }

        .user-info {
            font-size: 14px;
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 8px 16px;
            border: 1px solid white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: white;
            color: #667eea;
        }

        .container {
            padding: 40px;
            max-width: 600px;
            margin: 0 auto;
        }

        .delete-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            text-align: center;
        }

        .alert {
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            font-size: 16px;
        }

        .alert-error {
            background: #fee;
            border: 1px solid #f99;
            color: #c33;
        }

        .warning-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }

        .product-info {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            border-left: 4px solid #ff6b6b;
        }

        .product-info p {
            margin-bottom: 10px;
            font-size: 16px;
        }

        .product-info strong {
            color: #ff6b6b;
        }

        .warning-text {
            color: #666;
            font-size: 15px;
            line-height: 1.6;
            margin-bottom: 30px;
        }

        .button-group {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        button, a button {
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-delete {
            background: #ff6b6b;
            color: white;
        }

        .btn-delete:hover {
            background: #ff5252;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
        }

        .btn-cancel {
            background: #e0e0e0;
            color: #333;
        }

        .btn-cancel:hover {
            background: #d0d0d0;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>AS 시스템</h1>
        <div class="header-right">
            <div class="user-info">
                <strong><?php echo htmlspecialchars($_SESSION['member_id']); ?></strong>님 로그인됨
            </div>
            <form method="POST" action="logout.php" style="margin: 0;">
                <button type="submit" class="logout-btn">로그아웃</button>
            </form>
        </div>
    </div>

    <div class="container">
        <div class="delete-container">
            <?php if (!empty($error)): ?>
                <div class="alert alert-error">
                    ✗ <?php echo htmlspecialchars($error); ?>
                </div>
                <div class="button-group">
                    <a href="product_edit.php?id=<?php echo $product_id; ?>"><button class="btn-cancel">돌아가기</button></a>
                </div>
            <?php else: ?>
                <div class="warning-icon">⚠️</div>
                <h2 style="color: #ff6b6b; margin-bottom: 20px;">제품 삭제</h2>

                <div class="product-info">
                    <p>번호: <strong><?php echo htmlspecialchars($product['s15_amid']); ?></strong></p>
                    <p>모델명: <strong><?php echo htmlspecialchars($product['s15_model_name']); ?></strong></p>
                </div>

                <div class="warning-text">
                    <p>이 작업은 <strong style="color: #ff6b6b;">되돌릴 수 없습니다!</strong></p>
                    <p style="margin-top: 15px;">정말로 이 제품을 삭제하시겠습니까?</p>
                </div>

                <div class="button-group">
                    <a href="product_edit.php?id=<?php echo $product_id; ?>"><button class="btn-cancel">취소</button></a>
                    <a href="product_delete.php?id=<?php echo $product_id; ?>&confirm=yes"><button class="btn-delete">확인 - 삭제</button></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php
mysql_close($connect);
?>
