<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 하위댓글존재 확인
$del_result = mysql_query("SELECT count(s1_uid) FROM $db1 WHERE s1_caid = $number");

if (!$del_result) {
   error("QUERY_ERROR");
   exit;
}

$del_rows = mysql_result($del_result,0,0);

if ($del_rows) {
   error("NOT_ALLOWED_CAT1");
   exit;
}



##### 테이블에서 해당 파일의 레코드를 삭제한다.
$result = mysql_query("DELETE FROM $db5 WHERE s5_caid = $number");
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

##### 리스트 출력화면으로 이동한다.
$encoded_key = urlencode($key);
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>