<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 사용자가 아무값도 입력하지 않았거나 입력한 값이 허용되지 않는 값일 경우 에러메시지를 출력하고 스크립트를 종료한다.

if(!ereg("([^[:space:]]+)", $s5_category)) {
   error("NOT_ALLOWED_s1_name");
   exit;
}

$result = mysql_query("SELECT count(s5_category) FROM $db WHERE s5_category = '$s5_category'");
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$rows = mysql_result($result,0,0);
if ($rows) {
    popup_msg("입력하신 카테고리명은 이미 등록되어 있습니다. \\n\\n다시한번 확인하시고 입력하여 주십시오.");
         break;    
   exit;
}
mysql_free_result($result);


$query = "UPDATE $db SET s5_category = '$s5_category' WHERE s5_caid  = '$number'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>
