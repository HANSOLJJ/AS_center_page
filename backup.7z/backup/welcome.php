<?
include "@config.php";
include "@error_function.php";
include "@access.php";
$Today_date = date("Y m d",time());
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 뱀ъ댄 愿由ы</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>
<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0'>
<p>&nbsp;</p>
<table width='800' Height='100' border='1' cellpadding='0' cellspacing='0' bordercolor='#50BAE0' bordercolordark='white' bordercolorlight='#50BAE0' align='center' valign='middle'>
	<tr>
        <td align="center" style="padding:5px;" bgcolor="#DFFFFF">
            <p align="center"><b><font color='red'>留 댁  異  猷(2012/04/12/09:18)</font></b></p>
        </td>
    </tr>
</table>
<p>&nbsp;</p>
<table width='800' Height='100' border='1' cellpadding='0' cellspacing='0' bordercolor='#50BAE0' bordercolordark='white' bordercolorlight='#50BAE0' align='center' valign='middle'>
	<tr>
        <td align="center" style="padding:5px;" bgcolor="#DFFFFF">
            <p align="center"><a href='complete_doc[20120316].pdf' target='_blank'><b><font color='red'>猷怨</font></b></a></p>
        </td>
    </tr></table>
