<?
$asid = $number;
$sec = $s11_sec;

$query_sum1 = "SELECT s18_asid,  s18_uid,  s18_quantity,  s18_sp_cost, cost1, cost2 FROM $db18 WHERE s18_asid = '$asid'";
$result_sum1= mysql_query($query_sum1);
if (!$result_sum1) {
   error("QUERY_ERROR");
   exit;
}

$no_code="0";
$kid_total  ="0";

while($row_sum1 = mysql_fetch_array($result_sum1,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s18_asid = $row_sum1[s18_asid];
$no_code++;
$my_s18_uid = $row_sum1[s18_uid];
$my_s18_quantity = $row_sum1[s18_quantity];
$my_s18_sp_cost = $row_sum1[s18_sp_cost];

$my_cost1= $row_sum1[cost1];
$my_cost2 = $row_sum1[cost2];

//echo"$my_s18_asid - $my_s18_uid - $my_s18_quantity - $my_s18_sp_cost<br>";

if($my_s18_sp_cost ==""){$kid_cost[$no_code] = $my_s18_quantity * $my_cost1;}else
if($my_s18_sp_cost !=""){$kid_cost[$no_code] = $my_s18_quantity * $my_cost2;}
//---------------가격 테스트 코드

//echo "<P align='left'>$my_s18_quantity X $my_cost1 = $kid_cost[$no_code] <br></p>";

//-----------------------------
$kid_total = $kid_total + $kid_cost[$no_code];

}
$kid_total_default = $kid_total;
$kid_total =number_format($kid_total);
//echo"<b>$kid_total 원</b>";
?>