<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		① AS 내역&nbsp;→&nbsp;
		<font color='red'><b>② 부품내역</b></font>
		</td>
	</tr>
</table>
<br>

<?
include"1_exp.php";
include"temp_code.php";

print"<table width='100%' align='center' cellspacing='0' cellpadding='0'>
			<tr>
				<td align='center' width='50%' valign='top'>";
				include"cure_parts_list.php";
	print"</td>
	<td width='50%' valign='top' align='center'>";
	include"cure_view.php";
	print"</td>
	</tr>
	</table>"; 
	?>