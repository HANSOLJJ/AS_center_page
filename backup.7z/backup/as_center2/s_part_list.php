<table  width='100%' cellpadding='0' cellspacing='0' border='0' align='center'>

<?

##### 
$instant_query = "SELECT s18_accid, s18_aiid, s18_uid, s18_quantity, cost_name, cost_sn FROM $db18 WHERE s18_aiid = '$my_s14_aiid'";
$instant_result = mysql_query($instant_query);
if(!$instant_result) {
   error("QUERY_ERROR");
   exit;
}
$instant_rows = mysql_num_rows($instant_result);
if($instant_rows > 0) {
$total_cost = '0';
   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   $my_s18_accid = $instant_reply->s18_accid;
	   $my_s18_aiid = $instant_reply->s18_aiid;
	   $my_s18_uid = $instant_reply->s18_uid;
	   $my_s18_quantity = $instant_reply->s18_quantity;

	   $my_cost_name = $instant_reply->cost_name;
	   $my_cost_sn = $instant_reply->cost_sn;


//------------------데이터 불러오기


print "	
<tr >
<td align='left'>
&nbsp;-&nbsp;$my_cost_name&nbsp;&nbsp;[$my_cost_sn]
</td>
<td align='right'>
<font color='red'><b>$my_s18_quantity&nbsp;개</b>&nbsp;</font><br>
 </td>
 </tr>";
$total_cost = $total_cost + $parts_cost;
   }


}

?>
</table>
