<table  width='100%' cellpadding='0' cellspacing='0' border='1' align='center'bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td  width='18%' height='40' background="<?echo "$border_bg1";?>">
		<p align='center'><b>모델명</b></p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>불량증상</b></p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>AS 내역</b></p>
		</td>
		<td  width='32%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>부품내역</b></p>
		</td>
		<td  width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>등록수정</b></p>
		</td>
	</tr>

<?
$query_item_list = "SELECT s14_aiid, s14_asid, s14_model, s14_poor, s14_stat, s14_asrid, cost_name, cost_sn, as_start_view, as_end_result FROM $db14 WHERE s14_asid = '$my_s13_asid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}

while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s14_aiid = $row_item_list[s14_aiid];
$my_s14_asid = $row_item_list[s14_asid];
$my_s14_model = $row_item_list[s14_model];
$my_s14_poor = $row_item_list[s14_poor];
$my_s14_stat = $row_item_list[s14_stat];
$my_s14_asrid = $row_item_list[s14_asrid];

$my_cost_name = $row_item_list[cost_name];
$my_cost_sn = $row_item_list[cost_sn];
$my_as_start_view = $row_item_list[as_start_view];
$my_as_end_result = $row_item_list[as_end_result];

if($my_as_end_result ==""){$my_as_end_result ="&nbsp;";}


//------------------데이터 불러오기

$small_query2 = "SELECT s16_poor FROM $db16 WHERE s16_apid = '$my_s14_poor'";
$small_result2 = mysql_query($small_query2);
if(!$small_result2) {
   error("QUERY_ERROR");
   exit;
}

$small_row2 = mysql_fetch_row($small_result2);

$my_s16_poor = $small_row2[0];

echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><b>$my_cost_name</b><br>($my_cost_sn)</td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><font color='red'><b>$my_as_start_view</b></font></td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg>$my_as_end_result</td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg>");
//include"s_part_list.php";
include"test_s_part_list.php";
echo("</td>");
echo("<td align='center'><a href='list.php?in_code=modify1&s14_aiid=$my_s14_aiid&s14_asrid=$my_s14_asrid&s11_sec=$my_ex_sec1&s13_asid=$my_s13_asid'><img src='../$icon_dir/button_blue_mo_wr.gif' border='0' align='absmiddle'></a></td></tr>");

}

?>
<tr>
	<td height='50' align='center' valign='middle' ><b>처리비용 총액</b></td>
	<td height='50' align='center' valign='middle'  colspan='3'><font color='red'><b><?include"add_sum_total_cost.php";?></b></font></td>
	<td height='50' align='center' valign='middle' ><b>-</b></td>
	</td>
</tr>
</table>