<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		<font color='red'><b>① AS 내역</b></font>&nbsp;→&nbsp;
		② 부품내역
		</td>
	</tr>
</table>
<br>

<script language="javascript">
<!--
function sendit() {

   if(!form.s14_asrid.value) {
      alert('AS내역을 입력하세요!');
      form.s14_asrid.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name='form' method='POST' action='list.php?in_code=modify2&page=<? echo("$page"); ?>' enctype='multipart/form-data'>
<INPUT type='hidden' name='s18_aiid' value="<?echo"$s14_aiid";?>">
<INPUT type='hidden' name='s11_sec' value="<?echo"$s11_sec";?>">
<INPUT type='hidden' name='s13_asid' value="<?echo"$s13_asid";?>">
<!-------------------------내역  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			AS 내역
			</td>
			<td width='70%'>
			<select name="s14_asrid"<?echo("$Form_style1");?>>
			<option value=''>AS 내역을 선택해 주세요.</option>
<?php
     
##### 레코드 세트
$result= mysql_query("SELECT s19_asrid, s19_result FROM $db19");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장   

$my_s19_asrid = $row[s19_asrid];
$my_s19_result = $row[s19_result];

  
##### 
if($s14_asrid == $my_s19_asrid){echo("<option value='$my_s19_asrid' selected>$my_s19_result</option>");
}else{
echo("<option value='$my_s19_asrid'>$my_s19_result</option>");}

}
?>

			</select>
			</td>
		</tr>

</table>

<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>