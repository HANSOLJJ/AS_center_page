<?
$query_temp = "UPDATE $db14 SET s14_asrid  = '$s14_asrid'  WHERE s14_aiid  = '$s18_aiid'";
$result_temp = mysql_query($query_temp);

if (!$result_temp) {      
   error("QUERY_ERROR");
   exit;
}
?>