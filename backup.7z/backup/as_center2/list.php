<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>


<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<? echo"$title_b_22"; ?>

<?

switch ($in_code) {

// 일반페이지


case ("") : 	include"list_view.php"; Break;
case ("list_view") : 	include"list_view.php"; Break;
case ("write1") : 	include"write1.php"; Break;
case ("write2") : 	include"write2.php"; Break;
case ("modify1") : 	include"modify1.php"; Break;
case ("modify2") : 	include"modify2.php"; Break;
case ("set2") : 	include"as_set2.php"; Break;
case ("level_down") : 	include"level_down.php"; Break;
}

?>
