<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";



##### 
$s13_as_level = "1";
$s13_as_name1 = $HTTP_SESSION_VARS[member_name];

$query = "UPDATE $db13 SET s13_as_level  = '$s13_as_level', s13_as_name1  = '$s13_as_name1', s13_as_name2  = '', s13_total_cost  = ''  WHERE s13_asid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

#####파츠 수량 정리
##### 테이블에서 해당 파일의 레코드를 삭제한다.
$result_del1 = mysql_query("DELETE FROM $db18 WHERE s18_asid  = $number");
if (!$result_del1) {
 error("QUERY_ERROR");
 exit;
}

##### 테이블에서 해당 파일의 레코드를 삭제한다.
$query2 = "UPDATE $db14 SET s14_asrid  = '', s14_cart  = '', as_end_result ='' WHERE s14_asid  = '$number'";
$result2 = mysql_query($query2);
if (!$result2) {
 error("QUERY_ERROR");
 exit;
}


//--------테스트 코드
 $query_test = "SELECT  s7_cpid, s7_uid, s7_num  FROM $db7 WHERE s7_center_id  = '$center_id_s'";
 $result_test = mysql_query($query_test);

 while($row_test = mysql_fetch_array($result_test,MYSQL_ASSOC)) {
	 $my_s7_cpid = $row_test[s7_cpid];
	 $my_s7_uid = $row_test[s7_uid];
	 $my_s7_num = $row_test[s7_num];

//echo"$my_s7_cpid - $my_s7_uid - $my_s7_num<br>";
 }
##########







##### 리스트 출력화면으로 이동한다.
$encoded_key = urlencode($key);
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset&page=$page'>");   
   ?>