<?

//------------------업체명
$instant_query = "Select s11_com_name, s11_sec, s11_oaddr, s11_phone1, s11_phone2, s11_phone3 FROM $db11 WHERE s11_meid  ='$s13_meid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $s11_com_name=$instant_reply->s11_com_name;
	   $s11_sec=$instant_reply->s11_sec;
	   $s11_oaddr=$instant_reply->s11_oaddr;
	   $s11_phone1=$instant_reply->s11_phone1;
	   $s11_phone2=$instant_reply->s11_phone2;
	   $s11_phone3=$instant_reply->s11_phone3;

	   $remote_phone = $s11_phone1."".$s11_phone2."".$s11_phone3;
	
   }
}

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s12_ssid, s12_sms_category, s12_sms_sample FROM $db12 WHERE s12_sms_category = '완료'";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$remote_msg = $row->s12_sms_sample;
$remote_msg = $remote_msg."".$kid_total."원";


$id ="digitalcom";
$pw="digidigi";
$num ="1";
$remote_reserve ="0";
//$remote_phone ="01036955652";
//$remote_callback ="0326241980";
//$remote_msg="테스트 문자";

?>
<form name="SMSFORM" method="post" action="http://www.munja114.co.kr/Remote/RemoteSms.html">
<input type="hidden" name="remote_id" value="<? echo $id;?>"><!-- 문자114 아이디 -->
<input type="hidden" name="remote_pass" value="<? echo $pw;?>"><!-- 문자114 패스워드 -->
<input type="hidden" name="remote_returnurl" value="<? echo"http://mic4u.co.kr/@@as/as/as_center2/list.php?in_code=list_view";?>"> 
<!-- 발송후 리턴할 주소 -->
<input type="hidden" name="remote_num" value="<? echo $num;?>">
<!-- 수신번호 개수 default : 1, 다수 번호,번호-->
<input type="hidden" name="remote_reserve" value="<? echo $remote_reserve;?>"><!-- 예약 1 , 일반 0 -->
<input type="hidden" name="remote_reservetime" value="2005-05-18 11:30">
<!-- 예약시 예약 시간 년-월-일 시:분 -->
<input type="hidden" name="remote_phone" value="<? echo $remote_phone;?>"><!-- 수신번호 다수일때는 쉼표','로 구분 --> 
<input type="hidden" name="remote_callback" value="<? echo $remote_callback;?>"><!-- 발신번호 숫자만 입력 -->
<input type="hidden" name="remote_msg" value="<? echo $remote_msg;?>">
<input type="hidden" name="remote_etc1" value="사용자정의1"><!-- 사용자 정의 변수1 -->
<input type="hidden" name="remote_etc2" value="사용자정의2"><!-- 사용자 정의 변수2 -->
<script>document.SMSFORM.submit();</script> 
</form>
<!------------------------->
