<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 테이블에서 해당 파일의 레코드를 삭제한다.
$result = mysql_query("DELETE FROM $db18 WHERE s18_accid = '$number'");

##### 선택한 게시물의 입력값을 뽑아낸다.
$level_result = mysql_query("SELECT count(s18_accid) FROM $db18 WHERE s18_aiid  = '$s18_aiid'");
$level_rows = mysql_result($level_result,0,0);

if($level_rows =="" OR $level_rows =="0"){$level_rows ="";}

$query2 = "UPDATE $db14 SET s14_cart  = '$level_rows' WHERE s14_aiid  = '$s18_aiid'";
$result2 = mysql_query($query2);

if (!$result) {
 error("QUERY_ERROR");
 exit;
}

##### 리스트 출력화면으로 이동한다.

echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=modify2&s18_aiid=$s18_aiid&s14_asrid=$s14_asrid&s11_sec=$s11_sec&s13_asid=$s13_asid&keyfield=$keyfield&key=$key&page=$page'>");   
?>
