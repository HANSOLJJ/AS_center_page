<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 1500;

$result = mysql_query("SELECT count(s18_accid) FROM $db18 WHERE s18_aiid = '$s18_aiid' AND s18_end ='N' ");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>
<p align='center'><b>사용부품</b></p>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE' class="body">
	<tr>
		<td  height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>번호</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>카테고리</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>ERP</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>자재명</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>수량</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>삭제</b></p>
		</td>
	</tr>
<?

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s18_accid, s18_aiid, s18_uid, s18_quantity, s18_signdate FROM $db18 WHERE s18_aiid = '$s18_aiid' AND s18_end ='N' ";

$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s18_accid = $row[s18_accid];
   $my_s18_aiid = $row[s18_aiid];
   $my_s18_quantity = $row[s18_quantity];
   $my_s18_uid = $row[s18_uid];




##### 선택한 게시물의 입력값을 뽑아낸다.
$query2 = "SELECT s1_uid, s1_caid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1 FROM $db1 WHERE s1_uid = '$my_s18_uid'";
$result2 = mysql_query($query2);
if(!$result2) {
   error("QUERY_ERROR");
   exit;
}
$row2 = mysql_fetch_row($result2);
 
$my_s1_uid = $row2[0];
$my_s1_caid = $row2[1];
$my_s1_erp = $row2[2];
$my_s1_name = $row2[3];

$my_s1_cost_c_1 = $row2[4];
$my_s1_cost_a_1 = $row2[5];
$my_s1_cost_a_2 = $row2[6];
$my_s1_cost_n_1 = $row2[7];
$my_s1_cost_n_2 = $row2[8];
$my_s1_cost_s_1 = $row2[9];

//------------------가격정보

if($s11_sec =="일반"){$parts_cost = $my_s1_cost_n_2;}else
if($s11_sec =="대리점"){$parts_cost = $my_s1_cost_a_2;}else
if($s11_sec =="딜러"){$parts_cost = $my_s1_cost_s_1;}else{
$parts_cost = "가격에러";}



//------------------카테고리명 부르기
$category_query = mysql_query("Select s5_category FROM $db5 WHERE s5_caid ='$my_s1_caid'");
$my_s1_caid = mysql_result($category_query,0,0);

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}

 ##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<tr><td height='35'  $list_style1 $td_bg align='center'>$article_num.</td>");

##### 

echo("<td align='center'  $list_style1 $td_bg><p>$my_s1_caid</p></td>");

##### 

echo("<td align='center'  $list_style1 $td_bg><p>$my_s1_erp</p></td>");

##### 

echo("<td align='center'  $list_style1 $td_bg><p>$my_s1_name</p></td>");

echo("<td align='center' $list_style1 $td_bg><p>");

echo("<iframe name='frame$article_num' src='num.php?s18_aiid=$my_s18_aiid&s18_accid=$my_s18_accid&my_s18_quantity=$my_s18_quantity&s18_uid=$my_s18_uid&s11_sec=$s11_sec&s14_asrid=$s14_asrid&s18_asid=$s13_asid&keyfield=$keyfield&key=$key' width='100' height='35' scrolling='no' marginwidth='0' marginheight='0' frameborder='no' valign='middle'></iframe>");

echo("</p></td>");

echo("<td align='center'  $list_style1 $td_bg><a href='cart_item_del.php?s18_aiid=$my_s18_aiid&number=$my_s18_accid&s14_asrid=$s14_asrid&parts_cost=$parts_cost&s13_asid=$s13_asid&s11_sec=$s11_sec&keyfield=$keyfield&key=$key&page=$page'><img src='../$icon_dir/cart_del.gif' border='0'></a></td>");

$article_num--;
}
if($total_record == '0'){print"<table width='95%' align='center' cellspacing='0' cellpadding='0'  border='1' class='body' bordercolor='#dedede' bordercolordark='white' bordercolorlight='#dedede'><tr><td height='160'><p align='center'>사용부품 내역이  비어있습니다.</p></td></tr></table>";}


?>


<table width='100%'align='center' cellspacing='0' cellpadding='0'  border='0' class='body'>
	<tr>
		<td align='center'>
		<br><br>
		&nbsp;
<?if(!$total_record == '0'){print"<a href='list.php?in_code=list_view'><img src='../$icon_dir/button_blue_submit.gif' border='0'></a>";}?>

		</td>
	</tr>
</table>

<? echo"$s13_asid";?>