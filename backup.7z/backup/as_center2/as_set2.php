<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how, s13_as_in_no, s13_meid, s13_dex_no, s13_sms1, s13_sms2, s13_bank_check, s13_tax_code, s13_dex_send, s13_dex_send_name, s13_as_out_date, ex_tel, ex_sms_no, ex_sec1, ex_sec2, ex_company, ex_man, ex_address, ex_address_no, ex_company_no FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_asid = $row->s13_asid;
$my_s13_as_center = $row->s13_as_center;
$my_s13_as_in_date = $row->s13_as_in_date;
$my_s13_as_in_how = $row->s13_as_in_how;

$my_s13_as_in_no = $row->s13_as_in_no;
$my_s13_meid = $row->s13_meid;
$my_s13_dex_no = $row->s13_dex_no;
$my_s13_sms1 = $row->s13_sms1;
$my_s13_sms2 = $row->s13_sms2;
$my_s13_bank_check = $row->s13_bank_check;
$my_s13_tax_code = $row->s13_tax_code;
$my_s13_dex_send = $row->s13_dex_send;

$my_s13_dex_send_name = $row->s13_dex_send_name;
$my_s13_as_out_date = $row->s13_as_out_date;


$my_s13_as_in_date =date("Y/m/d",$my_s13_as_in_date);

$my_ex_tel = $row->ex_tel;
$my_ex_sms_no = $row->ex_sms_no;
$my_ex_sec1 = $row->ex_sec1;
$my_ex_sec2 = $row->ex_sec2;
$my_ex_company = $row->ex_company;
$my_ex_man = $row->ex_man;
$my_ex_address = $row->ex_address;
$my_ex_address_no = $row->ex_address_no;
$my_ex_company_no = $row->ex_company_no;


##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p>&nbsp;</p>

		<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
			<tr>
				<td  width='15%' height='50' background="<?echo "$border_bg1";?>">
				<p align='center'><b>입고일</b></p>
				</td>
				<td  width='15%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>수탁방법</b></p>
				</td>
				<td  width='15%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>업체명</b></p>
				</td>
				<td  width='10%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>형태</b></p>
				</td>
				<td  width='30%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>주소</b></p>
				</td>
				<td  width='15%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>연락처</b></p>
				</td>
			</tr>
			<tr>
				<td height='50'>
				<p align='center'><? echo"$my_s13_as_in_date";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_s13_as_in_how";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_ex_company";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_ex_sec1";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_ex_address";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_ex_tel";?><br>(<? echo"$my_ex_sms_no";?>)</p>
				</td>
			</tr>
			<tr>
				<td colspan='20'>
				<? include"as_set2_add_list.php";?>
				</td>
			</tr>
		</table>

		<p>&nbsp;</p>


		<p align='center'><font color='red'><b>정확히 확인해 주시기 바랍니다.<br>완료 처리후 되돌릴 수 없습니다.</font></p>
		<p>&nbsp;</p>
		</td>
	</td>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center' >
	<tr>
		<td>
		<p align='right'><a href='as_set2_process.php?number=<?echo("$number");?>&total_cost_sum=<?echo("$total_cost");?>&s13_as_in_how=<?echo("$my_s13_as_in_how");?>&s13_meid=<? echo("$my_s13_meid");?>'>
		<img src='../<?echo("$icon_dir");?>/button_set2.gif' align='absmiddle' border='0'></a>&nbsp;
		<a href='<? echo("list.php?in_code=list_view");?>'>
		<img src='../<?echo("$icon_dir");?>/button_blue_cancel.gif' align='absmiddle' border='0'>
		</a>
		</p>
		</td>
	</tr>
</table>
