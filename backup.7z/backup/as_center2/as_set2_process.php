<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";



##### 
$s13_as_level = "3";
$s13_as_name2 = $HTTP_SESSION_VARS[member_name];

$query = "UPDATE $db13 SET s13_as_level  = '$s13_as_level', s13_as_name2  = '$s13_as_name2', s13_total_cost  = '$total_cost_sum'  WHERE s13_asid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

#####파츠 수량 정리

//------기존 수량 확인
$center_id_s = $HTTP_SESSION_VARS[member_center_id];



$query1 = "SELECT s18_uid, s18_quantity FROM $db18 WHERE s18_asid = '$number'";
$result1 = mysql_query($query1);

while($row1 = mysql_fetch_array($result1,MYSQL_ASSOC)) {

	$my_s18_uid = $row1[s18_uid];
	$my_s18_quantity = $row1[s18_quantity];



$query2 = "UPDATE $db7 SET s7_num = s7_num - '$my_s18_quantity' WHERE s7_center_id  = '$center_id_s' AND s7_uid ='$my_s18_uid'";
$result2 = mysql_query($query2);


}
//--------테스트 코드
 $query_test = "SELECT  s7_cpid, s7_uid, s7_num  FROM $db7 WHERE s7_center_id  = '$center_id_s'";
 $result_test = mysql_query($query_test);

 while($row_test = mysql_fetch_array($result_test,MYSQL_ASSOC)) {
	 $my_s7_cpid = $row_test[s7_cpid];
	 $my_s7_uid = $row_test[s7_uid];
	 $my_s7_num = $row_test[s7_num];

//echo"$my_s7_cpid - $my_s7_uid - $my_s7_num<br>";
 }
##########

if($s13_as_in_how =="택배" OR $s13_as_in_how =="퀵"){
include"sms_center_key.php";
include"sms_cost.php";
//echo"$remote_callback";
include"sms.php";
}

##### 리스트 출력화면으로 이동한다.
$encoded_key = urlencode($key);
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>