<?
$query_read = "SELECT s19_asrid, s19_result FROM step19_as_result WHERE s19_asrid = $s14_asrid";
$result_read = mysql_query($query_read);
if(!$result_read) {
   error("QUERY_ERROR");
   exit;
}
$row_read = mysql_fetch_object($result_read);

$my_s19_asrid = $row_read->s19_asrid;
$my_s19_result = $row_read->s19_result;

$query_33 = "UPDATE step14_as_item SET as_end_result  = '$my_s19_result' WHERE s14_aiid  = '$s18_aiid'";
  $result_33 = mysql_query($query_33);
  if (!$result_33) {
	 error("QUERY_ERROR");
	 exit;
  }
  ?>