<?
$id ="digitalcom";
$pw="digidigi";
$num ="1";
$remote_reserve ="0";
$remote_phone ="01036955652";
$remote_callback ="00000";
$remote_msg="테스트 문자";
?>
<form name="SMSFORM" method="post" action="http://www.munja114.co.kr/Remote/RemoteSms.html">
<input type="hidden" name="remote_id" value="<? echo $id;?>"><!-- 문자114 아이디 -->
<input type="hidden" name="remote_pass" value="<? echo $pw;?>"><!-- 문자114 패스워드 -->
<input type="hidden" name="remote_returnurl" value="www.test.co.kr/Remote/return.html">
<!-- 발송후 리턴할 주소 -->
<input type="hidden" name="remote_num" value="<? echo $num;?>">
<!-- 수신번호 개수 default : 1, 다수 번호,번호-->
<input type="hidden" name="remote_reserve" value="<? echo $remote_reserve;?>"><!-- 예약 1 , 일반 0 -->
<input type="hidden" name="remote_reservetime" value="2005-05-18 11:30">
<!-- 예약시 예약 시간 년-월-일 시:분 -->
<input type="hidden" name="remote_phone" value="<? echo $remote_phone;?>"><!-- 수신번호 다수일때는 쉼표','로 구분 --> 
<input type="hidden" name="remote_callback" value="<? echo $remote_callback;?>"><!-- 발신번호 숫자만 입력 -->
<input type="hidden" name="remote_msg" value="<? echo $remote_msg;?>">
<input type="hidden" name="remote_etc1" value="사용자정의1"><!-- 사용자 정의 변수1 -->
<input type="hidden" name="remote_etc2" value="사용자정의2"><!-- 사용자 정의 변수2 -->
<input type="submit" name="submit1" value="전송">
</form>
 