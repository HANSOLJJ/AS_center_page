<table  width='100%' cellpadding='0' cellspacing='0' border='0' align='center'>

<?

##### 
$instant_query = "SELECT s18_accid, s18_aiid, s18_uid, s18_quantity, s18_sp_cost, s18_asid, cost_name, cost_sn, cost1, cost2, cost_sec FROM $db18 WHERE s18_aiid = '$my_s14_aiid'";
$instant_result = mysql_query($instant_query);
if(!$instant_result) {
   error("QUERY_ERROR");
   exit;
}
$instant_rows = mysql_num_rows($instant_result);
if($instant_rows > 0) {
$total_cost = '0';
   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   $my_s18_accid = $instant_reply->s18_accid;
	   $my_s18_aiid = $instant_reply->s18_aiid;
	   $my_s18_uid = $instant_reply->s18_uid;
	   $my_s18_quantity = $instant_reply->s18_quantity;
	   $my_s18_sp_cost = $instant_reply->s18_sp_cost;
	   $my_s18_asid = $instant_reply->s18_asid;

//------------------추가코드
	   $my_cost_name = $instant_reply->cost_name;
	   $my_cost_sn = $instant_reply->cost_sn;
	   $my_cost1 = $instant_reply->cost1;
	   $my_cost2 = $instant_reply->cost2;
	   $my_cost_sec = $instant_reply->cost_sec;



//------------------가격정보
if($my_s18_sp_cost ==""){$parts_cost = $my_cost1 * $my_s18_quantity; $my_cost= $my_cost1;}else{$parts_cost = $my_cost2 * $my_s18_quantity;$my_cost= $my_cost2;}

$my_cost = number_format($my_cost);	
$n_parts_cost = number_format($parts_cost );	
//------------------데이터 불러오기


print "	
<tr >
<td align='left'>
&nbsp;-&nbsp;$my_cost_name&nbsp;&nbsp;[$my_cost_sn]
</td>
<td align='right'>
<font color='red'><b>$my_s18_quantity&nbsp;개</b>&nbsp;</font><br>
 </td>
 <td align='right'>
<font color='red'><b>$my_cost</b>&nbsp;X $my_s18_quantity = $n_parts_cost </font>
";


//$total_cost = $total_cost + $parts_cost;

$total_cost = $total_cost + $parts_cost;


   }

}
//$total_cost = $total_cost + 2500;
$total_cost = number_format($total_cost);
$total_cost = $total_cost."&nbsp;원";
print "
 </td>
 </tr>
 ";
?>
</table>
