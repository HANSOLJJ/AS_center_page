<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>
<script type="text/javascript">
window.resizeTo (800, 1000);
window.focus();

function printNow() {
  document.getElementById('command_bar').style.display = 'none';
  window.print();
}
</script>

<div id='command_bar'>
  A4용지를 준비하고 인쇄버튼을 클릭하세요. &nbsp; <input type='button' value='인쇄하기' onclick='printNow()' />
</div>
<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how, s13_as_in_no, s13_meid, s13_dex_no, s13_total_cost, s13_sms1, s13_sms2, s13_bank_check, s13_tax_code, s13_dex_send, s13_dex_send_name, s13_as_out_date, s13_as_name2, ex_tel, ex_sms_no, ex_sec1, ex_sec2, ex_company, ex_man, ex_address, ex_address_no, ex_company_no, s13_bankcheck_w FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_asid = $row->s13_asid;
$my_s13_as_center = $row->s13_as_center;
$my_s13_as_in_date = $row->s13_as_in_date;
$my_s13_as_in_how = $row->s13_as_in_how;

$my_s13_as_in_no = $row->s13_as_in_no;
$my_s13_meid = $row->s13_meid;
$my_s13_dex_no = $row->s13_dex_no;
$my_s13_total_cost = $row->s13_total_cost;
$my_s13_sms1 = $row->s13_sms1;
$my_s13_sms2 = $row->s13_sms2;
$my_s13_bank_check = $row->s13_bank_check;
$my_s13_tax_code = $row->s13_tax_code;
$my_s13_dex_send = $row->s13_dex_send;

$my_s13_dex_send_name = $row->s13_dex_send_name;
$my_s13_as_out_date = $row->s13_as_out_date;
$my_s13_as_name2= $row->s13_as_name2;

/// 추가--------------------------
$my_ex_tel = $row->ex_tel;
$my_ex_sms_no = $row->ex_sms_no;
$my_ex_sec1 = $row->ex_sec1;
$my_ex_sec2 = $row->ex_sec2;
$my_ex_company = $row->ex_company;
$my_ex_address = $row->ex_address;
$my_ex_address_no = $row->ex_address_no;
$my_ex_company_no = $row->ex_company_no;

$s13 = $row->s13_bankcheck_w;
if($s13 =='center'){$s13 ="센터 현금납부";}else
if($s13 =='base'){$s13 ="계좌이체";}else
if($s13 ==''){$s13 ="3월 8일 이후  확인가능";}
/// 추가--------------------------

$my_s13_as_in_date =date("Y년 m월 d일",$my_s13_as_in_date);
$my_s13_bank_check= date("Y년 m월 d일",$my_s13_bank_check);
$my_s13_as_out_date= date("Y년 m월 d일",$my_s13_as_out_date);

if($my_s13_tax_code != ""){$tax_on ="발행";}else{$tax_on ="미발행";}

if($my_s13_dex_send_name == ""){$dex_send ="&nbsp;";} else {$dex_send ="$my_s13_dex_send_name($my_s13_dex_send)";}

//------------------센터명
$center_query = mysql_query("Select s2_center FROM step2_center WHERE s2_center_id ='$my_s13_as_center'");
$center_name = mysql_result($center_query,0,0);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<p align='left'><img src='logo1.jpg' width='100'></p>
<table border="0" width="100%" >
    <tr>
        <td width="50%" valign="top">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td colspan="3" width="100%" height='50'>
                        <p align='center'><font size='4'><b>A/S 접수 및 처리 내역서</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="10%" rowspan="4"><p align='center'><b>공<br>급<br>자</b></p></td>
                    <td width="45%" height='30'><p align='center'><b>상호</b></p></td>
                    <td width="45%"><p align='center'>(주)디지탈컴</p></td>
                </tr>
                <tr>
                    <td width="45%"  height='30'><p align='center'><b>사업자등록번호</b></p></td>
                    <td width="45%"><p align='center'>116-81-75974</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>처리지점</b></p></td>
                    <td width="45%"><p align='center'><? echo"$center_name";?></p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>A/S 처리기사</b></p></td>
                    <td width="45%"><p align='center'><? echo"$my_s13_as_name2";?></p></td>
                </tr>
            </table>
        </td>
        <td width="50%" valign="top">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td colspan="2" width="50%" height='30'>
                        <p align='center'><b>접수번호</b></p>
                    </td>
                    <td width="50%"><p align='center'><? echo"$my_s13_as_in_no";?></p></td>
                </tr>
                <tr>
                    <td colspan="2" width="50%" height='30'><p align='center'><b>일자</b></p></td>
                    <td width="50%"><p align='center'><? echo"$my_s13_as_in_date";?></p></td>
                </tr>
                <tr>
                    <td width="10%"  rowspan="4"><p align='center'><b>접수신청</b></p></td>
                    <td width="45%" height='30'><p align='center'><b>상호</b></p></td>
                    <td width="45%"><p align='center'><? echo"$my_ex_company";?>&nbsp;귀하</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>연락처</b></p></td>
                    <td width="45%"><p align='center'><? echo"$my_ex_tel";?></p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>세금계산서발행</b></p></td>
                    <td width="45%">
                        <p align='center'><? echo"$tax_on";?></p>
                    </td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>사업자등록번호</b></p></td>
                    <td width="45%"><p align='center'><? echo"$my_ex_company_no";?></p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
			<table border="0" width="100%" height='30'>
				<tr>
					<td>
					<p align='left'><font size='3'><b>A/S 내역 및 비용</b></font></p>
					</td>
				</tr>
			</table>
           <?include"test_set2_add_list2.php";?>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="25%" height='30'><p align='center'><b>입금계좌번호</b></p></td>
                    <td colspan="3" width="75%"><p align='center'><b>신한 140-005-221339 (주)디지탈컴 정용호</b></p></td>
                </tr>
                <tr>
                    <td width="25%" height='30'><p align='center'><b>대금지급</b></p></td>
                    <td width="25%"><p align='center'><b><?echo"$s13"; ?></b></p></td>
                    <td width="25%"><p align='center'><b>입금일자</b></p></td>
                    <td width="25%"><p align='center'><? echo"$my_s13_bank_check";?></p></td>
                </tr>
                <tr>
					<td  height='30'><p align='center'><b>A/S 처리완료일</b></p></td>
                    <td><p align='center'><? echo"$my_s13_as_out_date";?></p></td>
                    <td ><p align='center'><b>택배운송번호</b></p></td>
                    <td><p align='center'><? echo"$dex_send";?></p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="100%" colspan="3" height='30'><p align='center'><b>디지탈컴 A/S 센터</b></p></td>
                </tr>
                <tr>
                    <td width="15%" height='30'><p align='center'><b>지점</b></p></td>
                    <td width="60%"><p align='center'><b>주소</b></p></td>
                    <td width="25%" ><p align='center'><b>전화번호</b></p></td>
                </tr>
                  <tr>
                    <td  height='30'><p align='center'><b>영등포</b></p></td>
                    <td><p align='left'>[우 150-723]서울특별시 영등포구 영등포로 109, 3층 가열 8호 (당산동2가,영등포 유통상가)</p></td>
                    <td><p align='center'>02-2671-9193</p></td>
                </tr>
                <tr>
                    <td height='30' ><p align='center'><b>을지로</b></p></td>
                    <td ><p align='left'>[우 100-340]서울특별시 중구 을지로 157, 라열 377호 (산림동, 대림상가)</p></td>
                    <td ><p align='center'>02-2275-9193</p></td>
                </tr>
				<tr>
                    <td  height='30'><p align='center'><b>본사</b></p></td>
                    <td><p align='left'>[우 421-742]경기도 부천시 오정구 석천로 397, 303동 801호-804호 (삼정동, 부천테크노파크 쌍용3차)</p></td>
                    <td><p align='center'>032-624-1980</p></td>
                </tr>
                <tr>
                    <td width="75%"  colspan="2" height='30'><p align='center'><b>기술상담문의</b></p></td>
                    <td width="25%" height="0"><p align='center'>1577-9193</p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">※ A/S 택배 접수시 불량증상을 적어서 보내주시면 더욱 신속하게 처리됩니다.</td>
    </tr>
    <tr>
        <td colspan="2">※테두리가 진하게 표시된 네모박스안에 반드시 명기해 주세요.</td>
    </tr>
</table>

<p>&nbsp;</p>
