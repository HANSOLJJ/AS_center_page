<table  width='100%' cellpadding='0' cellspacing='0' border='0' align='center'>

<?

##### 
$instant_query = "SELECT s18_accid, s18_aiid, s18_uid, s18_quantity, s18_sp_cost, s18_asid FROM $db18 WHERE s18_aiid = '$my_s14_aiid'";
$instant_result = mysql_query($instant_query);
if(!$instant_result) {
   error("QUERY_ERROR");
   exit;
}
$instant_rows = mysql_num_rows($instant_result);
if($instant_rows > 0) {
$total_cost = '0';
   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   $my_s18_accid = $instant_reply->s18_accid;
	   $my_s18_aiid = $instant_reply->s18_aiid;
	   $my_s18_uid = $instant_reply->s18_uid;
	   $my_s18_quantity = $instant_reply->s18_quantity;
	   $my_s18_sp_cost = $instant_reply->s18_sp_cost;
	   $my_s18_asid = $instant_reply->s18_asid;


//------------------데이터 불러오기

$small_query1 = "SELECT s1_uid, s1_caid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1 FROM $db1 WHERE s1_uid = '$my_s18_uid'";
$small_result1 = mysql_query($small_query1);
if(!$small_result1) {
   error("QUERY_ERROR");
   exit;
}
$i++;
$small_row1 = mysql_fetch_row($small_result1);

$my_s1_uid = $small_row1[0];
$my_s1_caid = $small_row1[1];
$my_s1_erp = $small_row1[2];
$my_s1_name = $small_row1[3];


$my_s1_cost_c_1 = $small_row1[4];
$my_s1_cost_a_1 = $small_row1[5];
$my_s1_cost_a_2 = $small_row1[6];
$my_s1_cost_n_1 = $small_row1[7];
$my_s1_cost_n_2 = $small_row1[8];
$my_s1_cost_s_1 = $small_row1[9];

//------------------가격정보
if($my_s18_sp_cost ==""){

if($s11_sec =="일반"){$parts_cost = $my_s1_cost_n_2 * $my_s18_quantity; $my_cost=$my_s1_cost_n_2;}else
if($s11_sec =="대리점"){$parts_cost = $my_s1_cost_a_2 * $my_s18_quantity;$my_cost=$my_s1_cost_a_2;}else
if($s11_sec =="딜러"){$parts_cost = $my_s1_cost_s_1* $my_s18_quantity;$my_cost=$my_s1_cost_s_1;}else{
$parts_cost = "가격에러";}

} else{
	$parts_cost = $my_s1_cost_s_1;
	}


$my_cost = number_format($my_cost);	
$n_parts_cost = number_format($parts_cost );	
//------------------데이터 불러오기


print "	
<tr >
<td align='left'>
&nbsp;-&nbsp;$my_s1_name&nbsp;&nbsp;[$my_s1_erp]
</td>
<td align='right'>
<font color='red'><b>$my_s18_quantity&nbsp;개</b>&nbsp;</font><br>
 </td>
 <td align='right'>
<font color='red'><b>$my_cost</b>&nbsp;X $my_s18_quantity = $n_parts_cost </font>
";

//$total_cost = $total_cost + $parts_cost;

if($my_s18_sp_cost ==""){
print "
<a href='sp_cost.php?s18_accid=$my_s18_accid&s18_asid=$my_s18_asid&j_total_cost=$j_total_cost&number=$number'>★</a>";
} else{
print "
<a href='sp_cost2.php?s18_accid=$my_s18_accid&s18_asid=$my_s18_asid&j_total_cost=$j_total_cost&number=$number'>[정가]</a>";
}
 $total_cost = $total_cost + $parts_cost;


   }

}
$total_cost = $total_cost + 2500;
$total_cost = number_format($total_cost);
$total_cost = $total_cost."&nbsp;원";
print "
<br>
 </td>
 </tr>
	<tr><td colspan='3'><hr></td></tr>
 <tr>
 <td><b>총액</b></td><td colspan='2' align='right'>
<b>$total_cost</b>
 </td></tr>
 ";
?>
</table>
