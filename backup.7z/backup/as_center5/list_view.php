<?
if($reset=="on"){
$s_d = "";
$e_d = "";
}

if($this_time =="on"){
$now_time = time();
$s_year = date("Y", $now_time); 
$s_month = date("m", $now_time); 
$s_day = date("d", $now_time); 
$e_year = date("Y", $now_time); 
$e_month = date("m", $now_time); 
$e_day = date("d", $now_time); 
}

if($reset!="on"){
			$s_d = mktime(0,0,0,$s_month, $s_day, $s_year);
			$e_d = mktime(0,0,0,$e_month, $e_day+1, $e_year);
}


if($keyfield == "s13_as_in_no"){$sel1 ="selected"; }

#####라스트코드
//last_sec1 =센터정보
//s_year =시작년도
//s_month = 시작월
//s_day = 시작일
//e_year = 종료년도
//e_month = 종료월
//e_day = 종료일
//scode =코드번호

echo"<table  width='95%' cellpadding='10' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'><tr><td>";
####

$last_sec1 = $HTTP_SESSION_VARS["member_center_id"];
?>

<form name='form1' method="post" action="<?echo("list.php?in_code=list_view&page=$page&last_sec1=$last_sec1&keyfield=$keyfield&key=$key&reset=off");?>">
<b>검색기간</b> : &nbsp;
<?
$men_year = date("Y",time());	

$FIRST_DAY = "2010";		// 시작값
$LAST_DAY = $men_year;			// 마지막값
   echo "<select name='s_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
if($i == $s_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      
   }
   echo "</select> &nbsp;";

   echo "<select name='s_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $s_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}   
   }
   echo "</select> &nbsp;";

   echo "<select name='s_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $s_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>~
<?

$FIRST_DAY = "2010";		// 시작값
$LAST_DAY = $men_year;			// 마지막값
   echo "<select name='e_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
if($i == $e_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      
   }
   echo "</select> &nbsp;";

   echo "<select name='e_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $e_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}    
 
   }
   echo "</select> &nbsp;";

   echo "<select name='e_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $e_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";

?>

&nbsp;<input type='submit' STYLE='font-size:9pt;' value='검색'>
</form>
<?
echo("<a href=\"list.php?in_code=list_view&last_sec1=$last_sec1&this_time=on&keyfield=$keyfield&key=$key&reset=off\"><font color=red><b>[ 검색일자 오늘일자 입력 ]</b></font></a>&nbsp;");
?>
<hr height='1'>

<form method="post" action="<?echo("list.php?in_code=list_view&page=$page&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset")?>">

							<select name="keyfield" size="1" align='absmiddle' <?echo("$Form_style1");?>>
							<option value="">선택</option>
						   <option value="s13_as_in_no" <? echo"$sel1";?>>접수번호</option>
							</select>
							&nbsp;&nbsp;
							<input type="text" name="key" size='18' <?echo("$Form_style1");?> value="<?echo"$key";?>">&nbsp;
							<input type='submit' STYLE='font-size:9pt;' value='검색'>
							</td>
							
						</form>
<?
echo"</td></tr></table>";

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 25;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if($last_sec1 !=""){$s_date1="AND s13_as_center  = '$last_sec1'";$jcg1="1";}
if($s_d !="" AND $e_d ==""){$s_date2="AND s13_as_in_date >= '$s_d'";$jcg2="2";}else
if($s_d =="" AND $e_d !=""){$s_date2="AND s13_as_in_date <= '$e_d'";$jcg2="3";}else
if($s_d !="" AND $e_d !=""){$s_date2="AND s13_as_in_date BETWEEN '$s_d' AND '$e_d'";$jcg2="4";}
if($keyfield !=""){$s_date3="AND $keyfield LIKE '%$key%'";$jcg3="5";}

$temp_p ="SELECT count(*) FROM $db13  WHERE s13_as_level LIKE '5'";
$query = $temp_p.$s_date1.$s_date2.$s_date3;

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td width='50%' height='50' align='left'>
		<b>[ 해당 조건에 검색된 등록된 AS 정보 : <?echo"$total_record ";?> 건 ]</b>
		</td>
	</tr>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='5%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>No</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>입고정보<br>출고정보</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>업체명</b></p>
		</td>
		<td  width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>접수번호</b></p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>주소</b></p>
		</td>
		<td  width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>연락처</b></p>
		</td>
		<td  width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>비용합계</b></p>
		</td>
		<td width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>세부내역</b></p>
		</td>
	</tr>

<?

$time_limit = 60*60*24*$notify_new_article; 

#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
if($last_sec1 !=""){$s_date1="AND s13_as_center  = '$last_sec1'";$jcg1="1";}
if($s_d !="" AND $e_d ==""){$s_date2="AND s13_as_in_date >= '$s_d'";$jcg2="2";}else
if($s_d =="" AND $e_d !=""){$s_date2="AND s13_as_in_date <= '$e_d'";$jcg2="3";}else
if($s_d !="" AND $e_d !=""){$s_date2="AND s13_as_in_date BETWEEN '$s_d' AND '$e_d'";$jcg2="4";}
if($keyfield !=""){$s_date3="AND $keyfield LIKE '%$key%'";$jcg3="5";}

$temp_p2 ="SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how, s13_as_in_no, s13_meid, s13_dex_no, s13_total_cost, s13_sms1, s13_sms2, s13_bank_check, s13_tax_code, s13_dex_send, s13_dex_send_name, s13_as_out_date, ex_sec1, ex_company, ex_sms_no, ex_tel, ex_address FROM $db13 WHERE s13_as_level LIKE '5'";

$temp_p2_end ="ORDER BY s13_asid DESC LIMIT $first, $num_per_page";

$query = $temp_p2.$s_date1.$s_date2.$s_date3.$temp_p2_end;

$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

if($total_record=='0'){print"<tr><td height='200' colspan='20'><table width='600' align='center' cellspacing='0' cellpadding='0'  border='0' ><tr><td height='160'><p align='center'>등록된 데이터가 없습니다.</p></td></tr></table></td></tr>";}


##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s13_asid = $row[s13_asid];
$my_s13_as_center = $row[s13_as_center];
$my_s13_as_in_date =  date("y/m/d",$row[s13_as_in_date]);
$my_s13_as_in_how = $row[s13_as_in_how];
$my_s13_as_in_no = $row[s13_as_in_no];
$my_s13_meid = $row[s13_meid];
$my_s13_dex_no = $row[s13_dex_no];
$my_s13_total_cost = $row[s13_total_cost];

$my_s13_sms1 = $row[s13_sms1];
$my_s13_sms2 = $row[s13_sms2];
$my_s13_bank_check = $row[s13_bank_check];
$my_s13_tax_code = $row[s13_tax_code];
$my_s13_dex_send = $row[s13_dex_send];
$my_s13_dex_send_name = $row[s13_dex_send_name];
$my_s13_as_out_date = date("y/m/d",$row[s13_as_out_date]);

/// 추가--------------------------
$my_ex_sec1 = $row[ex_sec1];
$my_ex_company = $row[ex_company];
$my_ex_sms_no = $row[ex_sms_no];
$my_ex_tel = $row[ex_tel];
$my_ex_address = $row[ex_address];


//-----출고정보

if($my_s13_as_in_how =="택배"){$info_m1="택배($my_s13_dex_no)";}else 
if($my_s13_as_in_how =="퀵"){$info_m1="퀵";}else 
if($my_s13_as_in_how =="내방"){$info_m1="내방";}

if($s13_dex_send_name !=""){$info_m2= $my_s13_dex_send_name."-".$s13_dex_no;}else{$info_m2 ="내방";}

if($my_s13_as_out_date == ""){$my_s13_as_out_date ="&nbsp;";} else {$my_s13_as_out_date ="$my_s13_as_out_date";}



if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'"; $cell_color='#fbfbfb';}else{$td_bg="bgcolor='#FFFFFF'"; $cell_color='#FFFFFF';}
//--------------------------------------------------------------------
echo("<tr>");


##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg><table width='100%' border='0'><tr><td align='left'><b>$my_s13_as_in_date</b>-$info_m1<br><b>$my_s13_as_out_date</b>-$info_m2</td></tr></table></td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg><b>$my_ex_company</b><br>($my_ex_sec1)</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg>$my_s13_as_in_no</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg>$my_ex_address</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg>$my_ex_tel<br>($my_ex_sms_no)</td>");

echo("<td  align='center' valign='middle' $list_style1 $td_bg><font color='red'>");

include"add_sum_total_cost.php";

echo("</font></td>");


##### 

echo("<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=test&number=$my_s13_asid&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset&page=$page'><img src='../$icon_dir/button_blue_view_info.gif' border='0'></a></td>");

$article_num--;
}
echo("</table>");
?>

<table  width='95%' height='50' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>
<td  align='center' >

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php?in_code=list_view&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset&page=$my_page\">←</a>&nbsp;");
}




##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("<a href=\"list.php?in_code=list_view&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset&page=$direct_page\" >$direct_page</a>.&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php?in_code=list_view&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset&page=$my_page\" >→</a>");
}

?>
</td>
	</tr>
</table>

<p>&nbsp;</p>
<p>&nbsp;</p>