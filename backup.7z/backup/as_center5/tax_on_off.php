<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 

$query = "UPDATE $db13 SET s13_tax_code  = '$tax' WHERE s13_asid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

##### 리스트 출력화면으로 이동한다.

echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=test&number=$number&tax=$tax&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset&page=$page''>");   
   ?>