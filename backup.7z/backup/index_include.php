<?
include "@session_inc.php";
include "@config.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 愿由ъ 濡洹몄</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>

<script language="javascript">
   <!--
   function sendit2()  {
      if (!mainform2.as_id.value) {
         alert("대(ID)瑜 ν몄!");
         mainform2.as_id.focus();
         return;
      }
      if (!mainform2.as_passwd.value) {
         alert("鍮諛踰몃 ν몄!");
         mainform2.as_passwd.focus();
         return;
      }
      mainform2.submit();
   }
   
   function loginEnterDown() {
      if(event.keyCode==13)
         sendit2();
   }
   //-->
</script>

</head>

<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0'>

<table cellpadding='0' cellspacing='0' width='100%' height='100%' valign='top'>
    <tr>
        <td>
<form name='mainform2' method='POST' action='as_login_process.php' target='_parent'>

				<table width='620' height='110' border=0 cellpadding=0 cellspacing=0 align='center' background='<? echo("$icon_dir"); ?>/bg_as_login.png'>
					<tr>
						<td width='620' height='50' colspan='5'>
                            <p>&nbsp;</p>
						</td>
					</tr>
					<tr>
						<td width='119' height='44'>
                            <p>&nbsp;</p>
						</td>
						<td width='131' height='44'>
                            <p><input type='text' name='as_id' size='15' maxlength='15' onKeyDown='javascript:loginEnterDown();' style='background-color:#ffffff;border:1 solid #00bcff; width:120; height:19; font-size:9pt;'></p>
						</td>
						<td width='69' height='44'>
                            <p>&nbsp;</p>
						</td>
						<td width='131' height='44'>
                            <p><input type='password' name='as_passwd' size='15' maxlength='15' onKeyDown='javascript:loginEnterDown();' style='background-color:#ffffff;border:1 solid #00bcff; width:120; height:19; font-size:9pt;'></p>
						</td>
						<td width='170' height='44'>
                          <p>&nbsp;<A href='javascript:sendit2()'><img src='<? echo("$icon_dir/button_blue_login.gif");?>' border='0'></a></p>
						</td>
					</tr>
					<tr>
						<td width='620' colspan='5'>
                            <p>&nbsp;</p>
						</td>
					</tr>
				</table>
				</form>




        </td>
    </tr>
</table>


</body>
                            <p>&nbsp;</p>
						</td>
					</tr>
				</table>
				</form>




        </td>
    </tr>
</table>


</body>