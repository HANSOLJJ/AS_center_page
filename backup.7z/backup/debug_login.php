<?php
/**
 * AS System - Login Debug
 * 로그인 프로세스 디버깅
 */

header('Content-Type: text/html; charset=utf-8');

// MySQL 호환성 레이어 로드 (PHP 7.4+ 지원)
require_once '@session_inc.php';

session_start();

$id = 'raintrace';
$passwd = 'raintrace';

// DB 연결 정보
$mysql_host = 'mysql';
$mysql_user = 'mic4u_user';
$mysql_pwd  = 'change_me';
$mysql_db   = 'mic4u';

echo "<h2>로그인 디버그 정보</h2>";
echo "<pre>";

// DB 연결 시도
echo "1. DB 연결 시도...\n";
$connect = mysql_connect($mysql_host, $mysql_user, $mysql_pwd);
if ($connect) {
    echo "   ✓ DB 연결 성공\n";
    
    // DB 선택
    echo "2. DB 선택...\n";
    if (mysql_select_db($mysql_db, $connect)) {
        echo "   ✓ DB 선택 성공\n";
        
        // 관리자 조회
        echo "3. 관리자 조회 ($id)...\n";
        $result = mysql_query("SELECT passwd, userlevel FROM 2010_admin_member WHERE id = '$id'");
        if ($result) {
            echo "   ✓ 쿼리 성공\n";
            
            $rows = mysql_num_rows($result);
            echo "   - 조회된 행: $rows\n";
            
            if ($rows > 0) {
                $row = mysql_fetch_object($result);
                $db_passwd = $row->passwd;
                $db_userlevel = $row->userlevel;
                
                echo "   - ID: $id\n";
                echo "   - 저장된 비밀번호: $db_passwd (길이: " . strlen($db_passwd) . ")\n";
                echo "   - 레벨: $db_userlevel\n";
                
                // 비밀번호 암호화
                echo "4. 비밀번호 암호화...\n";
                $result = mysql_query("SELECT password('$passwd')");
                if ($result) {
                    echo "   ✓ PASSWORD() 함수 실행 성공\n";
                    
                    $user_passwd = mysql_result($result, 0, 0);
                    echo "   - PASSWORD('$passwd'): $user_passwd\n";
                    echo "   - 길이: " . strlen($user_passwd) . "\n";
                    
                    // 16자로 잘라내기
                    if (strlen($db_passwd) <= 16) {
                        $user_passwd_truncated = substr($user_passwd, 0, 16);
                        echo "   - 16자로 잘라낸 값: $user_passwd_truncated\n";
                        
                        // 비교
                        echo "5. 비밀번호 비교...\n";
                        echo "   - 저장된 값: $db_passwd\n";
                        echo "   - 입력한 값: $user_passwd_truncated\n";
                        echo "   - 일치: " . (strcmp($db_passwd, $user_passwd_truncated) === 0 ? "YES" : "NO") . "\n";
                    }
                } else {
                    echo "   ✗ PASSWORD() 함수 실행 실패\n";
                }
            } else {
                echo "   ✗ 해당 ID를 찾을 수 없습니다\n";
            }
        } else {
            echo "   ✗ 쿼리 실패\n";
        }
    } else {
        echo "   ✗ DB 선택 실패\n";
    }
} else {
    echo "   ✗ DB 연결 실패\n";
}

echo "</pre>";

mysql_close();
?>
