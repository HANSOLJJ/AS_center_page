<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

//$query = "select * into outfile '엑셀파일.xls' from $db13;"
//$query = "select * from $db13 into outfile '/www/@@as/as/result$db13' fields terminated by ',';";

$query = "SELECT * INTO OUTFILE '/www/@@as/as/result/asda.txt'  fields terminated by '|'  FROM $db13;";
mysql_query($query);





?>
