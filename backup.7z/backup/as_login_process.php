<?
include "@config.php";
include "@error_function.php";


##### 대(ID) 理 5, 理 10 臾몄 レ媛 議고⑸ 臾몄댁댁댁 .
if(!ereg("[[:alnum:]+]{5,10}",$as_id)) {
   error("NOT_ALLOWED_ID");
   exit;
}

##### 鍮諛踰몃 理 4, 理 8 臾몄 レ媛 議고⑸ 臾몄댁댁댁 .
if(!ereg("[[:alnum:]+]{4,8}",$as_passwd)) {
   error("NOT_ALLOWED_PASSWD");
   exit;
}

##### 濡洹몄명湲  ν 대 鍮諛踰멸 쇱 肄瑜 寃.
$result = mysql_query("SELECT s3_passwd, s3_userlevel, s3_center_id, s3_name FROM step3_member WHERE s3_id = '$as_id'");
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$rows = mysql_num_rows($result);

##### 쇱 蹂닿  寃쎌
if (!$rows) {
   error("LOGIN_ID_NOT_FOUND");
   exit;
} else {

##### 蹂닿  寃쎌 鍮諛踰 媛 媛몄⑤.
$row = mysql_fetch_object($result);

$db_passwd = $row->s3_passwd;
$db_userlevel = $row->s3_userlevel;
$db_center_id = $row->s3_center_id;
$db_s3_name = $row->s3_name;
   
##### ъ⑹媛 ν 鍮諛踰몃 명.
$result = mysql_query("SELECT password('$as_passwd')");
$user_passwd = mysql_result($result,0,0);
 
#####  鍮諛踰몃 鍮援 쇱硫 몄 깊.

if(strcmp($db_passwd,$user_passwd)) {      
  error("LOGIN_INVALID_PW");
  exit;
} else {
   
      if(headers_sent()) {
         error("HTTP_HEADERS_SENT");
         exit;      
      } else {      
      
setcookie("member_id","",0,"/");
setcookie("member_sid","",0,"/");
setcookie("member_email","",0,"/");
setcookie("member_name","",0,"/");
setcookie("member_level","",0,"/");
setcookie("member_center_id","",0,"/");

     ##### 몄 깊.
         session_start();    
         ##### 깅 몄 곗댄곕 ν 몄 蹂瑜 깅.
         session_register("member_id", "member_sid", "member_name", "member_level", "member_center_id");

         ##### 깅 몄 蹂 곗댄곕 ν.
         $member_id = $as_id;
         $member_level = $db_userlevel;
         $member_sid = session_id();
		 $member_center_id = $db_center_id;
		 $member_name = $db_s3_name;
      }


mysql_close();

}

}
echo ("<meta http-equiv='Refresh' content='0; URL=test_menu_as.php'>");

?>