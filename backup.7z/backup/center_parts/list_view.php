
<?

//------------------센터명 부르기

$search_query = "Select s5_caid, s5_category  FROM $db5 ORDER BY s5_caid ASC";
$search_result= mysql_query($search_query);

if (!$search_result) {
   error("QUERY_ERROR");
   exit;
}

$pa =0;

while($search_row = mysql_fetch_array($search_result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $pa++;
   $search_s5_caid = $search_row[s5_caid];
   $search_s5_category = $search_row[s5_category];

if(($pa % 10)  =="1"){echo"<br>";}
if($search_s5_category  == $s5_category_s){$font_color ="#FF0000";}else{$font_color ="#000000";}
echo("<a href=\"list.php?in_code=list.php?in_code=list_view&in_code=list_view&keyfield=s1_caid&key=$search_s5_caid\"><font color=$font_color><b>[ $search_s5_category ]</b></font></a>&nbsp;");


}

echo("</td></tr></table>");

?>

<br>
<br>


<?
$center_id_s = $HTTP_SESSION_VARS["member_center_id"];

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 30;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if(!eregi("[^[:space:]]+",$key)) {
	$query = "SELECT count(*) FROM $db";
} else {
   $encoded_key = urlencode($key);
   $query = "SELECT count(*) FROM $db WHERE $keyfield LIKE '%$key%'";  
}

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}

?>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='5%' height='50' background="<?echo "$border_bg1";?>" rowspan='2'>
		<p align='center'><b>No</b></p>
		</td>
		<td  width="5%"  background="<?echo "$border_bg1";?>" rowspan="2">
		<p align='center'><b>ERP CODE</b></p>
		</td>
		<td  width="5%" background="<?echo "$border_bg1";?>" rowspan="2">
		<p align='center'><b>자재명</b></p>
		</td>
		<td width="5%" background="<?echo "$border_bg1";?>" rowspan="2">
		<p align='center'><b>재고</b></p>
		</td>
		<td width="5%"background="<?echo "$border_bg1";?>" rowspan="2">
         <p align='center'><b>A/S CENTER 공급가</b></p>
		</td>
		<td background="<?echo "$border_bg1";?>" colspan="2">
        <p align='center'><b>대리점 공급가</b></p>
		</td>
		<td background="<?echo "$border_bg1";?>"colspan="2">
         <p align='center'><b>일반 판매</b></p>
		</td>
		<td width="5%" background="<?echo "$border_bg1";?>" rowspan="2">
        <p align='center'><b>특별공급가</b></p>
		</td>
	</tr>	
	<tr>
		<td width='5%' background="<?echo "$border_bg1";?>">
        <p align='center'><b>개별판매</b></p>
		</td>
		<td width='5%' background="<?echo "$border_bg1";?>">
         <p align='center'><b>수리시</b></p>
		</td>
		<td width='5%' background="<?echo "$border_bg1";?>">
         <p align='center'><b>개별판매</b></p>
		</td>
		<td width='5%' background="<?echo "$border_bg1";?>">
        <p align='center'><b>수리시</b></p>
		</td>
	</tr>
<?

$time_limit = 60*60*24*$notify_new_article; 

#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
if(!eregi("[^[:space:]]+",$key)) {
		$query = "SELECT s1_uid, s1_erp,s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1 FROM $db ORDER BY s1_uid DESC LIMIT $first, $num_per_page";
} else {
   $query = "SELECT s1_uid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1 FROM $db WHERE $keyfield LIKE '%$key%' ORDER BY s1_uid DESC LIMIT $first, $num_per_page";
}
$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

if($total_record=='0'){print"<tr><td height='200' colspan='10'><table width='600' align='center' cellspacing='0' cellpadding='0'  border='0' ><tr><td height='160'><p align='center'>등록된 데이터가 없습니다.</p></td></tr></table></td></tr>";}


##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s1_uid = $row[s1_uid];
   $my_s1_erp = $row[s1_erp];
   $my_s1_name = $row[s1_name];
   $my_s1_cost_c_1 = $row[s1_cost_c_1];
   $my_s1_cost_a_1 = $row[s1_cost_a_1];
   $my_s1_cost_a_2 = $row[s1_cost_a_2];
   $my_s1_cost_n_1 = $row[s1_cost_n_1];
   $my_s1_cost_n_2 = $row[s1_cost_n_2];
   $my_s1_cost_s_1 = $row[s1_cost_s_1];
  
//------------------센터 재고 부르기

$instant_query = "Select s7_num FROM $db7 WHERE s7_center_id ='$center_id_s' AND s7_uid ='$my_s1_uid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $center_num=$instant_reply->s7_num;
	
   }

}else{$center_num='0';}




  
##### 원칙상 제목에는 HTML 태그를 허용하지 않는다.
$my_s1_name = htmlspecialchars($my_s1_name);

## 숫자 쉼표

$my_s1_cost_c_1 = number_format($my_s1_cost_c_1); 
$my_s1_cost_a_1 = number_format($my_s1_cost_a_1); 
$my_s1_cost_a_2 = number_format($my_s1_cost_a_2); 
$my_s1_cost_n_1 = number_format($my_s1_cost_n_1); 
$my_s1_cost_n_2 = number_format($my_s1_cost_n_2); 
$my_s1_cost_s_1 = number_format($my_s1_cost_s_1); 

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}
//--------------------------------------------------------------------
echo("<tr>");

##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_erp</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_name</td>");

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$center_num</td>");

##### 가격

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_cost_c_1</td>");

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_cost_a_1</td>");

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_cost_a_2</td>");

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_cost_n_1</td>");

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_cost_n_2</td>");

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_s1_cost_s_1</td>");

$article_num--;
}
echo("</table>");
?>
<br>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>
<form method="post" action="<?echo("list.php?in_code=$in_code&in_mode=$in_mode&center_id_s=$center_id_s")?>">


							
							<td width='280' height='35'>
							<select name="keyfield" size="1" align='absmiddle' <?echo("$Form_style1");?>>
							   <option value="s1_name">자재명</option>
							   <option value="s1_erp">ERP CODE</option>
							</select>
							&nbsp;&nbsp;
							<input type="text" name="key" size='18' <?echo("$Form_style1");?>>&nbsp;&nbsp;&nbsp;
							<input type='submit' STYLE='font-size:9pt;' value='검색'>
							</td>
							
						</form>
							<td  align='center'>

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&keyfield=$keyfield&key=$key\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("<a href=\"list.php?in_code=list_view&page=$direct_page&keyfield=$keyfield&key=$key\" >$direct_page</a>.&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&keyfield=$keyfield&key=$key\" >→</a>");
}

?>



<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td>

<?
if($HTTP_SESSION_VARS["member_id"] !="" AND $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "1"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "2"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "3"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";}
?>
		</td>
	</tr>
</table>