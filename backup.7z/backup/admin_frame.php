<?
include "@config.php";
include "@error_function.php";
include "@access.php";

$admin_ip = getenv('REMOTE_ADDR');
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 뱀ъ댄 愿由ы</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>
</head>

<script language="javascript">
var old_menu = '';
var old_cell = '';

function menuclick( submenu ,cellbar)
{
  if( old_menu != submenu ) {
    if( old_menu !='' ) {
      old_menu.style.display = 'none';
	  old_cell.src= 'admin_menu_arrow_close.gif';
    }
    submenu.style.display = 'block';
    cellbar.src = 'admin_menu_arrow_open.gif';
    old_menu = submenu;
    old_cell = cellbar;

  } else {
    submenu.style.display = 'none';
    cellbar.src= 'admin_menu_arrow_close.gif';
    old_menu = '';
    old_cell = '';
  }
}
</script>


<?echo $HTTP_SESSION_VARS["member_id"] ?>
<?echo $HTTP_SESSION_VARS["member_level"] ?>

<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0'>

<table width='100%' Height='100%' border='0' cellpadding='0' cellspacing='0' align='center' >
	<tr>
		<td width='250'>
		</td>
		<td>

		<iframe name="admin_target" src="welcome.php" width="100%" height="100%" scrolling='auto' marginwidth="0" marginheight="0" frameborder="no"></iframe>

		</td>
	</tr>
</table>


<script>
if (!document.layers)
document.write('<div id="divStayTopLeft" style="position:absolute">')
</script>

<layer id="divStayTopLeft" >

<!--EDIT BELOW CODE TO YOUR OWN MENU-->

<table width='250' border='0' cellpadding='0' cellspacing='0'>
	<tr>
		<td height='140' background='<? echo("$icon_dir"); ?>/bg_admin_title.png' style='padding-left:20px;'>
		<SPAN class='admin_menu_name'><? echo("$admin_name");?></span> 		
		</td>
	</tr>
</table>

<?
if($HTTP_SESSION_VARS["member_level"] =="0"){include"admin_menu_center.php";}else
if($HTTP_SESSION_VARS["member_level"] =="2"){include"admin_menu.php";}else
if($HTTP_SESSION_VARS["member_level"] =="3"){include"admin_menu_raintrace.php";}
?>


<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="logout.php"> 濡洹몄</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>




<!--END OF EDIT-->

</layer>


<script type="text/javascript">



//Enter "frombottom" or "fromtop"
var verticalpos="fromtop"

if (!document.layers)
document.write('</div>')

function JSFX_FloatTopDiv()
{
	var startX = 0,
	startY = 0;
	var ns = (navigator.appName.indexOf("Netscape") != -1);
	var d = document;
	function ml(id)
	{
		var el=d.getElementById?d.getElementById(id):d.all?d.all[id]:d.layers[id];
		if(d.layers)el.style=el;
		el.sP=function(x,y){this.style.left=x;this.style.top=y;};
		el.x = startX;
		if (verticalpos=="fromtop")
		el.y = startY;
		else{
		el.y = ns ? pageYOffset + innerHeight : document.body.scrollTop + document.body.clientHeight;
		el.y -= startY;
		}
		return el;
	}
	window.stayTopLeft=function()
	{
		if (verticalpos=="fromtop"){
		var pY = ns ? pageYOffset : document.body.scrollTop;
		ftlObj.y += (pY + startY - ftlObj.y)/8;
		}
		else{
		var pY = ns ? pageYOffset + innerHeight : document.body.scrollTop + document.body.clientHeight;
		ftlObj.y += (pY - startY - ftlObj.y)/8;
		}
		ftlObj.sP(ftlObj.x, ftlObj.y);
		setTimeout("stayTopLeft()", 10);
	}
	ftlObj = ml("divStayTopLeft");
	stayTopLeft();
}
JSFX_FloatTopDiv();
</script>