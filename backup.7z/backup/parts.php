<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

// 로그인 확인
if (empty($_SESSION['member_id']) || empty($_SESSION['member_sid'])) {
    header('Location: login.php');
    exit;
}

// MySQL 호환성 레이어 로드
require_once 'mysql_compat.php';

// 데이터베이스 연결
$connect = mysql_connect('mysql', 'mic4u_user', 'change_me');
mysql_select_db('mic4u', $connect);

$user_name = $_SESSION['member_id'];
$current_page = 'parts';

// 현재 탭 설정
$current_tab = isset($_GET['tab']) ? $_GET['tab'] : 'tab1';
$success_message = '';

// 삭제 완료 체크
if (isset($_GET['deleted']) && $_GET['deleted'] === '1') {
    if ($current_tab === 'tab1') {
        $success_message = 'AS 자재가 정상적으로 삭제되었습니다.';
    } elseif ($current_tab === 'tab2') {
        $success_message = '카테고리가 정상적으로 삭제되었습니다.';
    }
}

// 페이지네이션 설정
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// 검색 조건
$search_type = isset($_GET['search_type']) ? $_GET['search_type'] : 'all';
$search_keyword = isset($_GET['search_keyword']) ? trim($_GET['search_keyword']) : '';

// 탭별 데이터 처리
$tab_info = array(
    'tab1' => array('name' => 'AS 자재 관리', 'table' => 'step1_parts', 'button_text' => '새 자재 등록', 'add_link' => 'parts_add.php'),
    'tab2' => array('name' => '자재 카테고리 관리', 'table' => 'step5_category', 'button_text' => '새 카테고리 등록', 'add_link' => 'category_add.php'),
    'tab3' => array('name' => '탭3', 'table' => '', 'button_text' => '새 항목 등록', 'add_link' => '#'),
    'tab4' => array('name' => '탭4', 'table' => '', 'button_text' => '새 항목 등록', 'add_link' => '#'),
    'tab5' => array('name' => '탭5', 'table' => '', 'button_text' => '새 항목 등록', 'add_link' => '#'),
);

// 현재 탭 정보
$tab_config = $tab_info[$current_tab];
$table = $tab_config['table'];
$show_table = !empty($table);

// 탭별 데이터 처리
$where = "1=1";

// 검색 조건 추가
if ($show_table && !empty($search_keyword)) {
    $search_keyword_esc = mysql_real_escape_string($search_keyword);
    if ($current_tab === 'tab1') {
        if ($search_type === 'name') {
            $where .= " AND p.s1_name LIKE '%" . $search_keyword_esc . "%'";
        } elseif ($search_type === 'category') {
            $where .= " AND c.s5_category LIKE '%" . $search_keyword_esc . "%'";
        } else {
            $where .= " AND (p.s1_name LIKE '%" . $search_keyword_esc . "%' OR c.s5_category LIKE '%" . $search_keyword_esc . "%')";
        }
    } elseif ($current_tab === 'tab2') {
        $where .= " AND s5_category LIKE '%" . $search_keyword_esc . "%'";
    }
}

// 데이터 초기화
$total_count = 0;
$total_pages = 0;
$result = null;

// 테이블이 설정된 경우만 쿼리 실행
if ($show_table && !empty($table)) {
    if ($current_tab === 'tab1') {
        // 자재 데이터 처리
        $count_result = mysql_query("
            SELECT COUNT(*) as cnt FROM step1_parts p
            LEFT JOIN step5_category c ON p.s1_caid = c.s5_caid
            WHERE $where
        ");
        $count_row = mysql_fetch_assoc($count_result);
        $total_count = $count_row['cnt'];
        $total_pages = ceil($total_count / $limit);

        $result = mysql_query("
            SELECT p.s1_uid, p.s1_name, p.s1_caid, c.s5_category, p.s1_cost_c_1, 
                   p.s1_cost_a_1, p.s1_cost_a_2, p.s1_cost_n_1, p.s1_cost_n_2, p.s1_cost_s_1
            FROM step1_parts p
            LEFT JOIN step5_category c ON p.s1_caid = c.s5_caid
            WHERE $where
            ORDER BY p.s1_uid DESC
            LIMIT $offset, $limit
        ");
    } elseif ($current_tab === 'tab2') {
        // 카테고리 데이터 처리
        $count_result = mysql_query("
            SELECT COUNT(*) as cnt FROM step5_category
            WHERE $where
        ");
        $count_row = mysql_fetch_assoc($count_result);
        $total_count = $count_row['cnt'];
        $total_pages = ceil($total_count / $limit);

        $result = mysql_query("
            SELECT s5_caid, s5_category
            FROM step5_category
            WHERE $where
            ORDER BY s5_caid DESC
            LIMIT $offset, $limit
        ");
    }
}

// 자동완성 데이터 조회 (AJAX 요청일 경우)
if (isset($_GET['action']) && $_GET['action'] === 'autocomplete') {
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    $type = isset($_GET['type']) ? $_GET['type'] : 'name';
    
    header('Content-Type: application/json; charset=utf-8');
    
    $suggestions = array();
    if (!empty($q)) {
        if ($type === 'name') {
            $query = "SELECT DISTINCT s1_name FROM step1_parts WHERE s1_name LIKE '%" . mysql_real_escape_string($q) . "%' LIMIT 10";
        } elseif ($type === 'category') {
            $query = "SELECT DISTINCT s5_category FROM step5_category WHERE s5_category LIKE '%" . mysql_real_escape_string($q) . "%' LIMIT 10";
        }
        
        if (isset($query)) {
            $res = mysql_query($query);
            while ($row = mysql_fetch_assoc($res)) {
                $field = $type === 'name' ? 's1_name' : 's5_category';
                $suggestions[] = array(
                    'value' => $row[$field],
                    'label' => $row[$field]
                );
            }
        }
    }
    
    echo json_encode($suggestions);
    exit;
}

// AJAX 삭제 요청 처리
if (isset($_POST['action']) && $_POST['action'] === 'delete') {
    header('Content-Type: application/json; charset=utf-8');
    
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $tab = isset($_POST['tab']) ? $_POST['tab'] : 'tab1';
    $success = false;
    $message = '삭제에 실패했습니다.';
    
    if ($id > 0) {
        if ($tab === 'tab1') {
            if (mysql_query("DELETE FROM step1_parts WHERE s1_uid = $id")) {
                $success = true;
                $message = 'AS 자재가 정상적으로 삭제되었습니다.';
            }
        } elseif ($tab === 'tab2') {
            if (mysql_query("DELETE FROM step5_category WHERE s5_caid = '$id'")) {
                $success = true;
                $message = '카테고리가 정상적으로 삭제되었습니다.';
            }
        }
    }
    
    echo json_encode(array('success' => $success, 'message' => $message));
    exit;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>자재 관리 - AS 시스템</title>
    <link rel="stylesheet" href="jqu/jquery.autocomplete.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f6fa; color: #333; font-size: 14px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 24px; }
        .header-right { display: flex; gap: 20px; align-items: center; }
        .logout-btn { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border: 1px solid white; border-radius: 5px; cursor: pointer; }
        .logout-btn:hover { background: white; color: #667eea; }
        .nav-bar { background: white; padding: 0; border-bottom: 2px solid #ddd; display: flex; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .nav-item { padding: 15px 25px; text-decoration: none; color: #666; font-size: 14px; font-weight: 500; transition: all 0.3s; border-bottom: 3px solid transparent; }
        .nav-item:hover { background: #f5f5f5; color: #667eea; }
        .nav-item.active { color: #667eea; border-bottom-color: #667eea; background: #f9f9ff; }
        .container { padding: 40px; max-width: 1400px; margin: 0 auto; }
        .content { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        h2 { color: #667eea; margin-bottom: 20px; }

        .tabs { display: flex; gap: 0; margin-bottom: 30px; border-bottom: 2px solid #ddd; }
        .tab-button { padding: 12px 24px; background: #f0f0f0; border: none; cursor: pointer; font-size: 14px; font-weight: 500; color: #666; transition: all 0.3s; border-radius: 5px 5px 0 0; }
        .tab-button:hover { background: #e0e0e0; }
        .tab-button.active { background: #667eea; color: white; border-bottom: 3px solid #667eea; }

        .message { padding: 12px 16px; border-radius: 5px; margin-bottom: 20px; font-size: 14px; background: #efe; border: 1px solid #9f9; color: #3c3; }
        .message.error { background: #fee; border-color: #f99; color: #c33; }

        .search-box { background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; gap: 10px; align-items: flex-end; flex-wrap: wrap; }
        .search-box select, .search-box input { padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; }
        .search-box input { flex: 1; min-width: 200px; }
        .search-box button { padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; }
        .search-box button:hover { background: #764ba2; }

        .action-buttons { display: flex; gap: 10px; margin-bottom: 20px; }
        .register-btn { padding: 10px 20px; background: #27ae60; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; }
        .register-btn:hover { background: #229954; }
        .register-btn:disabled { opacity: 0.6; cursor: not-allowed; }

        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; table-layout: fixed; border: 1px solid #ddd; }
        th, td { padding: 12px; text-align: center; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; word-wrap: break-word; font-size: 14px; }
        th:last-child, td:last-child { border-right: none; }
        th { background: #f0f4ff; color: #667eea; font-weight: 600; }
        tr:hover { background: #f9f9f9; }

        .header-sub { background: #f5f8ff; color: #667eea; font-weight: 500; border-bottom: 1px solid #ddd; }

        .action-link { padding: 5px 10px; margin: 0 3px; text-decoration: none; border-radius: 3px; display: inline-block; font-size: 12px; cursor: pointer; }
        .edit-link { background: #3498db; color: white; }
        .edit-link:hover { background: #2980b9; }
        .delete-link { background: #e74c3c; color: white; }
        .delete-link:hover { background: #c0392b; }

        .pagination { text-align: center; margin-top: 20px; }
        .pagination a, .pagination span { padding: 8px 12px; margin: 0 3px; text-decoration: none; border: 1px solid #ddd; border-radius: 3px; display: inline-block; }
        .pagination a:hover { background: #667eea; color: white; }
        .pagination .current { background: #667eea; color: white; border-color: #667eea; }

        .info-text { color: #666; margin-bottom: 10px; font-size: 14px; }
        
        .blockUI { background: rgba(0, 0, 0, 0.6); }
        .blockMsg { background: white; border: 1px solid #ddd; border-radius: 5px; padding: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .blockMsg h2 { color: #667eea; margin-bottom: 10px; font-size: 16px; }

        .price-cell { text-align: center; font-size: 16px; }

        .empty-state { padding: 40px; text-align: center; color: #999; }
        .empty-state p { margin-bottom: 10px; font-size: 14px; }
        .empty-state strong { display: block; margin-top: 15px; color: #667eea; font-size: 14px; }
    </style>
</head>
<body>
    <script src="jqu/jquery-1.4.2.min.js"></script>
    <script src="jqu/jquery.autocomplete.js"></script>
    <script src="jqu/jquery.blockUI.js"></script>

    <div class="header">
        <h1>디지탈컴 AS 시스템</h1>
        <div class="header-right">
            <span><?php echo htmlspecialchars($user_name); ?>님</span>
            <form method="POST" action="logout.php" style="margin: 0;">
                <button type="submit" class="logout-btn">로그아웃</button>
            </form>
        </div>
    </div>

    <div class="nav-bar">
        <a href="dashboard.php" class="nav-item">대시보드</a>
        <a href="as_requests.php" class="nav-item">수리 내역</a>
        <a href="orders.php" class="nav-item">소모품 판매</a>
        <a href="parts.php" class="nav-item <?php echo $current_page === 'parts' ? 'active' : ''; ?>">자재 관리</a>
        <a href="members.php" class="nav-item">고객 관리</a>
        <a href="products.php" class="nav-item">제품 관리</a>
    </div>

    <div class="container">
        <div class="content">
            <h2>📦 자재 관리</h2>

            <div class="tabs">
                <button class="tab-button <?php echo $current_tab === 'tab1' ? 'active' : ''; ?>" onclick="location.href='parts.php?tab=tab1'">AS 자재 관리</button>
                <button class="tab-button <?php echo $current_tab === 'tab2' ? 'active' : ''; ?>" onclick="location.href='parts.php?tab=tab2'">자재 카테고리 관리</button>
                <button class="tab-button <?php echo $current_tab === 'tab3' ? 'active' : ''; ?>" onclick="location.href='parts.php?tab=tab3'">탭3</button>
                <button class="tab-button <?php echo $current_tab === 'tab4' ? 'active' : ''; ?>" onclick="location.href='parts.php?tab=tab4'">탭4</button>
                <button class="tab-button <?php echo $current_tab === 'tab5' ? 'active' : ''; ?>" onclick="location.href='parts.php?tab=tab5'">탭5</button>
            </div>

            <?php if (!empty($success_message)): ?>
            <div class="message">
                ✓ <?php echo htmlspecialchars($success_message); ?>
            </div>
            <?php endif; ?>

            <form method="GET" class="search-box" id="search-form">
                <input type="hidden" name="tab" value="<?php echo htmlspecialchars($current_tab); ?>">
                <?php if ($current_tab === 'tab1'): ?>
                <select name="search_type" id="search_type">
                    <option value="all" <?php echo $search_type === 'all' ? 'selected' : ''; ?>>전체</option>
                    <option value="name" <?php echo $search_type === 'name' ? 'selected' : ''; ?>>자재명</option>
                    <option value="category" <?php echo $search_type === 'category' ? 'selected' : ''; ?>>카테고리</option>
                </select>
                <?php endif; ?>
                <input type="text" id="search_keyword" name="search_keyword" placeholder="검색어를 입력하세요" value="<?php echo htmlspecialchars($search_keyword); ?>">
                <button type="submit">검색</button>
                <a href="parts.php?tab=<?php echo htmlspecialchars($current_tab); ?>" style="padding: 10px 20px; background: #95a5a6; color: white; border-radius: 5px; text-decoration: none;">초기화</a>
            </form>

            <div class="action-buttons">
                <button class="register-btn" onclick="location.href='<?php echo $tab_config['add_link']; ?>'" <?php echo ($tab_config['add_link'] === '#') ? 'disabled' : ''; ?>>+ <?php echo $tab_config['button_text']; ?></button>
            </div>

            <div class="info-text">
                총 <?php echo $total_count; ?>개의 항목 (페이지: <?php echo $page; ?>/<?php echo max(1, $total_pages); ?>)
            </div>

            <table id="data-table">
                <thead>
                    <tr>
                        <?php if ($current_tab === 'tab1'): ?>
                            <th style="width: 4%;">번호</th>
                            <th style="width: 12%;">자재명</th>
                            <th style="width: 8%;">카테고리</th>
                            <th style="width: 10%;">AS center 공급가</th>
                            <th colspan="2" style="width: 14%;">대리점 공급가</th>
                            <th colspan="2" style="width: 14%;">일반판매 공급가</th>
                            <th style="width: 8%;">특별공급가</th>
                            <th style="width: 8%;">관리</th>
                        <?php elseif ($current_tab === 'tab2'): ?>
                            <th style="width: 10%;">번호</th>
                            <th style="width: 15%;">ID</th>
                            <th style="width: 50%;">카테고리명</th>
                            <th style="width: 25%;">관리</th>
                        <?php else: ?>
                            <th style="width: 20%;">항목1</th>
                            <th style="width: 20%;">항목2</th>
                            <th style="width: 20%;">항목3</th>
                            <th style="width: 20%;">항목4</th>
                            <th style="width: 20%;">관리</th>
                        <?php endif; ?>
                    </tr>
                    <?php if ($current_tab === 'tab1'): ?>
                    <tr>
                        <th style="width: 4%;"></th>
                        <th style="width: 12%;"></th>
                        <th style="width: 8%;"></th>
                        <th style="width: 10%;"></th>
                        <th class="header-sub" style="width: 7%;">개별판매</th>
                        <th class="header-sub" style="width: 7%;">수리시</th>
                        <th class="header-sub" style="width: 7%;">개별판매</th>
                        <th class="header-sub" style="width: 7%;">수리시</th>
                        <th style="width: 8%;"></th>
                        <th style="width: 8%;"></th>
                    </tr>
                    <?php endif; ?>
                </thead>
                <tbody>
                    <?php
                    if ($show_table && $result && mysql_num_rows($result) > 0) {
                        if ($current_tab === 'tab1') {
                            while ($row = mysql_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td style='width: 4%;'>" . htmlspecialchars($row['s1_uid']) . "</td>";
                                echo "<td style='width: 12%;'>" . htmlspecialchars($row['s1_name']) . "</td>";
                                echo "<td style='width: 8%;'>" . htmlspecialchars($row['s5_category'] ?: '미분류') . "</td>";
                                echo "<td class='price-cell' style='width: 10%;'>" . number_format($row['s1_cost_c_1']) . "</td>";
                                echo "<td class='price-cell' style='width: 7%;'>" . number_format($row['s1_cost_a_1']) . "</td>";
                                echo "<td class='price-cell' style='width: 7%;'>" . number_format($row['s1_cost_a_2']) . "</td>";
                                echo "<td class='price-cell' style='width: 7%;'>" . number_format($row['s1_cost_n_1']) . "</td>";
                                echo "<td class='price-cell' style='width: 7%;'>" . number_format($row['s1_cost_n_2']) . "</td>";
                                echo "<td class='price-cell' style='width: 8%;'>" . number_format($row['s1_cost_s_1']) . "</td>";
                                echo "<td style='width: 8%;'>";
                                echo "<a href='parts_edit.php?id=" . $row['s1_uid'] . "' class='action-link edit-link'>수정</a>";
                                echo "<a href='#' class='action-link delete-link delete-btn' data-id='" . $row['s1_uid'] . "' onclick='return deleteItem(this);'>삭제</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } elseif ($current_tab === 'tab2') {
                            $row_num = $total_count - $offset;
                            while ($row = mysql_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td style='width: 10%;'>" . $row_num-- . "</td>";
                                echo "<td style='width: 15%;'>" . htmlspecialchars($row['s5_caid']) . "</td>";
                                echo "<td style='width: 50%;'>" . htmlspecialchars($row['s5_category']) . "</td>";
                                echo "<td style='width: 25%;'>";
                                echo "<a href='category_edit.php?id=" . urlencode($row['s5_caid']) . "' class='action-link edit-link'>수정</a>";
                                echo "<a href='#' class='action-link delete-link delete-btn' data-id='" . htmlspecialchars($row['s5_caid']) . "' onclick='return deleteItem(this);'>삭제</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        }
                    } elseif ($show_table) {
                        $colspan = ($current_tab === 'tab1') ? 10 : ($current_tab === 'tab2' ? 4 : 5);
                        echo "<tr><td colspan='$colspan' style='border-right: none;'>데이터가 없습니다.</td></tr>";
                    } else {
                        echo "<tr>";
                        echo "<td style='width: 20%; border-right: 1px solid #ddd;'>-</td>";
                        echo "<td style='width: 20%; border-right: 1px solid #ddd;'>-</td>";
                        echo "<td style='width: 20%; border-right: 1px solid #ddd;'>-</td>";
                        echo "<td style='width: 20%; border-right: 1px solid #ddd;'>-</td>";
                        echo "<td style='width: 20%;'>-</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>

            <?php if ($show_table && $total_pages > 1): ?>
            <div class="pagination">
                <?php
                $search_params = '&tab=' . urlencode($current_tab);
                if ($current_tab === 'tab1' && $search_type !== 'all') {
                    $search_params .= '&search_type=' . urlencode($search_type);
                }
                if ($search_keyword) {
                    $search_params .= '&search_keyword=' . urlencode($search_keyword);
                }

                if ($page > 1) {
                    echo "<a href='parts.php?page=" . ($page - 1) . $search_params . "'>← 이전</a>";
                }

                $start_page = max(1, $page - 2);
                $end_page = min($total_pages, $page + 2);

                if ($start_page > 1) {
                    echo "<a href='parts.php?page=1" . $search_params . "'>1</a>";
                    if ($start_page > 2) echo "<span>...</span>";
                }

                for ($i = $start_page; $i <= $end_page; $i++) {
                    if ($i == $page) {
                        echo "<span class='current'>" . $i . "</span>";
                    } else {
                        echo "<a href='parts.php?page=" . $i . $search_params . "'>" . $i . "</a>";
                    }
                }

                if ($end_page < $total_pages) {
                    if ($end_page < $total_pages - 1) echo "<span>...</span>";
                    echo "<a href='parts.php?page=" . $total_pages . $search_params . "'>" . $total_pages . "</a>";
                }

                if ($page < $total_pages) {
                    echo "<a href='parts.php?page=" . ($page + 1) . $search_params . "'>다음 →</a>";
                }
                ?>
            </div>
            <?php endif; ?>

            <?php if (!$show_table): ?>
            <div class="empty-state">
                <p>📋 이 탭의 데이터베이스 테이블이 아직 설정되지 않았습니다.</p>
                <strong>곧 자료가 추가될 예정입니다.</strong>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        $(function() {
            var currentTab = '<?php echo $current_tab; ?>';
            
            if (currentTab === 'tab1') {
                var searchType = $('#search_type').val();
                var autocompleteType = searchType === 'all' ? 'name' : searchType;
                
                $('#search_keyword').autocomplete('parts.php?action=autocomplete&type=' + autocompleteType, {
                    minChars: 1,
                    width: 300,
                    matchContains: true,
                    autoFill: false,
                    selectFirst: false
                });

                $('#search_type').change(function() {
                    var newType = $(this).val() === 'all' ? 'name' : $(this).val();
                    $('#search_keyword').autocomplete('parts.php?action=autocomplete&type=' + newType, {
                        minChars: 1,
                        width: 300,
                        matchContains: true,
                        autoFill: false,
                        selectFirst: false
                    });
                });
            }
        });

        function deleteItem(el) {
            if (!confirm('정말 삭제하시겠습니까?')) {
                return false;
            }

            var id = $(el).data('id');
            var $el = $(el);
            var currentTab = '<?php echo $current_tab; ?>';

            $.blockUI({
                message: '<h2>처리 중...</h2><p>삭제 중입니다.</p>'
            });

            $.ajax({
                url: 'parts.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'delete',
                    id: id,
                    tab: currentTab
                },
                success: function(response) {
                    $.unblockUI();
                    
                    if (response.success) {
                        $el.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                            showMessage(response.message, 'success');
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        });
                    } else {
                        showMessage(response.message, 'error');
                    }
                },
                error: function() {
                    $.unblockUI();
                    showMessage('삭제 중 오류가 발생했습니다.', 'error');
                }
            });

            return false;
        }

        function showMessage(message, type) {
            var messageClass = type === 'error' ? 'error' : '';
            var $message = $('<div class="message ' + messageClass + '"></div>')
                .text((type === 'error' ? '✗ ' : '✓ ') + message)
                .insertBefore('#data-table')
                .fadeIn();

            setTimeout(function() {
                $message.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 3000);
        }
    </script>
</body>
</html>
<?php mysql_close($connect); ?>
