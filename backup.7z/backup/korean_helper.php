<?php
/**
 * Korean text helper - converts Korean text properly
 */

function ko($text) {
    if (is_string($text)) {
        // If the text is in EUC-KR, convert to UTF-8
        if (!mb_check_encoding($text, 'UTF-8')) {
            return mb_convert_encoding($text, 'UTF-8', 'EUC-KR');
        }
    }
    return $text;
}

// Try to automatically detect and output correct charset
function outputKorean($text) {
    return ko($text);
}

// Override echo for Korean text
if (!function_exists('echo_ko')) {
    function echo_ko($text) {
        echo ko($text);
    }
}
?>
