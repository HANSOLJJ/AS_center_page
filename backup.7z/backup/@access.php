<?php
/**
 * AS System - Access Control
 * 로그인 세션 확인
 */

// 세션이 시작되지 않았으면 시작
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 로그인되지 않은 사용자 확인 (member_id 및 member_sid 확인)
if (empty($_SESSION['member_id']) || empty($_SESSION['member_sid'])) {
    // 로그인 페이지로 리다이렉트
    header('Location: login.php');
    exit;
}
?>
