<?

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 30;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if(!eregi("[^[:space:]]+",$key)) {
		$query = "SELECT count(*) FROM $db11";

} else {
   $encoded_key = urlencode($key);
   $query = "SELECT count(*) FROM $db11 WHERE $keyfield LIKE '%$key%'";  
}

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}

echo"$mode";
?>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='5%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>No</b></p>
		</td>
		<td width='5%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>분류</b></p>
		</td>
		<td width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>업체명</b></p>
		</td>
		<td width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>전화</b></p>
		</td>
		<td width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>사업자 등록번호</b></p>
		</td>
		<td width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>업종 /  업태</b></p>
		</td>
		<td width='5%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>대표자</b></p>
		</td>
		<td width='25%'background="<?echo "$border_bg1";?>">
		<p align='center'><b>주소</b></p>
		</td>
		<td width='5%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>수정</b></p>
		</td>
		<td width='5%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>삭제</b></p>
		</td>
	</tr>

<?

$time_limit = 60*60*24*$notify_new_article; 

#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
if(!eregi("[^[:space:]]+",$key)) {
	$query = "SELECT   s11_meid, s11_sec, s11_phone1, s11_phone2, s11_phone3, s11_phone4, s11_phone5, s11_phone6, s11_com_num1, s11_com_num2, s11_com_num3, s11_com_name, s11_com_man, s11_com_sec1, s11_com_sec2, s11_oaddr FROM $db11 ORDER BY s11_meid DESC LIMIT $first, $num_per_page";	
} else {
   $query = "SELECT   s11_meid, s11_sec, s11_phone1, s11_phone2, s11_phone3, s11_phone4, s11_phone5, s11_phone6, s11_com_num1, s11_com_num2, s11_com_num3, s11_com_name, s11_com_man, s11_com_sec1, s11_com_sec2, s11_oaddr FROM $db11 WHERE $keyfield LIKE '%$key%' ORDER BY s11_meid DESC LIMIT $first, $num_per_page";
}
$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

if($total_record=='0'){print"<tr><td height='200' colspan='10'><table width='600' align='center' cellspacing='0' cellpadding='0'  border='0' ><tr><td height='160'><p align='center'>등록된 데이터가 없습니다.</p></td></tr></table></td></tr>";}


##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.  

   $my_s11_meid = $row[s11_meid];
   $my_s11_sec = $row[s11_sec];
   $my_s11_phone1 = $row[s11_phone1];
   $my_s11_phone2 = $row[s11_phone2];
   $my_s11_phone3 = $row[s11_phone3];
   $my_s11_phone4 = $row[s11_phone4];
   $my_s11_phone5 = $row[s11_phone5];
   $my_s11_phone6 = $row[s11_phone6];
   $my_s11_com_num1 = $row[s11_com_num1];
   $my_s11_com_num2 = $row[s11_com_num2];
   $my_s11_com_num3 = $row[s11_com_num3];
   $my_s11_com_name = $row[s11_com_name];
   $my_s11_com_man = $row[s11_com_man];
   $my_s11_com_sec1 = $row[s11_com_sec1];
   $my_s11_com_sec2 = $row[s11_com_sec2];
   $my_s11_oaddr = $row[s11_oaddr];


if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}
if($my_s11_email ==""){$my_s11_email ="&nbsp;";}
//--------------------------------------------------------------------

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}


echo("<tr>");

##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s11_sec</td>");

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s11_com_name</td>");

##### [컬럼 3 : 

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s11_phone1-$my_s11_phone2-$my_s11_phone3<br>$my_s11_phone4-$my_s11_phone5-$my_s11_phone6</td>");

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s11_com_num1-$my_s11_com_num2-$my_s11_com_num3</td>");

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s11_com_sec1<br>$my_s11_com_sec2</td>");

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s11_com_man</td>");

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s11_oaddr</td>");
##### 

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=modify&number=$my_s11_meid&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_modify.gif' border='0'></a></td>");

##### 

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=del&number=$my_s11_meid&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_del.gif' border='0'></a></td>");

$article_num--;
}
echo("</table>");
?>
<br>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>
<form method="post" action="<?echo("list.php?in_code=list_view&in_mode=$in_mode&center_id_s=$center_id_s")?>">


							
							<td width='280' height='35'>
							<select name="keyfield" size="1" align='absmiddle' <?echo("$Form_style1");?>>
							   <option value="s11_com_name">회사명</option>
							   <option value="s11_com_man">대표자명</option>
							   <option value="s11_oaddr">주소</option>
							</select>
							&nbsp;&nbsp;
							<input type="text" name="key" size='18' <?echo("$Form_style1");?>>&nbsp;&nbsp;&nbsp;
							<input type='submit' STYLE='font-size:9pt;' value='검색'>
							</td>
							
						</form>
							<td  align='center'>

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&s3_center_id=$center_id_s&keyfield=$keyfield\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("<a href=\"list.php?in_code=list_view&page=$direct_page&s3_center_id=$center_id_s&keyfield=$keyfield\" >$direct_page</a>.&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&s3_center_id=$center_id_s&keyfield=$keyfield\" >→</a>");
}

?>



<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td>

<?
if($HTTP_SESSION_VARS["member_id"] !="" AND $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "1"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "2"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "3"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";}
?>
		</td>
	</tr>
</table>