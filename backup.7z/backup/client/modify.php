<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT  s11_phone1, s11_phone2, s11_phone3, s11_phone4, s11_phone5, s11_phone6, s11_com_num1, s11_com_num2, s11_com_num3, s11_com_name, s11_com_man, s11_com_sec1, s11_com_sec2, s11_oaddr FROM $db11 WHERE s11_meid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s11_meid = $row->s11_meid;
$my_s11_phone1 = $row->s11_phone1;
$my_s11_phone2 = $row->s11_phone2; 
$my_s11_phone3 = $row->s11_phone3; 
$my_s11_phone4 = $row->s11_phone4;
$my_s11_phone5 = $row->s11_phone5; 
$my_s11_phone6 = $row->s11_phone6; 
$my_s11_com_num1 = $row->s11_com_num1;
$my_s11_com_num2 = $row->s11_com_num2;
$my_s11_com_num3 = $row->s11_com_num3; 
$my_s11_com_name = $row->s11_com_name;
$my_s11_com_man = $row->s11_com_man;
$my_s11_com_sec1 = $row->s11_com_sec1;
$my_s11_com_sec2 = $row->s11_com_sec2;
$my_s11_oaddr = $row->s11_oaddr;


##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {

	
	if(!form.s11_phone1.value) {
      alert('핸드폰 번호를 입력하세요!');
      form.s11_phone1.focus();
      return;
   }

   if(!form.s11_phone2.value) {
      alert('핸드폰 번호를 입력하세요!');
      form.s11_phone2.focus();
      return;
   }

   if(!form.s11_phone3.value) {
      alert('핸드폰 번호를 입력하세요!');
      form.s11_phone3.focus();
      return;
   }

  if(form.s11_phone1.value) {
         if(!IsNumber(form.s11_phone1.name)) {
            alert("핸드폰 번호는 숫자여야 합니다!");
            form.s11_phone1.focus();
            return; 
         }
      }

	  if(form.s11_phone2.value) {
         if(!IsNumber(form.s11_phone2.name)) {
            alert("핸드폰 번호는 숫자여야 합니다!");
            form.s11_phone2.focus();
            return; 
         }
      }

	  if(form.s11_phone3.value) {
         if(!IsNumber(form.s11_phone3.name)) {
            alert("핸드폰 번호는 숫자여야 합니다!");
            form.s11_phone3.focus();
            return; 
         }
      }
  if(!form.s11_phone4.value) {
      alert('전화 번호를 입력하세요!');
      form.s11_phone4.focus();
      return;
   }

   if(!form.s11_phone5.value) {
      alert('전화 번호를 입력하세요!');
      form.s11_phone5.focus();
      return;
   }

   if(!form.s11_phone6.value) {
      alert('전화 번호를 입력하세요!');
      form.s11_phone6.focus();
      return;
   }



  if(form.s11_phone4.value) {
         if(!IsNumber(form.s11_phone4.name)) {
            alert("전화 번호는 숫자여야 합니다!");
            form.s11_phone4.focus();
            return; 
         }
      }

	  if(form.s11_phone5.value) {
         if(!IsNumber(form.s11_phone5.name)) {
            alert("전화 번호는 숫자여야 합니다!");
            form.s11_phone5.focus();
            return; 
         }
      }

	  if(form.s11_phone6.value) {
         if(!IsNumber(form.s11_phone6.name)) {
            alert("전화 번호는 숫자여야 합니다!");
            form.s11_phone6.focus();
            return; 
         }
      }

           
   form.submit();
}


function IsID(formname) {
      var form = eval("document.form." + formname);
      
      if(form.value.length < 5 || form.value.length > 12) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z')) {
            return false;
         }
      }
      return true;   
   }

   function IsPW(formname) {
      var form = eval("document.form." + formname);
      
      if(form.value.length < 4 || form.value.length > 12) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z') && (chr < 'A' || chr > 'Z')) {
            return false;
         }
      }
      return true;   
   }
         
   function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>

<!------------------------- 전화  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>핸드폰 번호</b></p>
			</td>
			<td width='70%'>
			<input type="text" name="s11_phone1" size="3" maxlength="3" <?echo("$Form_style1");?>  value="<? echo("$my_s11_phone1"); ?>">&nbsp; -&nbsp;
			<input type="text" name="s11_phone2" size="4" maxlength="4" <?echo("$Form_style1");?>  value="<? echo("$my_s11_phone2"); ?>">&nbsp; -&nbsp;
			<input type="text" name="s11_phone3" size="4" maxlength="4" <?echo("$Form_style1");?>  value="<? echo("$my_s11_phone3"); ?>">
			</td>
		</tr>
<!------------------------- 전화  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>전화 번호</b></p>
			</td>
			<td width='70%'>
			<input type="text" name="s11_phone4" size="3" maxlength="3" <?echo("$Form_style1");?>  value="<? echo("$my_s11_phone4"); ?>">&nbsp; -&nbsp;
			<input type="text" name="s11_phone5" size="4" maxlength="4" <?echo("$Form_style1");?>  value="<? echo("$my_s11_phone5"); ?>">&nbsp; -&nbsp;
			<input type="text" name="s11_phone6" size="4" maxlength="4" <?echo("$Form_style1");?>  value="<? echo("$my_s11_phone6"); ?>">
			</td>
		</tr>
<!------------------------- 사업자 정보  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'> <b>사업자 등록번호</b></p>
			</td>
			<td width='70%'>
			<input type="text" name="s11_com_num1" size="3" maxlength="3" <?echo("$Form_style1");?>   value="<? echo("$my_s11_com_num1"); ?>">&nbsp; -&nbsp;
			<input type="text" name="s11_com_num2" size="2" maxlength="2" <?echo("$Form_style1");?> value="<? echo("$my_s11_com_num2"); ?>">&nbsp; -&nbsp;
			<input type="text" name="s11_com_num3" size="5" maxlength="5" <?echo("$Form_style1");?> value="<? echo("$my_s11_com_num3"); ?>">
			</td>
		</tr>
<!------------------------- 대표자  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>상호</b></p>
			</td>
			<td width='70%'>
			<input type="text" name="s11_com_name" size="32" maxlength="255" <?echo("$Form_style1");?>  value="<? echo("$my_s11_com_name"); ?>">
			</td>
		</tr>

<!------------------------- 대표자  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>업종 / 업태</b></p>
			</td>
			<td width='70%'>
			<input type="text" name="s11_com_sec1" size="32" maxlength="255" <?echo("$Form_style1");?>   value="<? echo("$my_s11_com_sec1"); ?>">&nbsp;/&nbsp;
			<input type="text" name="s11_com_sec2" size="32" maxlength="255" <?echo("$Form_style1");?>   value="<? echo("$my_s11_com_sec2"); ?>">
			</td>
		</tr>
<!------------------------- 대표자  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>사업장 주소</b></p>
			</td>
			<td width='70%'>
			<input type="text" name="s11_oaddr" size="64" maxlength="255" <?echo("$Form_style1");?>   value="<? echo("$my_s11_oaddr"); ?>">
			</td>
		</tr>
<!------------------------- 대표자  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>대표자</b></p>
			</td>
			<td width='70%'>
			<input type="text" name="s11_com_man" size="64" maxlength="255" <?echo("$Form_style1");?> value="<? echo("$my_s11_com_man"); ?>">
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>