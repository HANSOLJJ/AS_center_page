<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$query = "UPDATE $db11 SET s11_phone1 = '$s11_phone1', s11_phone2 = '$s11_phone2', s11_phone3 = '$s11_phone3', s11_phone4 = '$s11_phone4', s11_phone5 = '$s11_phone5', s11_phone6 = '$s11_phone6', s11_com_num1 = '$s11_com_num1', s11_com_num2 = '$s11_com_num2', s11_com_num3 = '$s11_com_num3', s11_com_name = '$s11_com_name', s11_com_man = '$s11_com_man', s11_com_sec1 = '$s11_com_sec1', s11_com_sec2 = '$s11_com_sec2', s11_oaddr = '$s11_oaddr' WHERE s11_meid  = '$number'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>