<script language="javascript">
<!--
function sendit() {

	
	if(!form.s11_phone1.value) {
      alert('핸드폰 번호를 입력하세요!');
      form.s11_phone1.focus();
      return;
   }

   if(!form.s11_phone2.value) {
      alert('핸드폰 번호를 입력하세요!');
      form.s11_phone2.focus();
      return;
   }

   if(!form.s11_phone3.value) {
      alert('핸드폰 번호를 입력하세요!');
      form.s11_phone3.focus();
      return;
   }



  if(form.s11_phone1.value) {
         if(!IsNumber(form.s11_phone1.name)) {
            alert("핸드폰 번호는 숫자여야 합니다!");
            form.s11_phone1.focus();
            return; 
         }
      }

	  if(form.s11_phone2.value) {
         if(!IsNumber(form.s11_phone2.name)) {
            alert("핸드폰 번호는 숫자여야 합니다!");
            form.s11_phone2.focus();
            return; 
         }
      }

	  if(form.s11_phone3.value) {
         if(!IsNumber(form.s11_phone3.name)) {
            alert("핸드폰 번호는 숫자여야 합니다!");
            form.s11_phone3.focus();
            return; 
         }
      }

	  if(!form.s11_phone4.value) {
      alert('전화 번호를 입력하세요!');
      form.s11_phone4.focus();
      return;
   }

   if(!form.s11_phone5.value) {
      alert('전화 번호를 입력하세요!');
      form.s11_phone5.focus();
      return;
   }

   if(!form.s11_phone6.value) {
      alert('전화 번호를 입력하세요!');
      form.s11_phone6.focus();
      return;
   }



  if(form.s11_phone4.value) {
         if(!IsNumber(form.s11_phone4.name)) {
            alert("전화 번호는 숫자여야 합니다!");
            form.s11_phone4.focus();
            return; 
         }
      }

	  if(form.s11_phone5.value) {
         if(!IsNumber(form.s11_phone5.name)) {
            alert("전화 번호는 숫자여야 합니다!");
            form.s11_phone5.focus();
            return; 
         }
      }

	  if(form.s11_phone6.value) {
         if(!IsNumber(form.s11_phone6.name)) {
            alert("전화 번호는 숫자여야 합니다!");
            form.s11_phone6.focus();
            return; 
         }
      }

 if(!form.s11_com_zip1.value) {
      alert('우편번호를 입력하세요!');
      form.s11_com_zip1.focus();
      return;
   }

	 if(form.s11_com_zip1.value) {
         if(!IsNumber(form.s11_com_zip1.name)) {
            alert("우편번호는 숫자여야 합니다!");
            form.s11_com_zip1.focus();
            return; 
         }
      }

	  if(!form.s11_com_zip2.value) {
      alert('우편번호를 입력하세요!');
      form.s11_com_zip2.focus();
      return;
   }

	 if(form.s11_com_zip2.value) {
         if(!IsNumber(form.s11_com_zip2.name)) {
            alert("우편번호는 숫자여야 합니다!");
            form.s11_com_zip2.focus();
            return; 
         }
      }

	  if(!form.s11_oaddr.value) {
      alert('주소를 입력하세요!');
      form.s11_oaddr.focus();
      return;
   }
           
   form.submit();
}


function IsID(formname) {
      var form = eval("document.form." + formname);
      
      if(form.value.length < 5 || form.value.length > 12) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z')) {
            return false;
         }
      }
      return true;   
   }

   function IsPW(formname) {
      var form = eval("document.form." + formname);
      
      if(form.value.length < 4 || form.value.length > 12) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z') && (chr < 'A' || chr > 'Z')) {
            return false;
         }
      }
      return true;   
   }
         
   function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }

   function ZipWindow(ref,what) {
      var window_left = (screen.width-640)/2;
      var window_top = (screen.height-480)/2;
      ref = ref + "?what=" + what;      
      window.open(ref,"zipWin",'width=550,height=200,status=no,top=' + window_top + ',left=' + window_left + '');
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='write_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>' enctype='multipart/form-data'>
<INPUT type='hidden' name='mode_se' value="yes">
<!------------------------- 형태  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<b>형태</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="radio" name="s11_sec" value="일반" checked>&nbsp;일반&nbsp;
			<input type="radio" name="s11_sec" value="대리점">&nbsp;대리점&nbsp;
			<input type="radio" name="s11_sec" value="딜러">&nbsp;딜러&nbsp;
			&nbsp;<a href='list.php?in_code=write2'><b><font color='red'>[주소 및 사업자 정보 삭제]</font></b></a>
			</td>
		</tr> 
<!------------------------- 전화  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>핸드폰 번호</b></p>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s11_phone1" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_phone2" size="4" maxlength="4" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_phone3" size="4" maxlength="4" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 전화  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>전화 번호</b></p>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s11_phone4" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_phone5" size="4" maxlength="4" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_phone6" size="4" maxlength="4" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 사업자 정보  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			 <p align='center'><b>사업자 등록번호</b></p>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s11_com_num1" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_com_num2" size="2" maxlength="2" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_com_num3" size="5" maxlength="5" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 대표자  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>상호</b></p>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s11_com_name" size="32" maxlength="255" <?echo("$Form_style1");?>>
			</td>
		</tr>

<!------------------------- 대표자  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>업종 / 업태</b></p>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s11_com_sec1" size="32" maxlength="255" <?echo("$Form_style1");?>>&nbsp;/&nbsp;
			<input type="text" name="s11_com_sec2" size="32" maxlength="255" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 주소  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<b>업체 주소</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="text" name="s11_com_zip1" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp;-&nbsp; 
			<input type="text" name="s11_com_zip2" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp; 
			<input type="button" value="우편번호 및 주소 자동입력" onClick="ZipWindow('zipsearch.php',1)">
			<br>
			&nbsp;&nbsp;
			<input type="text" name="s11_oaddr" size="64" maxlength="255" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 대표자  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>대표자</b></p>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s11_com_man" size="32" maxlength="64" <?echo("$Form_style1");?>>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>