<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 신청한 아이디와 동일한 아이디가 존재하는지 확인한다.
$result = mysql_query("SELECT count(s3_id) FROM $db WHERE s3_id = '$s3_id'");
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$rows = mysql_result($result,0,0);
if ($rows) {
   error("NOT_ALLOWED_DUPLICATE_ID");
   exit;
}
mysql_free_result($result);

$query = "INSERT INTO $db (s3_center_id, s3_name, s3_id, s3_passwd, s3_userlevel) VALUES ('$s3_center_id', '$s3_name', '$s3_id', password('$s3_passwd'), 1)";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>