
<?

echo("<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'><tr><td>");

if($in_mode == "1" OR $in_mode == ""){$font_color_admin ="FF0000";}else{$font_color_admin ="#000000";}

echo("<a href=\"list.php?in_code=list_view&in_mode=1\"><font color=$font_color_admin><b>[ 센터 전체보기 ]</b></font></a>&nbsp;");

//------------------센터명 부르기

$search_query = "Select s2_center_id, s2_center FROM step2_center ORDER BY s2_center ASC";
$search_result= mysql_query($search_query);

if (!$search_result) {
   error("QUERY_ERROR");
   exit;
}


while($search_row = mysql_fetch_array($search_result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $search_s2_center = $search_row[s2_center];
   $search_s2_center_id = $search_row[s2_center_id];

if($search_s2_center_id  == $center_id_s){$font_color ="#FF0000";}else{$font_color ="#000000";}
echo("<a href=\"list.php?in_code=list_view&in_mode=2&center_id_s=$search_s2_center_id\"><font color=$font_color><b>[ $search_s2_center ]</b></font></a>&nbsp;");
}

echo("</td></tr></table>");

?>

<br>

<?

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 15;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if(!eregi("[^[:space:]]+",$key)) {
	if($in_mode == "1" OR $in_mode == ""){
		$query = "SELECT count(*) FROM $db";

	} else
	
	if($in_mode == "2"){
		$query = "SELECT count(*) FROM $db WHERE s3_center_id LIKE '$center_id_s'";

		}
} else {
   $encoded_key = urlencode($key);
   $query = "SELECT count(*) FROM $db WHERE s3_center_id LIKE '$center_id_s' AND $keyfield LIKE '%$key%'";  
}

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}

echo"$mode";
?>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='5%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'>No</p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'>센터명</p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'>기사명</p>
		</td>
		<td width='10%'background="<?echo "$border_bg1";?>">
		<p align='center'>ID</p>
		</td>
		<td width='10%'background="<?echo "$border_bg1";?>">
		<p align='center'>수정</p>
		</td>
		<td width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'>삭제</p>
		</td>
	</tr>

<?

$time_limit = 60*60*24*$notify_new_article; 

#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
if(!eregi("[^[:space:]]+",$key)) {
	if($in_mode == "1" OR $in_mode == ""){$query = "SELECT s3_mid, s3_center_id, s3_name, s3_id, s3_passwd, s3_userlevel FROM $db ORDER BY s3_mid DESC LIMIT $first, $num_per_page";
	} else if($in_mode == "2"){
		$query = "SELECT s3_mid, s3_center_id, s3_name, s3_id, s3_passwd, s3_userlevel FROM $db WHERE s3_center_id LIKE '$center_id_s' ORDER BY s3_mid DESC LIMIT $first, $num_per_page";
		}   
} else {
   $query = "SELECT s3_mid, s3_center_id, s3_name, s3_id, s3_passwd, s3_userlevel FROM $db WHERE s3_center_id LIKE '$center_id_s' AND $keyfield LIKE '%$key%' ORDER BY s3_mid DESC LIMIT $first, $num_per_page";
}
$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

if($total_record=='0'){print"<tr><td height='200' colspan='10'><table width='600' align='center' cellspacing='0' cellpadding='0'  border='0' ><tr><td height='160'><p align='center'>등록된 데이터가 없습니다.</p></td></tr></table></td></tr>";}


##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.  


   $my_s3_mid = $row[s3_mid];
   $my_s3_center_id = $row[s3_center_id];
   $my_s3_name = $row[s3_name];
   $my_s3_id = $row[s3_id];
  
//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM step2_center WHERE s2_center_id ='$my_s3_center_id'");
$center_name = mysql_result($center_query,0,0);
   

  
##### 원칙상 제목에는 HTML 태그를 허용하지 않는다.
$my_s3_name = htmlspecialchars($my_s3_name);

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}
//--------------------------------------------------------------------
echo("<tr>");

##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

echo("<td align='left' valign='middle' $list_style1 $td_bg>$center_name</td>");

echo("<td align='left' valign='middle' $list_style1 $td_bg>$my_s3_name</td>");

##### [컬럼 3 : 

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_s3_id</td>");

##### 

echo("	<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=modify&number=$my_s3_mid&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_modify.gif' border='0'></a></td>");

##### 

echo("	<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=del&number=$my_s3_mid&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_del.gif' border='0'></a></td>");

$article_num--;
}
echo("</table>");
?>
<br>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>

							<td  align='center'>

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&s3_center_id=$center_id_s&keyfield=$keyfield\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("<a href=\"list.php?in_code=list_view&page=$direct_page&s3_center_id=$center_id_s&keyfield=$keyfield\" >$direct_page</a>.&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&s3_center_id=$center_id_s&keyfield=$keyfield\" >→</a>");
}

?>



<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td>

<?
if($HTTP_SESSION_VARS["member_id"] !="" AND $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "1"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "2"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "3"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db&s3_center_id=$center_id_s'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";}
?>
		</td>
	</tr>
</table>