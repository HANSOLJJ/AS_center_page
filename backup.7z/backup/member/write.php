<script language="javascript">
<!--
function sendit() {

	if(!form.s3_center_id.value) {
      alert('센터명을 입력하세요!');
      form.s3_center_id.focus();
      return;
   }
	
	if(!form.s3_name.value) {
      alert('담당자 이름을 입력하세요!');
      form.s3_name.focus();
      return;
   }

   if(!form.s3_id.value) {
      alert('ID를 입력하세요!');
      form.s3_id.focus();
      return;
   }

   if(!IsID(form.s3_id.name)) {
         alert("아이디는 5 ~ 10자의 영문 소문자나 숫자 또는 조합된 문자열이어야 합니다!");
         form.s3_id.focus();
         form.s3_id.select();
         return;         
      }

   if(!form.s3_passwd.value) {
      alert('패스워드를 입력하세요!');
      form.s3_passwd.focus();
      return;
   }

   if(!IsPW(form.s3_passwd.name)) {
         alert("비밀번호는 4 ~ 8자의 영문자나 숫자 또는 조합된 문자열이어야 합니다!");
         form.s3_passwd.focus();
         form.s3_passwd.select();
         return;
      }    

    if (form.s3_passwd.value != form.repasswd.value) {
         alert("입력하신 비밀번호가 일치하지 않습니다.\n다시 확인하시고 입력하여 주십시오.");
         form.repasswd.focus();
         form.repasswd.select();
         return;
      }



           
   form.submit();
}


function IsID(formname) {
      var form = eval("document.form." + formname);
      
      if(form.value.length < 5 || form.value.length > 12) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z')) {
            return false;
         }
      }
      return true;   
   }

   function IsPW(formname) {
      var form = eval("document.form." + formname);
      
      if(form.value.length < 4 || form.value.length > 12) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z') && (chr < 'A' || chr > 'Z')) {
            return false;
         }
      }
      return true;   
   }
         
   function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='write_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>' enctype='multipart/form-data'>

<!------------------------- 센터명  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>센터명</b>
			</td>
			<td width='70%'>
			<select name="s3_center_id"<?echo("$Form_style1");?>>
			<option value=''>센터명을 선택해 주세요.</option>
<?php
     

$db_step2 = 'step2_center';

##### 레코드 세트
$result= mysql_query("SELECT s2_cid, s2_center_id, s2_center FROM $db_step2");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장   

$my_s2_cid = $row[s2_cid];
$my_s2_center_id = $row[s2_center_id];
$my_s2_center = $row[s2_center];
  
##### 

echo("<option value='$my_s2_center_id'>$my_s2_center</option>");

}
?>

			</select>
			</td>
		</tr>
<!------------------------- 담당자 이름  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>담당자 이름</b>
			</td>
			<td width='70%'>
			<input type="text" name="s3_name" size="64" maxlength="255" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- ID  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>ID</b>
			</td>
			<td width='70%'>
			<input type="text" name="s3_id" size="64" maxlength="255" <?echo("$Form_style1");?>>&nbsp;(5 ~ 10자의 영소문자, <font color="red">한글아이디 등록불가</font>)
			</td>
		</tr>
<!------------------------- pw  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>패스워드</b>
			</td>
			<td width='70%'>
			<input type="password" name="s3_passwd" size="32" maxlength="32" <?echo("$Form_style1");?>>&nbsp;비밀번호 확인<input type="password" name="repasswd" size="32" maxlength="32" <?echo("$Form_style1");?>>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>