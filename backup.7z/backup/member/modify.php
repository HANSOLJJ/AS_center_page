<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s3_mid, s3_center_id, s3_name, s3_id FROM $db WHERE s3_mid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s3_mid = $row->s3_mid;
$my_s3_center_id = $row->s3_center_id;
$my_s3_name = $row->s3_name;
$my_s3_id = $row->s3_id;

##### 제목과 본문에 대하여 테이블에 저장할 때(post.php) addslashes() 함수로 escape시킨 문자열을 원래대로 되돌려 놓는다.
$my_s3_name = stripslashes($my_s3_name);

##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {

	if(!form.s3_center_id.value) {
      alert('센터명을 입력하세요!');
      form.s3_center_id.focus();
      return;
   }
	
	if(!form.s3_name.value) {
      alert('담당자 이름을 입력하세요!');
      form.s3_name.focus();
      return;
   }

   if(!form.s3_passwd.value) {
      alert('패스워드를 입력하세요!');
      form.s3_passwd.focus();
      return;
   }

   if(!IsPW(form.s3_passwd.name)) {
         alert("비밀번호는 4 ~ 8자의 영문자나 숫자 또는 조합된 문자열이어야 합니다!");
         form.s3_passwd.focus();
         form.s3_passwd.select();
         return;
      }    

    if (form.s3_passwd.value != form.repasswd.value) {
         alert("입력하신 비밀번호가 일치하지 않습니다.\n다시 확인하시고 입력하여 주십시오.");
         form.repasswd.focus();
         form.repasswd.select();
         return;
      }



           
   form.submit();
}



   function IsPW(formname) {
      var form = eval("document.form." + formname);
      
      if(form.value.length < 4 || form.value.length > 12) {
         return false;
      }
      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);         
         if((chr < '0' || chr > '9') && (chr < 'a' || chr > 'z') && (chr < 'A' || chr > 'Z')) {
            return false;
         }
      }
      return true;   
   }
         
   function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>

<!------------------------- 센터명  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>센터명</b>
			</td>
			<td width='70%'>
			<select name="s3_center_id"<?echo("$Form_style1");?>>
			<option value=''>센터명을 선택해 주세요.</option>
<?php
     

$db_step2 = 'step2_center';

##### 레코드 세트
$result= mysql_query("SELECT s2_cid, s2_center_id, s2_center FROM $db_step2");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장   

$my_s2_cid = $row[s2_cid];
$my_s2_center_id = $row[s2_center_id];
$my_s2_center = $row[s2_center];
  
##### 

//변환1
if($my_s3_center_id == $my_s2_center_id){$selected_option = "selected";}else{$selected_option = "";}

echo("<option value='$my_s2_center_id' $selected_option>$my_s2_center</option>");

}
?>

			</select>
			</td>
		</tr>
<!------------------------- 담당자 이름  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>담당자 이름</b>
			</td>
			<td width='70%'>
			<input type="text" name="s3_name" size="64" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_s3_name");?>'>
			</td>
		</tr>
<!------------------------- ID  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>ID</b>
			</td>
			<td width='70%'>
			<? echo("$my_s3_id");?>
			</td>
		</tr>
<!------------------------- pw  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>패스워드</b>
			</td>
			<td width='70%'>
			<input type="password" name="s3_passwd" size="32" maxlength="32" <?echo("$Form_style1");?>>&nbsp;비밀번호 확인<input type="password" name="repasswd" size="32" maxlength="32" <?echo("$Form_style1");?>>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>