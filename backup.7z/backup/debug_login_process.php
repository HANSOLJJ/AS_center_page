<?php
/**
 * AS System - Login Process Debug
 * 로그인 프로세스 전체 디버깅
 */

header('Content-Type: text/html; charset=utf-8');

// MySQL 호환성 레이어 로드 (PHP 7.4+ 지원)
require_once '@session_inc.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "<h2>POST 요청이 아닙니다</h2>";
    echo "현재 메서드: " . $_SERVER['REQUEST_METHOD'];
    exit;
}

$id = isset($_POST['admin_id']) ? trim($_POST['admin_id']) : '';
$passwd = isset($_POST['admin_password']) ? trim($_POST['admin_password']) : '';

echo "<h2>로그인 프로세스 디버그</h2>";
echo "<pre>";

echo "1. 입력값 확인\n";
echo "   - ID: $id\n";
echo "   - PASSWORD: $passwd\n";

// ID 형식 검증
echo "2. ID 형식 검증\n";
if (!preg_match('/^[a-zA-Z0-9]{5,10}$/', $id)) {
    echo "   ✗ ID 형식 오류\n";
    exit;
}
echo "   ✓ ID 형식 OK\n";

// 비밀번호 형식 검증
echo "3. 비밀번호 형식 검증\n";
if (!preg_match('/^[a-zA-Z0-9]{4,8}$/', $passwd)) {
    echo "   ✗ 비밀번호 형식 오류\n";
    exit;
}
echo "   ✓ 비밀번호 형식 OK\n";

// DB 연결 및 쿼리
echo "4. DB 쿼리 실행\n";
$connect = mysql_connect('mysql', 'mic4u_user', 'change_me');
if (!$connect) {
    echo "   ✗ DB 연결 실패\n";
    exit;
}
mysql_select_db('mic4u', $connect);

$result = mysql_query("SELECT passwd, userlevel FROM 2010_admin_member WHERE id = '$id'");
if (!$result) {
    echo "   ✗ 쿼리 실패\n";
    exit;
}

$rows = mysql_num_rows($result);
echo "   ✓ 쿼리 성공 (조회 행: $rows)\n";

if ($rows === 0) {
    echo "   ✗ 해당 ID 없음\n";
    exit;
}

$row = mysql_fetch_object($result);
$db_passwd = $row->passwd;
$db_userlevel = $row->userlevel;

echo "   - 저장된 비밀번호: $db_passwd\n";
echo "   - 저장된 레벨: $db_userlevel\n";

// PASSWORD 함수
echo "5. PASSWORD 함수 실행\n";
$result = mysql_query("SELECT password('$passwd')");
if (!$result) {
    echo "   ✗ PASSWORD 쿼리 실패\n";
    exit;
}

$user_passwd = mysql_result($result, 0, 0);
echo "   ✓ PASSWORD 함수 결과: $user_passwd\n";

// 16자 잘라내기
if (strlen($db_passwd) <= 16) {
    $user_passwd = substr($user_passwd, 0, 16);
    echo "   - 16자로 잘라낸 값: $user_passwd\n";
}

// 비밀번호 비교
echo "6. 비밀번호 비교\n";
echo "   - 저장된 값: '$db_passwd'\n";
echo "   - 입력한 값: '$user_passwd'\n";
echo "   - 일치: " . ($db_passwd === $user_passwd ? "YES" : "NO") . "\n";

if ($db_passwd === $user_passwd) {
    echo "7. 로그인 성공!\n";
    echo "   - 세션 ID 설정: " . session_id() . "\n";
    
    // 세션 변수 설정
    $_SESSION['member_id'] = $id;
    $_SESSION['member_level'] = $db_userlevel;
    $_SESSION['member_sid'] = session_id();
    
    echo "   - member_id: " . $_SESSION['member_id'] . "\n";
    echo "   - member_level: " . $_SESSION['member_level'] . "\n";
    echo "   - member_sid: " . $_SESSION['member_sid'] . "\n";
    
    echo "\n   test_menu.php로 리다이렉트 준비...\n";
    // header('Location: test_menu.php');
    // exit;
} else {
    echo "7. 비밀번호 불일치!\n";
}

echo "</pre>";

mysql_close();
?>
