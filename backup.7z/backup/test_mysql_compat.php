<?php
header('Content-Type: text/html; charset=utf-8');

echo "현재 디렉토리: " . dirname(__FILE__) . "\n";
echo "mysql_compat.php 파일 존재: " . (file_exists('mysql_compat.php') ? "YES" : "NO") . "\n";

require_once 'mysql_compat.php';

echo "mysql_connect 함수 존재: " . (function_exists('mysql_connect') ? "YES" : "NO") . "\n";
echo "mysql_fetch_object 함수 존재: " . (function_exists('mysql_fetch_object') ? "YES" : "NO") . "\n";
?>
