<?
include "@config.php";
include "@error_function.php";
include "@access.php";
?>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>뱀ъ댄 愿由ы</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>
</head>
<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0' bgcolor='#e8e8e8'>

<table width='100%' Height='100%' border='0' cellpadding='0' cellspacing='0' align='center' >
	<tr>
		<td >&nbsp;&nbsp;
&nbsp;<a href="member/list.php?in_code=list_view&db=step3_member" target='admin_target'>AS 쇳 愿由ъ</a>&nbsp;
&nbsp;<a href="pw/list.php" target='admin_target'>蹂몄 愿由ъ 鍮踰 蹂寃</a>&nbsp;
		</td>
	</tr>
</table>







