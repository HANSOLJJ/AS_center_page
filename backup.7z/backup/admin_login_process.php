<?
include "@config.php";
include "@error_function.php";

if($mod == "admin_login_ck") {

##### 대(ID) 理 5, 理 10 臾몄 レ媛 議고⑸ 臾몄댁댁댁 .
if(!ereg("[[:alnum:]+]{5,10}",$id)) {
   error("NOT_ALLOWED_ID");
   exit;
}

##### 鍮諛踰몃 理 4, 理 8 臾몄 レ媛 議고⑸ 臾몄댁댁댁 .
if(!ereg("[[:alnum:]+]{4,8}",$passwd)) {
   error("NOT_ALLOWED_PASSWD");
   exit;
}

##### 濡洹몄명湲  ν 대 鍮諛踰멸 쇱 肄瑜 寃.
$result = mysql_query("SELECT passwd, userlevel FROM $DB_Admin_Member WHERE id = '$id'");
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$rows = mysql_num_rows($result);

##### 쇱 蹂닿  寃쎌
if (!$rows) {
   error("LOGIN_ID_NOT_FOUND");
   exit;
} else {

##### 蹂닿  寃쎌 鍮諛踰 媛 媛몄⑤.
$row = mysql_fetch_object($result);

$db_passwd = $row->passwd;
$db_userlevel = $row->userlevel;
   
##### ъ⑹媛 ν 鍮諛踰몃 명.
$result = mysql_query("SELECT password('$passwd')");
$user_passwd = mysql_result($result,0,0);
 
#####  鍮諛踰몃 鍮援 쇱硫 몄 깊.

if(strcmp($db_passwd,$user_passwd)) {      
  error("LOGIN_INVALID_PW");
  exit;
} else {
   
      if(headers_sent()) {
         error("HTTP_HEADERS_SENT");
         exit;      
      } else {      
      
setcookie("member_id","",0,"/");
setcookie("member_sid","",0,"/");
setcookie("member_email","",0,"/");
setcookie("member_name","",0,"/");
setcookie("member_level","",0,"/");

     ##### 몄 깊.
         session_start();    
         ##### 깅 몄 곗댄곕 ν 몄 蹂瑜 깅.
         session_register("member_id", "member_sid", "member_level");

         ##### 깅 몄 蹂 곗댄곕 ν.
         $member_id = $id;
         $member_level = $db_userlevel;
         $member_sid = session_id();
      }


mysql_close();

}

}
echo ("<meta http-equiv='Refresh' content='0; URL=test_menu.php'>");

} else { // mod 寃
	echo ("
	<script>
	alert('紐삳 洹쇱.');
	history.go(-1)
	</script>
	");
}
?>