<?php
/**
 * Wrapper to properly handle EUC-KR to UTF-8 conversion
 * This file intercepts and converts all output
 */

// Set encoding
ini_set('default_charset', 'UTF-8');
ini_set('display_errors', 0);

// Start output buffer with conversion
ob_start('convert_euckr_to_utf8');

function convert_euckr_to_utf8($buffer) {
    // Detect encoding
    $encoding = mb_detect_encoding($buffer, ['EUC-KR', 'UTF-8', 'ASCII'], true);

    if ($encoding && $encoding !== 'UTF-8') {
        return mb_convert_encoding($buffer, 'UTF-8', $encoding);
    }

    // If detection fails, force EUC-KR to UTF-8
    if (!mb_check_encoding($buffer, 'UTF-8')) {
        $buffer = mb_convert_encoding($buffer, 'UTF-8', 'EUC-KR');
    }

    return $buffer;
}

// Must set header before any output
header('Content-Type: text/html; charset=UTF-8');

// Additional mb string settings
mb_http_output('UTF-8');
mb_internal_encoding('UTF-8');
?>
