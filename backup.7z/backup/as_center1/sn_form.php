<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>
<script language="javascript">
<!--
function sendit() {

   if(!form.cost_sn_hand.value) {
      alert('시리얼을 입력하세요!');
      form.cost_sn_hand.focus();
      return;
   }
          
   form.submit();
}

//-->
</script>
<table  width='100%'  height='35' cellpadding='0' cellspacing='0' border='0' align='center' valign='middle'>
	<tr>
		<td valign='middle'>
<form name='form' method='POST' action='<? echo("sn_form_process.php?s14_aiid=$kin_num");?>' target='admin_target' enctype='multipart/form-data'>
<input type='text' name='cost_sn_hand' size='8' maxlength='255'  <? echo"$Form_style1";?>>&nbsp;<A href='javascript:sendit()'><img src='../<?echo"$icon_dir";?>/cart_modi.gif' border='0' align='absmiddle'></a>
		</td>
	</tr>
	</form>
</table>