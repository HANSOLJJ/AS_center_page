<SCRIPT type="text/javascript" src="jquery-1.4.2.min.js"></script> 
<script type="text/javascript" src="jquery.blockUI.js"></script>
<script type="text/javascript" src="jquery.validate.js"></script>
<script type="text/javascript" src="jquery.mousewheel-3.0.2.js"></script>


<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css"/>
	<script type="text/javascript" src="jquery.autocomplete.js"></script>

<?include"data_php.php";?>

<script> 
var goods = [<?=$data?>];
</script>	

<script type="text/javascript">
		$(document).ready(function() {
			$("#search").autocomplete(goods,{
				matchContains: true
			});
			
			/*
			$("#search").autocomplete("data_php.php",{
				minChars: 0,
				width: 310,
				formatItem: function(row, i, max) {
					return i + "/" + max + ": \"" + row.name + "\" [" + row.to + "]";
				},
				formatMatch: function(row, i, max) {
					return row.name + " " + row.to;
				},
				formatResult: function(row) {
					return row.to;
				}
			});
			*/
		});
	</script>
 </HEAD>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		<font color='red'><b>① 업체명 확인</b></font>&nbsp;→&nbsp;
		② 업체 정보 등록 및 선택&nbsp;→&nbsp;
		③ 입고정보 입력&nbsp;→&nbsp;
		④ 제품 정보 입력
		</td>
	</tr>
</table>
<br>
<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id ='$center_id_s'");
$center_name = mysql_result($center_query,0,0);
?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s11_com_name.value) {
      alert('업체명을 입력하세요!');
      form.s11_com_name.focus();
      return;
   }

           
   form.submit();
}

//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='write1_process.php?page=<? echo("$page"); ?>' enctype='multipart/form-data'>
<!------------------------- 업체명  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>업체명</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s11_com_name" id="search" autocomplete="off" size="64" maxlength="255" <?echo("$Form_style1");?>>

			</td>
		</tr>
</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>