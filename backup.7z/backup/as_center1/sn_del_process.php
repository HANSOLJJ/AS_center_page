<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 
  $query = "UPDATE $db14 SET cost_sn_hand = '' WHERE s14_aiid  = '$s14_aiid'";
  $result = mysql_query($query);
  if (!$result) {
	 error("QUERY_ERROR");
	 exit;
  }
    
 ##### 리스트 출력화면으로 이동한다.
echo("<meta http-equiv='Refresh' content='0; URL=list.php?reset=on'>");   
  ?>
