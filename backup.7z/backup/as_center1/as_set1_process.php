<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";



##### 
$s13_as_level = "2";
$s13_as_name1 = $HTTP_SESSION_VARS[member_name];

$query = "UPDATE $db13 SET s13_as_level  = '$s13_as_level', s13_as_name1  = '$s13_as_name1'  WHERE s13_asid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

if($s13_as_in_how =="택배" OR $s13_as_in_how =="퀵"){
include"sms_center_key.php";
//echo"$remote_callback";
include"sms.php";
}

//##### 리스트 출력화면으로 이동한다.
$encoded_key = urlencode($key);
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>