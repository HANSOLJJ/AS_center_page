<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

######추가 코드

$instant_query = "SELECT s15_amid, s15_model_name, s15_model_sn FROM $db15 WHERE s15_amid = '$s14_model'";

$instant_result = mysql_query($instant_query);
if(!$instant_result) {
   error("QUERY_ERROR");
   exit;
}
$instant_row = mysql_fetch_object($instant_result);

$my_s15_amid = $instant_row->s15_amid;
$my_s15_model_name = $instant_row->s15_model_name;
$my_s15_model_sn = $instant_row->s15_model_sn;

//echo"$my_s15_amid- $my_s15_model_name-$my_s15_model_sn ";

$instant_query2 = "SELECT s16_poor FROM $db16 WHERE s16_apid = '$s14_poor'";

$instant_result2 = mysql_query($instant_query2);
if(!$instant_result2) {
   error("QUERY_ERROR");
   exit;
}
$instant_row2 = mysql_fetch_object($instant_result2);

$my_s16_poor = $instant_row2->s16_poor;


######추가 코드 끝


$s14_stat ='입고';

$query = "INSERT INTO $db14 (s14_asid, s14_model, s14_poor, s14_stat, cost_name, cost_sn, as_start_view) VALUES ('$s14_asid', '$s14_model', '$s14_poor', '$s14_stat', '$my_s15_model_name', '$my_s15_model_sn', '$my_s16_poor')";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
  echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=write4&number=$number'>");
} 

?>
