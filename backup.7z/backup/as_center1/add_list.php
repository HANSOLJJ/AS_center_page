<table  width='100%' cellpadding='0' cellspacing='0' border='1' align='center'bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td  width='15%' height='40' background="<?echo "$border_bg1";?>">
		<p align='center'><b>모델명</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>시리얼</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>불량증상</b></p>
		</td>
	</tr>

<?
$query_item_list = "SELECT s14_aiid, s14_asid, s14_model, s14_poor, s14_stat, s14_as_nae, cost_name, cost_sn, cost_sn_hand, as_start_view  FROM $db14 WHERE s14_asid = '$my_s13_asid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}

while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s14_aiid = $row_item_list[s14_aiid];
$my_s14_asid = $row_item_list[s14_asid];
$my_s14_model = $row_item_list[s14_model];
$my_s14_poor = $row_item_list[s14_poor];
$my_s14_stat = $row_item_list[s14_stat];
$my_s14_as_nae = $row_item_list[s14_as_nae];

$my_cost_name = $row_item_list[cost_name];
$my_cost_sn = $row_item_list[cost_sn];
$my_cost_sn_hand = $row_item_list[cost_sn_hand];
$my_as_start_view = $row_item_list[as_start_view];

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_cost_name</td>");

if($in_code!="del"){
if($my_cost_sn_hand ==""){
echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><iframe name='frame$my_s14_aiid' src='sn_form.php?kin_num=$my_s14_aiid' width='100' height='35' scrolling='no' marginwidth='0' marginheight='0' frameborder='no' valign='middle'></iframe></td>");
}else{
echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>	$my_cost_sn_hand&nbsp;<a href='sn_del_process.php?s14_aiid=$my_s14_aiid'><img src='../$icon_dir/cart_del.gif' border='0' align='absmiddle'></a></td>");
}

}else{
if($my_cost_sn_hand ==""){$my_cost_sn_hand ="-";}
echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_cost_sn_hand</td>");
}
echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><font color='red'><b>$my_as_start_view</b></font></td>");
echo("</tr>");

}

?>
</table>