<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		<b>수탁 방법 수정</b>
		</td>
	</tr>
</table>
<br>
<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_as_in_how, s13_dex_no FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_asid = $row->s13_asid;
$my_s13_dex_no = $row->s13_dex_no;

?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s13_as_in_how.value) {
      alert('입고일을 입력하세요!');
      form.s13_as_in_how.focus();
      return;
   }
           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name='form' method='POST' action='modify2_process.php' enctype='multipart/form-data'>
<INPUT type='hidden' name='number' value="<? echo"$number";?>">
<INPUT type='hidden' name='s13_meid' value="<? echo"$my_s11_meid";?>">
<INPUT type='hidden' name='s13_as_in_how' value="퀵">

<!------------------------- 카테고리  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>수탁방법</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<a href='<? echo"list.php?in_code=modify2-1&number=$number";?>'>[내방]</a>&nbsp;&nbsp;
			<a href='<? echo"list.php?in_code=modify2-2&number=$number";?>'>[택배]</a>&nbsp;&nbsp;
			<b>[퀵]</B>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>