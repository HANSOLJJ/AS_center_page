<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$query = "INSERT INTO $db19 (s19_result) VALUES ('$s19_result')";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>
