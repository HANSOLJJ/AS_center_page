<?
##### 한 페이지당 출력할 게시물의 수
$num_per_page = 50;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;


if(!$page) {
   $page = 1;
}

##### 전체게시물의 총 개수를 각각 구한다.
$query = "SELECT count(s9_ouid) FROM $db9";

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>

<script language="javascript">
<!--
function profileWindow(ref) {
   var window_left = (screen.width-700)/2;
   var window_top = (screen.height-500)/2;   
   window.open(ref,"profileWin",'width=700,height=500,status=no,scrollbars=yes,top=' + window_top + ',left=' + window_left + '');
}
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
    <tr>
		<td width="33%" height='50' background="<?echo "$border_bg1";?>">
            <p align='center'><b>No.</b></p>
        </td>
        <td width="33%" height='50' background="<?echo "$border_bg1";?>">
            <p align='center'><b>센터명</b></p>
        </td>
        <td width="33%" height='50' background="<?echo "$border_bg1";?>">
            <p align='center'><b>출고일</b></p>
        </td>
    </tr>


<?
$time_limit = 60*60*24*$notify_new_article; 


##### 현재페이지의 범위내에 출력할 결과레코드세트를 얻는다.
 $query = "SELECT s9_ouid, s9_cartnum, s9_center_id, s9_completion, s9_signdate FROM $db9 ORDER BY s9_ouid DESC LIMIT $first, $num_per_page";

   
$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($info = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s9_ouid = $info[s9_ouid];
   $my_s9_cartnum = $info[s9_cartnum];   
   $my_s9_center_id = $info[s9_center_id];
   $my_s9_completion = $info[s9_completion];
   $my_s9_signdate = date("Y.m.d",$info[s9_signdate]);

//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id ='$my_s9_center_id'");
$center_name = mysql_result($center_query,0,0);


if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'"; $cell_color='#fbfbfb';}else{$td_bg="bgcolor='#FFFFFF'"; $cell_color='#FFFFFF';}

echo "<tr>";
   
echo " <td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>";

echo " <td height='35' align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=view&number=$my_s9_cartnum'>$center_name</a></td>";

echo " <td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_s9_signdate.</td>";
  
   echo("</tr>");      

   $article_num--;
}
?>
	
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
<tr>
   <td align="center">
<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&s3_center_id=$center_id_s&keyfield=$keyfield\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("<a href=\"list.php?in_code=list_view&page=$direct_page&s3_center_id=$center_id_s&keyfield=$keyfield\" >$direct_page</a>.&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&s3_center_id=$center_id_s&keyfield=$keyfield\" >→</a>");
}

?>
   </td>
</tr>
</table>
<br><br>