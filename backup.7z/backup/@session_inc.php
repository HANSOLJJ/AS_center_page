<?
// Set proper character encoding for Korean
header('Content-Type: text/html; charset=utf-8');
ini_set('default_charset', 'utf-8');
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');

// Output buffer with automatic EUC-KR to UTF-8 conversion
ob_start(function($buffer) {
    // Check if the buffer contains non-UTF-8 characters
    if (!preg_match('//u', $buffer)) {
        // Try to detect and convert from EUC-KR
        $converted = @mb_convert_encoding($buffer, 'UTF-8', 'EUC-KR,UTF-8,ASCII');
        if ($converted !== false && $converted != $buffer) {
            return $converted;
        }
    }
    return $buffer;
});

// MySQL compatibility layer for PHP 7.4+
require_once 'mysql_compat.php';

session_start();
//extract($HTTP_POST_VARS, EXTR_PREFIX_SAME, "");
//extract($HTTP_GET_VARS, EXTR_PREFIX_SAME, "");
//extract($HTTP_SESSION_VARS, EXTR_PREFIX_SAME, "");
//extract($HTTP_COOKIE_VARS, EXTR_PREFIX_SAME, "");
//extract($HTTP_SERVER_VARS, EXTR_PREFIX_SAME, "");
//extract($HTTP_POST_FILES, EXTR_PREFIX_SAME,"");
?>