<?php
/**
 * Session Management
 */

session_start();

class Session {
    public static function set($key, $value) {
        $_SESSION[$key] = $value;
    }

    public static function get($key, $default = null) {
        return isset($_SESSION[$key]) ? $_SESSION[$key] : $default;
    }

    public static function has($key) {
        return isset($_SESSION[$key]);
    }

    public static function delete($key) {
        unset($_SESSION[$key]);
    }

    public static function destroy() {
        session_destroy();
    }

    public static function is_logged_in() {
        return self::has('user_id') && self::has('user_level');
    }

    public static function get_user_id() {
        return self::get('user_id');
    }

    public static function get_user_level() {
        return self::get('user_level');
    }

    public static function login($user_id, $user_level, $user_name = '') {
        self::set('user_id', $user_id);
        self::set('user_level', $user_level);
        self::set('user_name', $user_name);
        self::set('login_time', time());
    }

    public static function logout() {
        self::destroy();
    }
}
?>
