<?
include "@config.php";
include "@error_function.php";
include "@access.php";
?>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>뱀ъ댄 愿由ы</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>
</head>
<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0' bgcolor='#e8e8e8'>

<table width='100%' Height='100%' border='0' cellpadding='0' cellspacing='0' align='center' >
	<tr>
		<td >&nbsp;&nbsp;
&nbsp;<a href="as_center1/list.php?reset=on" target='admin_target'> AS 怨 愿由</a>&nbsp;
&nbsp;<a href="as_center2/list.php?reset=on" target='admin_target'> AS 愿由</a></a>&nbsp;
&nbsp;<a href="as_center3/list.php?reset=on" target='admin_target'> AS 異怨 愿由</a>&nbsp;
&nbsp;<a href="as_center4/list.php?reset=on" target='admin_target'> AS  愿由</a>&nbsp;
&nbsp;<a href="as_center5/list.php?reset=on" target='admin_target'> AS 댁 愿由</a>&nbsp;
&nbsp;<a href="as_center_export/list.php" target='admin_target'>  異 愿由</a>&nbsp;
		</td>
	</tr>
</table>
