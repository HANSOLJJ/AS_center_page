<?
include "@config.php";
include "@error_function.php";
include "@access.php";
?>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>뱀ъ댄 愿由ы</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>
</head>
<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0' bgcolor='#e8e8e8'>

<table width='100%' Height='100%' border='0' cellpadding='0' cellspacing='0' align='center' >
	<tr>
		<td >&nbsp;&nbsp;
&nbsp;<a href="center/list.php?in_code=list_view&db=step1_center" target='admin_target'>AS 쇳 蹂 愿由</a>&nbsp;
&nbsp;<a href="parts_category/list.php?in_code=list_view" target='admin_target'>AS  移댄怨由 愿由</a>&nbsp;
&nbsp;<a href="parts/list.php?in_code=list_view&db=step1_parts" target='admin_target'>AS  愿由</a>&nbsp;
&nbsp;<a href="order/list.php?in_code=list_view&reset=on" target='admin_target'>AS  泥 愿由</a>&nbsp;
&nbsp;<a href="out/list.php?in_code=list_view" target='admin_target'>AS  異怨 愿由</a>&nbsp;
&nbsp;<a href="out_list/list.php?in_code=list_view" target='admin_target'>AS  異怨 댁</a>&nbsp;
&nbsp;<a href="parts_count/list.php?in_code=list_view" target='admin_target'>AS 쇳 ш </a>&nbsp;&nbsp;<a href="exl/list.php?in_code=list_view2" target='admin_target'>AS  泥援ш 臾몄異</a>&nbsp;
		</td>
	</tr>
</table>







