<table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
	<tr>
		 <td width="10%"  height='30'><p align='center'><b>No.</b></p></td>
		<td width="20%" ><p align='center'><b>소모품</b></p></td>
		<td width="20%" ><p align='center'><b>수량</b></p></td>
		<td width="50%" ><p align='center'><b>금액</b></p></td>
</tr>
<?

#####
$instant_query = "SELECT s21_accid, s21_uid, s21_quantity, s21_signdate, s21_end, s21_sp_cost, cost1, cost_name, cost_sn, cost1, cost2, cost_sec   FROM $db21 WHERE s21_sellid = '$my_s20_sellid '";

$instant_result = mysql_query($instant_query);
if(!$instant_result) {
   error("QUERY_ERROR");
   exit;
}

$instant_rows = mysql_num_rows($instant_result);
if($instant_rows > 0) {
$total_cost = '0';
$no='0';
   while($instant_reply = mysql_fetch_object($instant_result)) {


$my_s21_accid = $instant_reply->s21_accid;
$no++;
$my_s21_uid = $instant_reply->s21_uid;
$my_s21_quantity = $instant_reply->s21_quantity;
$my_s21_end = $instant_reply->s21_end;
$my_s21_sp_cost = $instant_reply->s21_sp_cost;

//------------------추가코드
	   $my_cost_name = $instant_reply->cost_name;
	   $my_cost_sn = $instant_reply->cost_sn;
	   $my_cost1 = $instant_reply->cost1;
	   $my_cost2 = $instant_reply->cost2;
	   $my_cost_sec = $instant_reply->cost_sec;

//------------------가격정보
if($my_s21_sp_cost ==""){
	$parts_cost = $my_cost1 * $my_s21_quantity; $my_cost= $my_cost1;
	}else{
	$parts_cost = $my_cost2 * $my_s21_quantity;$my_cost= $my_cost2;
	}

$my_cost = number_format($my_cost);	
$n_parts_cost = number_format($parts_cost );	

//------------------데이터 불러오기


print "	
<tr >
<td height='50' align='center' valign='middle'><b>$no</td>
<td align='left'>
&nbsp;-&nbsp;$my_cost_name&nbsp;&nbsp;[$my_cost_sn]
</td>
<td align='right'>
<font color='red'><b>$my_s21_quantity&nbsp;개</b>&nbsp;</font><br>
 </td>
 <td align='right'>
<font color='red'><b>$my_cost</b>&nbsp;X $my_s21_quantity = $n_parts_cost </font>
";


//$total_cost = $total_cost + $parts_cost;

$total_cost = $total_cost + $parts_cost;

   }

}

$total_cost = number_format($total_cost);
$total_cost = $total_cost."&nbsp;원";

$no = $no+1;
print "
 </td>
 </tr>
 <tr>
	<td height='50' align='center' valign='middle'>
<b>$no</b>
	</td>
	<td>
	처리비용
	</td>
	<td>
&nbsp;
	</td>
	<td align='right'><font color='red'><b>
 ";
include"add_sum_total_cost_sell.php";
print "
 &nbsp;</b></font></td>
 </tr> 
 ";
?>
</table>

