<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s20_sellid, s20_as_in_no, s20_as_center, s20_sell_in_date, s20_total_cost, s20_bank_check, s20_tax_code, s20_dex_send, s20_dex_send_name, s20_as_out_date, s20_as_level, s20_sell_name1, s20_meid, s20_bankcheck_w FROM $db20 WHERE s20_sellid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s20_sellid = $row->s20_sellid;
$my_s20_as_in_no = $row->s20_as_in_no;
$my_s20_as_center = $row->s20_as_center;
$my_s20_sell_in_date = $row->s20_sell_in_date;
$my_s20_total_cost = $row->s20_total_cost;

$my_s20_bank_check = $row->s20_bank_check;
$my_s20_tax_code = $row->s20_tax_code;
$my_s20_dex_send = $row->s20_dex_send;
$my_s20_dex_send_name = $row->s20_dex_send_name;
$my_s20_as_out_date = $row->s20_as_out_date;
$my_s20_as_level = $row->s20_as_level;
$my_s20_sell_name1 = $row->s20_sell_name1;
$my_s20_meid = $row->s20_meid;

$my_s20_as_out_date =date("Y년 m월 d일",$my_s20_as_out_date);$my_s20_bank_check= date("Y년 m월 d일",$my_s20_bank_check);
if($my_s13_tax_code != ""){$tax_on ="발행";}else{$tax_on ="미발행";}

if($my_s13_dex_send_name == ""){$dex_send ="&nbsp;";} else {$dex_send ="$my_s13_dex_send_name<br>($my_s13_dex_send)";}

$my_s13_total_cost =$my_s13_total_cost + "2500";
$my_s13_total_cost = number_format($my_s13_total_cost);	
$s13 = $row->s20_bankcheck_w;if($s13 =='center'){$s13 ="센터 현금납부";}elseif($s13 =='base'){$s13 ="계좌이체";}elseif($s13 ==''){$s13 ="3월 8일 이후  확인가능";}
//------------------센터명
$center_query = mysql_query("Select s2_center FROM step2_center WHERE s2_center_id ='$my_s20_as_center'");
$center_name = mysql_result($center_query,0,0);

//------------------업체명

$instant_query = "Select s11_com_name, s11_sec, s11_oaddr, s11_phone1, s11_phone2, s11_phone3, s11_com_num1, s11_com_num2, s11_com_num3 FROM $db11 WHERE s11_meid  ='$my_s20_meid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $s11_com_name=$instant_reply->s11_com_name;
	   $s11_sec=$instant_reply->s11_sec;
	   $s11_oaddr=$instant_reply->s11_oaddr;
	   $s11_phone1=$instant_reply->s11_phone1;
	   $s11_phone2=$instant_reply->s11_phone2;
	   $s11_phone3=$instant_reply->s11_phone3;

	   $s11_com_num1=$instant_reply->s11_com_num1;
	   $s11_com_num2=$instant_reply->s11_com_num2;
	   $s11_com_num3=$instant_reply->s11_com_num3;

	   $phone_num = $s11_phone1."-".$s11_phone2."-".$s11_phone3;
	   if($s11_com_num1 !=""){$com_num =$s11_com_num1."-".$s11_com_num2."-".$s11_com_num3;}else{$com_num="-";}
	
   }

}

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<p align='left'><img src='logo1.jpg' width='100'></p>
<table border="0" width="100%" >
    <tr>
        <td width="50%" valign="top">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td colspan="3" width="100%" height='50'>
                        <p align='center'><font size='4'><b>A/S 접수 및 처리 내역서</b></font></p>
                    </td>
                </tr>
                <tr>
                    <td width="10%" rowspan="4"><p align='center'><b>공<br>급<br>자</b></p></td>
                    <td width="45%" height='30'><p align='center'><b>상호</b></p></td>
                    <td width="45%"><p align='center'>(주)디지탈컴</p></td>
                </tr>
                <tr>
                    <td width="45%"  height='30'><p align='center'><b>사업자등록번호</b></p></td>
                    <td width="45%"><p align='center'>116-81-75974</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>처리지점</b></p></td>
                    <td width="45%"><p align='center'><? echo"$center_name";?></p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>A/S 처리기사</b></p></td>
                    <td width="45%"><p align='center'><? echo"$my_s20_sell_name1";?></p></td>
                </tr>
            </table>
        </td>
        <td width="50%" valign="top">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td colspan="2" width="50%" height='30'>
                        <p align='center'><b>접수번호</b></p>
                    </td>
                    <td width="50%"><p align='center'><? echo"$my_s20_as_in_no";?></p></td>
                </tr>
                <tr>
                    <td colspan="2" width="50%" height='30'><p align='center'><b>일자</b></p></td>
                    <td width="50%"><p align='center'><? echo"$my_s20_as_out_date";?></p></td>
                </tr>
                <tr>
                    <td width="10%"  rowspan="4"><p align='center'><b>접수신청</b></p></td>
                    <td width="45%" height='30'><p align='center'><b>상호</b></p></td>
                    <td width="45%"><p align='center'><? echo"$s11_com_name";?>&nbsp;귀하</p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>연락처</b></p></td>
                    <td width="45%"><p align='center'><? echo"$phone_num";?></p></td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>세금계산서발행</b></p></td>
                    <td width="45%">
                        <p align='center'><? echo"$tax_on";?></p>
                    </td>
                </tr>
                <tr>
                    <td width="45%" height='30'><p align='center'><b>사업자등록번호</b></p></td>
                    <td width="45%"><p align='center'><? echo"$com_num";?></p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
		
			 <table border="0" width="100%" height='30'>
				<tr>
					<td>
					<p align='left'><font size='3'><b>판매 내역 및 비용</b></font></p>
					</td>
				</tr>
			</table>
           <?include"test_s_part_list.php";?>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="25%" height='30'><p align='center'><b>입금계좌번호</b></p></td>
                    <td colspan="3" width="75%"><p align='center'><b>신한 140-005-221339 (주)디지탈컴 정용호</b></p></td>
                </tr>
                <tr>                    <td width="25%" height='30'><p align='center'><b>대금지급</b></p></td>                    <td width="25%"><p align='center'><b><?echo"$s13"; ?></b></p></td>                    <td width="25%"><p align='center'><b>입금일자</b></p></td>                    <td width="25%"><p align='center'><? echo"$my_s20_bank_check";?></p></td>                </tr>                <tr>                    <td  height='30'><p align='center'><b>A/S 처리완료일</b></p></td>                    <td><p align='center'><? echo"$my_s20_as_out_date";?></p></td>                    <td ><p align='center'><b>&nbsp;</b></p></td>                    <td><p align='center'>&nbsp;</p></td>                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
                <tr>
                    <td width="100%" colspan="3" height='30'><p align='center'><b>디지탈컴 A/S 센터</b></p></td>
                </tr>
                <tr>
                    <td width="15%" height='30'><p align='center'><b>지점</b></p></td>
                    <td width="60%"><p align='center'><b>주소</b></p></td>
                    <td width="25%" ><p align='center'><b>전화번호</b></p></td>
                </tr>
                <tr>
                    <td  height='30'><p align='center'><b>영등포</b></p></td>
                    <td><p align='left'>[우 150-723]서울특별시 영등포구 영등포로 109, 3층 가열 8호 (당산동2가,영등포 유통상가)</p></td>
                    <td><p align='center'>02-2671-9193</p></td>
                </tr>
                <tr>
                    <td height='30' ><p align='center'><b>을지로</b></p></td>
                    <td ><p align='left'>[우 100-340]서울특별시 중구 을지로 157, 라열 377호 (산림동, 대림상가)</p></td>
                    <td ><p align='center'>02-2275-9193</p></td>
                </tr>				<tr>                    <td  height='30'><p align='center'><b>본사</b></p></td>                    <td><p align='left'>[우 421-742]경기도 부천시 오정구 석천로 397, 303동 801호-804호 (삼정동, 부천테크노파크 쌍용3차)</p></td>                    <td><p align='center'>032-624-1980</p></td>                </tr>
                <tr>
                    <td width="75%"  colspan="2" height='30'><p align='center'><b>기술상담문의</b></p></td>
                    <td width="25%" height="0"><p align='center'>1577-9193</p></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2">※ A/S 택배 접수시 불량증상을 적어서 보내주시면 더욱 신속하게 처리됩니다.</td>
    </tr>
    <tr>
        <td colspan="2">※테두리가 진하게 표시된 네모박스안에 반드시 명기해 주세요.</td>
    </tr>
</table>
<p>&nbsp;</p>
<p align='right'>
		<?echo"<a href=\"javascript://\" onClick=\"profileWindow('print.php?number=" . $number . "')\">";?>
		<img src='../<?echo("$icon_dir");?>/button_print.gif' align='absmiddle' border='0'>
		</a>&nbsp;
		<a href='<?  echo"list.php?in_code=list_view3&last_sec1=$last_sec1&s_year=$s_year&s_month=$s_month&s_day=$s_day&e_year=$e_year& e_month=$e_month&e_day=$e_day&keyfield=$keyfield&key=$key&reset=$reset&page=$page";?>'>
		<img src='../<?echo("$icon_dir");?>/button_blue_list.gif' align='absmiddle' border='0'>
		</a>
		<p>&nbsp;</p>
