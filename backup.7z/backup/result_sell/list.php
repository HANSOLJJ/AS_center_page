<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>

<script language="javascript">
<!--
function profileWindow(ref) {
   var window_left = (screen.width-700)/2;
   var window_top = (screen.height-500)/2;   
   window.open(ref,"profileWin",'width=700,height=500,status=no,scrollbars=yes,top=' + window_top + ',left=' + window_left + '');
}
//-->
</script>

<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<?
$title_front = "<table width='95%' border='0' align='center' height='30'><tr><td style='border-bottom-width:2px; border-bottom-color:rgb(233,233,233); border-bottom-style:solid;'><p align='left'><SPAN class='admin_title_big'>■ ";
$title_end = "</span></p></td></tr></table><br>";

$title_b = $title_front ."판매내역  ". $title_end;

echo"$title_b"; 

switch ($in_code) {

// 일반페이지


case ("") : 	include"list_view.php"; Break;
case ("list_view2") : 	include"list_view3.php"; Break;
case ("list_view3") : 	include"list_view3.php"; Break;
case ("set2") : 	include"set2.php"; Break;
}

?>
