<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$query = "UPDATE $db15 SET s15_model_name = '$s15_model_name', s15_model_sn = '$s15_model_sn' WHERE s15_amid  = '$number'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>
