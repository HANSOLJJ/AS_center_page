<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s15_amid, s15_model_name, s15_model_sn FROM $db15 WHERE s15_amid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s15_amid = $row->s15_amid;
$my_s15_model_name = $row->s15_model_name;
$my_s15_model_sn = $row->s15_model_sn;

##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {
	
	if(!form.s15_model_name.value) {
      alert('모델명을 입력하세요!');
      form.s15_model_name.focus();
      return;
   }

   if(!form.s15_model_sn.value) {
      alert('시리얼 번호를 입력하세요!');
      form.s15_model_sn.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>

<!------------------------- 이름  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>모델명</b>
			</td>
			<td width='70%'>
			<input type="text" name="s15_model_name" size="64" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_s15_model_name");?>'>
			</td>
		</tr>
<!------------------------- sn  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>시리얼 번호</b>
			</td>
			<td width='70%'>
			<input type="text" name="s15_model_sn" size="64" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_s15_model_sn");?>'>
			</td>
		</tr>



</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>