<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 테이블에서 해당 파일의 레코드를 삭제한다.
$result = mysql_query("DELETE FROM $db15 WHERE s15_amid = $number");

if (!$result) {
 error("QUERY_ERROR");
 exit;
}

##### 리스트 출력화면으로 이동한다.
$encoded_key = urlencode($key);
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>