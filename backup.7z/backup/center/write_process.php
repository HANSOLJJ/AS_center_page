<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 사용자가 아무값도 입력하지 않았거나 입력한 값이 허용되지 않는 값일 경우 에러메시지를 출력하고 스크립트를 종료한다.

if(!ereg("([^[:space:]]+)", $s2_center)) {
   error("NOT_ALLOWED_s2_center");
   exit;
}

$s2_center_id = "center".time();


$query = "INSERT INTO $db (s2_center_id, s2_center,s2_center_tel) VALUES ('$s2_center_id', '$s2_center', '$s2_center_tel')";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>
