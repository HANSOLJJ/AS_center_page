<?
if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 15;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if(!eregi("[^[:space:]]+",$key)) {
   $query = "SELECT count(*) FROM $db";
} else {
   $encoded_key = urlencode($key);
   $query = "SELECT count(*) FROM $db WHERE $keyfield LIKE '%$key%'";  
}

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='50' align='left'>
		<b>[ 해당 조건에 검색된 등록된 AS 센터 : <?echo"$total_record ";?> 개 ]</b>
		</td>
	</tr>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='5%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>No</b></p>
		</td>
		<td  width='55%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>센터명</b></p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>전화번호</b></p>
		</td>
		<td width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>수정</b></p>
		</td>
		<td width='10%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>삭제</b></p>
		</td>
	</tr>

<?

$time_limit = 60*60*24*$notify_new_article; 

#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
if(!eregi("[^[:space:]]+",$key)) {
   $query = "SELECT s2_cid, s2_center_id, s2_center, s2_center_tel FROM $db ORDER BY s2_cid DESC LIMIT $first, $num_per_page";
} else {
   $query = "SELECT s2_cid, s2_center_id, s2_center, s2_center_tel FROM $db WHERE $keyfield LIKE '%$key%' ORDER BY s2_cid DESC LIMIT $first, $num_per_page";
}
$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

if($total_record=='0'){print"<tr><td height='200' colspan='5'><table width='600' align='center' cellspacing='0' cellpadding='0'  border='0' ><tr><td height='160'><p align='center'>등록된 데이터가 없습니다.</p></td></tr></table></td></tr>";}


##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s2_cid = $row[s2_cid];
   $my_s2_center_id = $row[s2_center_id];
   $my_s2_center = $row[s2_center];
   $my_s2_center_tel = $row[s2_center_tel];
  
##### 원칙상 제목에는 HTML 태그를 허용하지 않는다.
$my_s2_center = htmlspecialchars($my_s2_center);

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}
//--------------------------------------------------------------------
echo("<tr>");


##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

echo("<td align='left' valign='middle' $list_style1 $td_bg LeftMargin='10'>$my_s2_center</td>");
echo("<td align='left' valign='middle' $list_style1 $td_bg LeftMargin='10'>$my_s2_center_tel</td>");
##### 

echo("	<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=modify&number=$my_s2_cid'><img src='../$icon_dir/button_blue_modify.gif' border='0'></a></td>");

##### 

echo("	<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=del&number=$my_s2_cid'><img src='../$icon_dir/button_blue_del.gif' border='0'></a></td>");

$article_num--;
}
echo("</table>");
?>

<table  width='95%' height='50' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>
<form method="post" action="<?echo("list.php?in_code=list_view")?>">


							
							<td align='left' width='33%'>
							<select name="keyfield" size="1" align='absmiddle' <?echo("$Form_style1");?>>
							   <option value="s2_center">센터명</option>
							</select>
							&nbsp;&nbsp;
							<input type="text" name="key" size='18' <?echo("$Form_style1");?>>&nbsp;&nbsp;&nbsp;
							<input type='submit' STYLE='font-size:9pt;' value='검색'>
							</td>
							
						</form>
<td  align='center' width='33%'>

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php&in_code=list_view&page=$my_page&keyfield=$keyfield\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("<a href=\"list.php&in_code=list_view&page=$direct_page&keyfield=$keyfield\" >$direct_page</a>.&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php&in_code=list_view&page=$my_page&keyfield=$keyfield\" >→</a>");
}

?>
</td>
<td width='33%'>


<?
if($HTTP_SESSION_VARS["member_id"] !="" AND $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "1"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "2"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";} else
if($HTTP_SESSION_VARS["member_id"] !="" AND  $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "3"){print"<p align='right'><a href='list.php?in_code=write&page=$page&db=$db'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";}
?>
		</td>
	</tr>
</table>
