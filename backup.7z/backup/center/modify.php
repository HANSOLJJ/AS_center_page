<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s2_cid, s2_center_id, s2_center, s2_center_tel FROM $db WHERE s2_cid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s2_cid = $row->s2_cid;
$my_s2_center_id = $row->s2_center_id;
$my_s2_center = $row->s2_center;
$my_s2_center_tel = $row->s2_center_tel;

##### 제목과 본문에 대하여 테이블에 저장할 때(post.php) addslashes() 함수로 escape시킨 문자열을 원래대로 되돌려 놓는다.
$my_s2_center = stripslashes($my_s2_center);

##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {
	
	if(!form.s2_center.value) {
      alert('센터명을 입력하세요!');
      form.s2_center.focus();
      return;
   }
 if(!form.s2_center_tel.value) {
      alert('센터전화번호를 입력하세요!');
      form.s2_center_tel.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>

<!------------------------- 이름  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>센터명</b>
			</td>
			<td width='70%'>
			<input type="text" name="s2_center" size="64" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_s2_center");?>'>
			</td>
		</tr>
<!------------------------- 전화  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>전화번호</b>
			</td>
			<td width='70%'>
			<input type="text" name="s2_center_tel" size="64" maxlength="16" <?echo("$Form_style1");?>  value='<? echo("$my_s2_center_tel");?>'>
			</td>
		</tr>
</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>