<script language="javascript">
<!--
function sendit() {
	
	if(!form.s2_center.value) {
      alert('센터명을 입력하세요!');
      form.s2_center.focus();
      return;
   }
   if(!form.s2_center_tel.value) {
      alert('센터전화번호를 입력하세요!');
      form.s2_center_tel.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='write_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>' enctype='multipart/form-data'>

<!------------------------- 이름  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>센터명</b>
			</td>
			<td width='70%'>
			<input type="text" name="s2_center" size="64" maxlength="255" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 전화  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>전화번호</b>
			</td>
			<td width='70%'>
			<input type="text" name="s2_center_tel" size="64" maxlength="16" <?echo("$Form_style1");?>>
			</td>
		</tr>
</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>