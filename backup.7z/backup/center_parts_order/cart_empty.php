<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 테이블에서 해당 파일의 레코드를 삭제한다.
$result = mysql_query("DELETE FROM $db4 WHERE s4_center_id  = '$center_id_s' && s4_end = 'N'");
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

##### 리스트 출력화면으로 이동한다.

echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");  
?>