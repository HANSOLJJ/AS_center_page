<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s1_uid , s1_caid, s1_name FROM $db1 WHERE s1_uid = '$number'";

$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$row = mysql_fetch_row($result);

$my_s1_uid = $row[0];
$my_s1_caid = $row[1];
$my_s1_name = $row[2];



$id = $HTTP_SESSION_VARS["member_id"];
$member_center_id = $HTTP_SESSION_VARS["member_center_id"];

$signdate = time();

##### 테이블에 입력값을 등록한다.
$query = "INSERT INTO $db4 (s4_center_id, s4_center_member, s4_uid,  s4_quantity,  s4_signdate,  s4_end) VALUES ('$member_center_id', '$id', '$my_s1_uid', '1', '$signdate', 'N')";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

   ##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view&page=$page&keyfield=$keyfield&key=$key'>");
} 

?>
