<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

$result = mysql_query("SELECT count(s4_vid) FROM $db4 WHERE s4_center_id = '$center_id_s' && s4_end ='N' ");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$total_record = mysql_result($result,0,0);
mysql_free_result($result);

?>
<p align='center'><b>주문 항목</b></p>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE' class="body">
	<tr>
		<td  height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>번호</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>카테고리</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>ERP</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>자재명</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>수량</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>삭제</b></p>
		</td>
	</tr>
<?

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s4_vid, s4_center_id, s4_uid, s4_quantity FROM $db4 WHERE s4_center_id = '$center_id_s' AND s4_end ='N'";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$nno ='0';

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s4_vid = $row[s4_vid];
   $my_s4_center_id = $row[s4_center_id];
   $my_s4_uid = $row[s4_uid];
   $my_s4_quantity = $row[s4_quantity];

$nno++;


##### 선택한 게시물의 입력값을 뽑아낸다.
$query2 = "SELECT s1_uid, s1_caid, s1_erp, s1_name FROM $db1 WHERE s1_uid = '$my_s4_uid'";
$result2 = mysql_query($query2);
if(!$result2) {
   error("QUERY_ERROR");
   exit;
}
$row2 = mysql_fetch_row($result2);
 
$my_s1_uid = $row2[0];
$my_s1_caid = $row2[1];
$my_s1_erp = $row2[2];
$my_s1_name = $row2[3];


//------------------카테고리명 부르기
$category_query = mysql_query("Select s5_category FROM $db5 WHERE s5_caid ='$my_s1_caid'");
$my_s1_caid = mysql_result($category_query,0,0);

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}

 ##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<tr><td height='35'  $list_style1 $td_bg align='center'>$nno</td>");

##### 

echo("<td align='center'  $list_style1 $td_bg><p>$my_s1_caid</p></td>");

##### 

echo("<td align='center'  $list_style1 $td_bg><p>$my_s1_erp</p></td>");

##### 

echo("<td align='center'  $list_style1 $td_bg><p>$my_s1_name</p></td>");


echo("<td align='center' $list_style1 $td_bg><p>");

echo("<iframe name='frame$article_num' src='num.php?s4_vid=$my_s4_vid&my_s4_quantity=$my_s4_quantity&keyfield=$keyfield&key=$key' width='100' height='35' scrolling='no' marginwidth='0' marginheight='0' frameborder='no' valign='middle'></iframe>");

echo("</p></td>");


//print"
//<td width='71'  $list_style1 $td_bg align='center'>
//<table cellpadding='0' cellspacing='0' width='20' height='16'>
//    <tr>
//        <td width='12' rowspan='2'>
//		$my_s4_quantity&nbsp;           
//        </td>
//        <td>
//		<A href='cart_item_plus.php?number=$my_s4_vid'><img src='../$icon_dir/item_plus.gif' border='0' align='absmiddle'></a>            
//        </td>
//    </tr>
//    <tr>
//        <td>
//		<A href='cart_item_minus.php?number=$my_s4_vid&number3=$my_s4_quantity'><img src='../$icon_dir/item_minus.gif' border='0' align='absmiddle'></a>             
//        </td>
//    </tr>
//</table>
//</td>	";



echo("<td align='center'  $list_style1 $td_bg><a href='cart_item_del.php?number=$my_s4_vid&keyfield=$keyfield&key=$key'><img src='../$icon_dir/cart_del.gif' border='0'></a></td>");

$article_num--;
}
if($total_record == '0'){print"<table width='95%' align='center' cellspacing='0' cellpadding='0'  border='1' class='body' bordercolor='#dedede' bordercolordark='white' bordercolorlight='#dedede'><tr><td height='160'><p align='center'>장바구니가 비어있습니다.</p></td></tr></table>";}


?>


<table width='100%' align='center' cellspacing='0' cellpadding='0'  border='0' class='body'>
	<tr>
		<td align='center'>
		<br><br>
		&nbsp;
<?if(!$total_record == '0'){print"<a href='list.php?in_code=cart_view'><img src='../$icon_dir/cart_order_b.gif' border='0'></a>&nbsp;<a href='cart_empty.php?center_id_s=$my_s4_center_id'><img src='../$icon_dir/cart_empty_b.gif' border='0'></a>";}?>

		</td>
	</tr>
</table>