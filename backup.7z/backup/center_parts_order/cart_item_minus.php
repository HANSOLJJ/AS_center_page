<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$my_min_buy = '1';

##### 사용자가 아무값도 입력하지 않았거나 입력한 값이 허용되지 않는 값일 경우 에러메시지를 출력하고 스크립트를 종료한다.

if($number3 <= $my_min_buy) {
   error("NOT_ALLOWED_LOWQUANTITY");
   exit;
}

##### 선택한 게시물의 입력값을 뽑아낸다.
$query3 = "SELECT s4_vid, s4_quantity  FROM $db4 WHERE s4_vid = $number";
$result3 = mysql_query($query3);
if(!$result3) {
   error("QUERY_ERROR");
   exit;
}

$row3 = mysql_fetch_row($result3);

$my_s4_vid = $row3[0];
$my_s4_quantity = $row3[1];

##### 게시물의 암호와 사용자가 입력한 암호가 같으면 게시물을 수정한다. 
  $query = "UPDATE $db4 SET s4_quantity = '$my_s4_quantity'-1 WHERE s4_vid  = $number";
  $result = mysql_query($query);
  if (!$result) {
	 error("QUERY_ERROR");
	 exit;
  }
    
 ##### 리스트 출력화면으로 이동한다.
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");  
  
  
  ?>
