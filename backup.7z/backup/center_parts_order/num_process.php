<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 게시물의 암호와 사용자가 입력한 암호가 같으면 게시물을 수정한다. 
  $query = "UPDATE $db4 SET s4_quantity  = '$s4_quantity' WHERE s4_vid  = '$s4_vid'";
  $result = mysql_query($query);
  if (!$result) {
	 error("QUERY_ERROR");
	 exit;
  }
    
 ##### 리스트 출력화면으로 이동한다.
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view&keyfield=$keyfield&key=$key'>");   
  
  
  ?>
