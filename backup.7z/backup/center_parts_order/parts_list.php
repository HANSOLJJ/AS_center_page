<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 20;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if(!eregi("[^[:space:]]+",$key)) {
	$query = "SELECT count(*) FROM $db1";
} else {
   $encoded_key = urlencode($key);
   $query = "SELECT count(*) FROM $db1 WHERE $keyfield LIKE '%$key%'";  
}



$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>
<p align='center'><b>자재 리스트</b></p>

<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>
<form method="post" action="<?echo("list.php?in_code=list_view&page=$my_page&keyfield=$keyfield")?>">

							
							<td width='280' height='35'>
							<select name="keyfield" size="1" align='absmiddle' <?echo("$Form_style1");?>>
							   <option value="s1_name">자재명</option>
							   <option value="s1_erp">ERP CODE</option>
							</select>
							&nbsp;&nbsp;
							<input type="text" name="key" size='18' <?echo("$Form_style1");?>>&nbsp;&nbsp;&nbsp;
							<input type='submit' STYLE='font-size:9pt;' value='검색'>
							</td>
							
						</form>
						</tr>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE' class="body">
	<tr>
		<td  height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>번호</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>카테고리</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>ERP</b></p>
		</td>
		<td background="<?echo "$border_bg1";?>">
			<p align="center"><b>자재명</b></p>
		</td>
		<td background="<?echo "$border_bg1";?>">
			<p align="center"><b>재고량</b></p>
		</td>
		<td background="<?echo "$border_bg1";?>">
			<p align="center"><b>담기</b></p>
		</td>
	</tr>

<?
##### 
$time_limit = 60*60*24*$notify_new_article; 



if(!eregi("[^[:space:]]+",$key)) {
		$query = "SELECT s1_uid, s1_caid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1 FROM $db1 ORDER BY s1_caid ASC LIMIT $first, $num_per_page";
} else {
		$query = "SELECT s1_uid, s1_caid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1 FROM $db1 WHERE $keyfield LIKE '%$key%' ORDER BY s1_caid ASC LIMIT $first, $num_per_page";
}


$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
  $my_s1_uid = $row[s1_uid];
   $my_s1_caid = $row[s1_caid];
   $my_s1_erp = $row[s1_erp];
   $my_s1_name = $row[s1_name];
   $my_s1_cost_c_1 = $row[s1_cost_c_1];
   $my_s1_cost_a_1 = $row[s1_cost_a_1];
   $my_s1_cost_a_2 = $row[s1_cost_a_2];
   $my_s1_cost_n_1 = $row[s1_cost_n_1];
   $my_s1_cost_n_2 = $row[s1_cost_n_2];
   $my_s1_cost_s_1 = $row[s1_cost_s_1];
 

if($my_s1_caid % 9 =="1"){$my_color='#fdc689';}else
if($my_s1_caid % 9 =="2"){$my_color='#fff200';}else
if($my_s1_caid % 9 =="3"){$my_color='#c69c6d';}else
if($my_s1_caid % 9 =="4"){$my_color='#7accc8';}else
if($my_s1_caid % 9 =="5"){$my_color='#7cc57';}else
if($my_s1_caid % 9 =="6"){$my_color='#cccccc';}else
if($my_s1_caid % 9 =="7"){$my_color='#fff200';}else
if($my_s1_caid % 9 =="8"){$my_color='#f5989d';}else
if($my_s1_caid % 9 =="9"){$my_color='#f5989d';}

//------------------카테고리명 부르기
$category_query = mysql_query("Select s5_category FROM $db5 WHERE s5_caid ='$my_s1_caid'");
$my_s1_caid = mysql_result($category_query,0,0);

//------------------센터 재고 부르기

$instant_query = "Select s7_num FROM $db7 WHERE s7_center_id ='$center_id_s' AND s7_uid ='$my_s1_uid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $center_num=$instant_reply->s7_num;
	
   }

}else{$center_num='0';}


echo("<tr>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td height='35' align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$article_num.</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$my_s1_caid</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$my_s1_erp</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$my_s1_name</p></td>");

#####

echo("<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$center_num</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

$cart_query = mysql_query("Select count(s4_vid) FROM $db4 WHERE s4_uid ='$my_s1_uid' AND s4_center_id ='$center_id_s' AND s4_end ='N'"); 

$cart_nums = mysql_result($cart_query,0,0);

if($cart_nums=='0') {
echo"<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p align='center'><a href='into_cart.php?number=$my_s1_uid&page=$page&keyfield=$keyfield&key=$key'><img src='../$icon_dir/cart_into.gif' border='0'></a></p></td>";} else {
echo"<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p align='center'>-</p></td>";
}




echo("</tr>");

$article_num--;
}
echo("</table>");
?>

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&keyfield=$keyfield&key=$key\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("[<a href=\"list.php?in_code=list_view&page=$direct_page&keyfield=$keyfield&key=$key\" >$direct_page</a>]&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&keyfield=$keyfield&key=$key\" >→</a>");
}

?>
<p>&nbsp; </p><p> &nbsp;</p>