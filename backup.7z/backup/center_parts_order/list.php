<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>


<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<? echo"$title_b_5"; ?>

<?
switch ($in_code) {

// 일반페이지

case ("") : 	
	print"<table width='100%' align='center' cellspacing='0' cellpadding='0'>
			<tr>
				<td align='center' width='50%' valign='top'>";
				include"parts_list.php";
	print"</td>
	<td width='50%' valign='top' align='center'>";
	include"cart_view.php";
	print"</td>
	</tr>
	</table>"; 
	Break;
case ("list_view") : 
	print"<table width='100%' align='center' cellspacing='0' cellpadding='0'>
			<tr>
				<td align='center' width='50%' valign='top'>";
				include"parts_list.php";
	print"</td>
	<td width='50%' valign='top' align='center'>";
	include"cart_view.php";
	print"</td>
	</tr>
	</table>"; 
	Break;
case ("write") : 	include"write.php"; Break;
case ("modify") : 	include"modify.php"; Break;
case ("del") : 	include"del.php"; Break;
case ("view") : 	include"view.php"; Break;
case ("call") : 	include"call.php"; Break;
case ("cart_view") : 	include"cart_view2.php"; Break;
case ("call_end") : 	include"call_end.php"; Break;
}

?>
