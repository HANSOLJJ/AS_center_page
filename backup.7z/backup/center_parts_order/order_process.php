<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 

$s6_signdate = time();

$id = $HTTP_SESSION_VARS["member_id"];
$member_center_id = $HTTP_SESSION_VARS["member_center_id"];

$s6_completion ='주문접수';

$s6_cartnum = time();

##### 회원정보 테이블에 입력값을 등록한다.
$query = "INSERT INTO $db6 (s6_cartnum, s6_center_id, s6_center_member, s6_completion, s6_signdate) VALUES ('$s6_cartnum', '$member_center_id', '$id', '$s6_completion', '$s6_signdate')";

$result = mysql_query($query);

if (!$result) {
         error("QUERY_ERROR");
         exit;
      }

##### 

$query2 = "UPDATE $db4 SET s4_end = 'Y', s4_cartnum = '$s6_cartnum' WHERE s4_center_id  = '$member_center_id' AND s4_end ='N'";

$result2 = mysql_query($query2);

if (!$result2) {
         error("QUERY_ERROR");
         exit;
      }

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=call_end'>");

?>
