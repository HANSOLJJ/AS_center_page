<?php
/**
 * AS System - Main Entry Point (원본 구조 기반)
 * 로그인 확인 및 로그인 페이지로 리다이렉트
 */

header('Content-Type: text/html; charset=utf-8');
session_start();

// 로그인 확인 - member_id 세션 확인
if (!isset($_SESSION['member_id']) || empty($_SESSION['member_id'])) {
    // 로그인 페이지로 리다이렉트
    header('Location: login.php');
    exit;
}

// 로그인된 상태 - 대시보드로 리다이렉트
header('Location: dashboard.php');
exit;
?>
