# Backup - Legacy Code Archive

**생성일**: 2025-11-10  
**목적**: 레거시 PHP 파일 및 레거시 구조 보관

## 📦 포함된 항목

### 1. 레거시 PHP 파일들
- `lcm1.php ~ lcm3.php` - 레거시 설정 파일
- `lhm1.php ~ lhm6.php` - 레거시 헬퍼 파일
- `index.php.new`, `index2.php`, `index201102.php` - 구 버전 인덱스 파일
- `index_include.php` - 구 include 파일

### 2. 레거시 폴더 구조 (as_center* 시리즈)
- `as_center/` - 초기 AS 센터 구현
- `as_center1/` - AS 센터 v1
- `as_center2/` - AS 센터 v2
- `as_center3/` - AS 센터 v3
- `as_center4/` - AS 센터 v4
- `as_center5/` - AS 센터 v5
- `as_center_export/` - AS 수출 기능

### 3. 레거시 기능 폴더들
- `as_item/` - 구 AS 아이템 관리
- `as_poor/` - 구 불량증상 관리
- `as_result/` - 구 AS 결과 관리
- `bank/`, `bank_sell/` - 구 은행 관련 기능
- `center/`, `client/` - 구 센터/클라이언트 관리
- `center_parts/`, `center_parts_order/` - 구 부품 주문 관리
- `member/`, `order/`, `out/` - 구 회원/주문/출고 관리
- `parts/`, `parts_category/`, `parts_count/` - 구 자재 관리
- `result/`, `result_sell/` - 구 결과/판매 관리
- `sell/` - 구 판매 기능
- `sms/`, `sms_db/` - 구 SMS 기능
- `tax/` - 구 세금 관리

### 4. 레거시 설정 및 공통 파일
- `config/` - 구 설정 폴더
- `includes/` - 구 include 파일들
- `jqu/` - jQuery 라이브러리 (구 버전)
- `pw/` - 구 비밀번호 관리
- `print/` - 구 인쇄 기능
- `sample/` - 샘플 파일들

### 5. 기타
- `public/css/`, `public/js/` - 구 공개 리소스
- `.gif` 파일들 - 구 메뉴 아이콘 등

### 6. 테스트 파일
- `as_unused/` - www/as의 테스트 파일들

## ⚠️ 주의사항

**이 폴더의 파일들은 현재 프로젝트에서 사용되지 않습니다.**

현재 활발히 개발 중인 파일들:
- `www/as/parts.php` - 자재 관리 (현대화)
- `www/as/products.php` - 제품 관리
- `www/as/members.php` - 고객 관리
- `www/as/orders.php` - 주문 관리
- `www/as/as_requests.php` - AS 요청 관리
- `www/as/as_repair.php` - AS 수리 처리
- `www/as/dashboard.php` - 메인 대시보드

## 📝 참고 사항

1. **참고용으로만 사용**: 문제 해결 시 이 폴더의 파일들을 참고할 수 있습니다.
2. **Git에서 제외**: `.gitignore`에 등록되어 있어 git에 추가되지 않습니다.
3. **복원 가능**: 필요하면 git history에서 복원할 수 있습니다.
4. **정기적 정리**: 6개월마다 검토하여 필요 없는 파일들을 삭제해도 됩니다.

## 🔍 구조도

```
backup/
├── legacy/
│   ├── lcm1.php, lcm2.php, lcm3.php
│   ├── lhm1.php ~ lhm6.php
│   ├── index.php.new, index2.php
│   ├── as_center/ ~ as_center5/
│   ├── as_item/, as_poor/, as_result/
│   ├── bank/, bank_sell/, center/, client/
│   ├── center_parts/, center_parts_order/
│   ├── member/, order/, out/, out_list/
│   ├── parts/, parts_category/, parts_count/
│   ├── result/, result_sell/, sell/
│   ├── sms/, sms_db/, tax/
│   ├── config/, includes/, jqu/, pw/
│   ├── print/, sample/, public/
│   └── as_unused/
└── README.md (이 파일)
```

---

**마지막 업데이트**: 2025-11-10
