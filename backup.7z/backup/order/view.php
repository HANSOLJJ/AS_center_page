<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 1500;

$result = mysql_query("SELECT count(s4_vid) FROM $db4 WHERE s4_cartnum = '$number'");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width="20%" height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>번호</b></p>
		</td>
		<td width="20%" height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>카테고리</b></p>
		</td>
		<td width="20%" height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>ERP</b></p>
		</td>
		<td width="20%" height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>자재명</b></p>
		</td>
		<td width="20%" height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>수량</p>
		</td>
	</tr>

<?

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s4_vid, s4_center_id, s4_uid, s4_quantity FROM $db4 WHERE s4_cartnum = '$number'";

$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s4_vid = $row[s4_vid];
   $my_s4_center_id = $row[s4_center_id];
   $my_s4_uid = $row[s4_uid];
   $my_s4_quantity = $row[s4_quantity];


##### 선택한 게시물의 입력값을 뽑아낸다.
$query2 = "SELECT s1_uid, s1_caid, s1_erp, s1_name FROM $db1 WHERE s1_uid = '$my_s4_uid'";

$result2 = mysql_query($query2);
if(!$result2) {
   error("QUERY_ERROR");
   exit;
}
$row2 = mysql_fetch_row($result2);
 
$my_s1_uid = $row2[0];
$my_s1_caid = $row2[1];
$my_s1_erp = $row2[2];
$my_s1_name = $row2[3];

//------------------카테고리명 부르기
$category_query = mysql_query("Select s5_category FROM $db5 WHERE s5_caid ='$my_s1_caid'");
$my_s1_caid = mysql_result($category_query,0,0);


if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}

 ##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<tr><td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

##### 

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><p>$my_s1_caid</p></td>");

##### 

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><p>$my_s1_erp</p></td>");

##### 

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><p>$my_s1_name</p></td>");


echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><p>$my_s4_quantity</p></td>");


$article_num--;
}
if($total_record == '0'){print"<table width='100%' align='center' cellspacing='0' cellpadding='0'  border='1' class='body' bordercolor='#dedede' bordercolordark='white' bordercolorlight='#dedede'><tr><td height='160'><p align='center'>장바구니가 비어있습니다.</p></td></tr></table>";}


?>


<table width='100%' align='center' cellspacing='0' cellpadding='0'  border='0' class='body'>
	<tr>
		<td align='center'>
		<br><br>
		&nbsp;
<?if(!$total_record == '0'){print"<a href='order_process.php?number=$number '><img src='../$icon_dir/button_blue_ok_to_go.gif' align='absmiddle' border='0'></a>";}?>

		</td>
	</tr>
</table>

