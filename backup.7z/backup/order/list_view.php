
<?

echo("<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'><tr><td>");

if($in_mode == "1" OR $in_mode == ""){$font_color_admin ="FF0000";}else{$font_color_admin ="#000000";}

echo("<a href=\"list.php?in_code=list_view&in_mode=1\"><font color=$font_color_admin><b>[ 센터 전체보기 ]</b></font></a>&nbsp;");

//------------------센터명 부르기

$search_query = "Select s2_center_id, s2_center FROM step2_center ORDER BY s2_center ASC";
$search_result= mysql_query($search_query);

if (!$search_result) {
   error("QUERY_ERROR");
   exit;
}


while($search_row = mysql_fetch_array($search_result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $search_s2_center = $search_row[s2_center];
   $search_s2_center_id = $search_row[s2_center_id];

if($search_s2_center_id  == $center_id_s){$font_color ="#FF0000";}else{$font_color ="#000000";}
echo("<a href=\"list.php?in_code=list_view&d_mode=2&center_id_s=$search_s2_center_id\"><font color=$font_color><b>[ $search_s2_center ]</b></font></a>&nbsp;");
}

echo("</td></tr></table>");

?>

<br>
<?
##### 검색 날짜관련
if($d_mode==1){
$s_d = mktime(0,0,0,$s_month, $s_day, $s_year);
$e_d = mktime(0,0,0,$e_month, $e_day, $e_year);
}else{
$s_year = date("Y"); 
$s_month = date("m"); 
$s_day = date("d"); 
$e_year = date("Y"); 
$e_month = date("m"); 
$e_day = date("d"); 
}

####

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 50;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;


if(!$page) {
   $page = 1;
}

##### 전체게시물의 총 개수를 각각 구한다.
//$query = "SELECT count(s6_cartnum) FROM $db6";

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if($d_mode==''){
	 $query = "SELECT count(*) FROM $db6";
	}else
if($d_mode=='1'){
	 $query = "SELECT count(*) FROM $db6  WHERE s6_signdate BETWEEN '$s_d' AND '$e_d'";
	}else
if($d_mode=='2'){
	 $query = "SELECT count(*) FROM $db6  WHERE s6_center_id  LIKE '$center_id_s'";
	}


$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>

<script language="javascript">
<!--
function profileWindow(ref) {
   var window_left = (screen.width-700)/2;
   var window_top = (screen.height-500)/2;   
   window.open(ref,"profileWin",'width=700,height=500,status=no,scrollbars=yes,top=' + window_top + ',left=' + window_left + '');
}
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td width='50%' height='50' align='left'>
		<b>[ 해당 조건에 검색된 등록된 AS 정보 : <?echo"$total_record ";?> 건 ]</b>
		</td>
<form method="post" action="<?echo("list.php?in_code=list_view")?>&page=<? echo("$page"); ?>&d_mode=1">
		<td width='50%' align='right'>
<b>검색기간</b> : &nbsp;
<?
$men_year = date("Y",time());	

$FIRST_DAY = "2010";		// 시작값
$LAST_DAY = $men_year;			// 마지막값
   echo "<select name='s_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
if($i == $s_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      
   }
   echo "</select> &nbsp;";

   echo "<select name='s_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $s_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}   
   }
   echo "</select> &nbsp;";

   echo "<select name='s_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $s_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>~
<?

$FIRST_DAY = "2010";		// 시작값
$LAST_DAY = $men_year;			// 마지막값
   echo "<select name='e_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
if($i == $e_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      
   }
   echo "</select> &nbsp;";

   echo "<select name='e_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $e_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}    
 
   }
   echo "</select> &nbsp;";

   echo "<select name='e_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $e_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>

<input type='submit' STYLE='font-size:9pt;' value='검색'>
		</td>

</form>
	</tr>
</table>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
    <tr>
		<td width="25%" height='50' background="<?echo "$border_bg1";?>">
            <p align="center"><b>No.</b></p>
        </td>
		<td width="25%" height='50' background="<?echo "$border_bg1";?>">
            <p align="center"><b>센터명</b></p>
        </td>
        <td width="25%" height='50' background="<?echo "$border_bg1";?>">
            <p align="center"><b>주문일</b></p>
        </td>
        <td width="25%" height='50' background="<?echo "$border_bg1";?>">
            <p align="center"><b>진행상태</b></p>
        </td>
    </tr>


<?
$time_limit = 60*60*24*$notify_new_article; 


##### 현재페이지의 범위내에 출력할 결과레코드세트를 얻는다.
if($d_mode==''){
	$query = "SELECT s6_orid, s6_cartnum, s6_center_id, s6_center_member, s6_completion, s6_signdate FROM $db6 ORDER BY s6_orid DESC LIMIT $first, $num_per_page";
	}else
if($d_mode=='1'){
	$query = "SELECT s6_orid, s6_cartnum, s6_center_id, s6_center_member, s6_completion, s6_signdate FROM $db6   WHERE s6_signdate BETWEEN '$s_d' AND '$e_d' ORDER BY s6_orid DESC LIMIT $first, $num_per_page";
	}else
if($d_mode=='2'){
	$query = "SELECT s6_orid, s6_cartnum, s6_center_id, s6_center_member, s6_completion, s6_signdate FROM $db6   WHERE s6_center_id  = '$center_id_s' ORDER BY s6_orid DESC LIMIT $first, $num_per_page";
	}



   
$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($info = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s6_orid = $info[s6_orid];
   $my_s6_cartnum = $info[s6_cartnum];   
   $my_s6_center_id = $info[s6_center_id];
   $my_s6_center_member = $info[s6_center_member];
   $my_s6_completion = $info[s6_completion];
   $my_s6_signdate = date("Y.m.d",$info[s6_signdate]);


//------------------센터명 정보 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id  ='$my_s6_center_id'");
$center_num = mysql_result($center_query,0,0);   

//--------------

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}

echo "<tr>";
   
echo "<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>";

   
echo "   <td align='center' valign='middle' $list_style1 $td_bg>$center_num</td>";
   #####

echo "   <td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=view&number=$my_s6_cartnum'>" . $my_s6_signdate . "</b></a></td>";


     ##### 


if($my_s6_completion =='주문접수'){
	$max="<font color=red><b>주문접수</b></font>-주문확인";} else

if($my_s6_completion =='주문확인'){$max="주문확인";}
 

   ##### [컬럼 3 : 회원의 아이디를 출력한다.]   
echo "<td align='center' valign='middle' $list_style1 $td_bg>" . $max . "</td>";

  
   echo("</tr>");      

   $article_num--;
}
?>
	
</table>


<br>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>
<form method="post" action="<?echo("list.php?in_code=list_view")?>">


							
							<td width='280' height='35'>
							<select name="keyfield" size="1" align='absmiddle' <?echo("$Form_style1");?>>
							   <option value="s1_name">센터명</option>
							</select>
							&nbsp;&nbsp;
							<input type="text" name="key" size='18' <?echo("$Form_style1");?>>&nbsp;&nbsp;&nbsp;
							<input type='submit' STYLE='font-size:9pt;' value='검색'>
							</td>
							
						</form>
							<td  align='center'>

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&keyfield=$keyfield\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>$direct_page.</b>&nbsp;");
   } else {
      echo("<a href=\"list.php?in_code=list_view&page=$direct_page&keyfield=$keyfield\" >$direct_page</a>.&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"list.php?in_code=list_view&page=$my_page&keyfield=$keyfield\" >→</a>");
}

?>
   </td>
</tr>
</table>