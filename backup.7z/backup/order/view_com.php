<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title></title>
<link rel='stylesheet' href='2007.css' type=text/css>
</head>

<SCRIPT>
var div2print;
function printDiv (id) {
  if (document.all && window.print) {
    div2print = document.all[id];
    window.onbeforeprint = hideDivs;
    window.onafterprint = showDivs;
    window.print();
  }
  else if (document.layers) {
    div2print = document[id];
    hideDivs();
    window.print();
  } 
}
function hideDivs () {
  if (document.all) {
    var divs = document.all.tags('DIV');
    for (var d = 0; d < divs.length; d++)
      if (divs[d] != div2print)
        divs[d].style.display = 'none';
  }
  else if (document.layers) {
    for (var l = 0; l < document.layers.length; l++)
      if (document.layers[l] != div2print)
        document.layers[l].visibility = 'hide';

  }
}
function showDivs () {
  var divs = document.all.tags('DIV');
  for (var d = 0; d < divs.length; d++)
    divs[d].style.display = 'block';
}
</SCRIPT>

</head>
<!----<body OnLoad="printDiv('d2');">--->

<!------------------------------------------------>

<?
#변수
$jcgdb1 = "mycart";
$jcgdb2 = "item";
$jcgdb3 = "myorder2";

##### 데이터 베이스 연결
include"include.connect.php";

##### 사용자 정의 함수 파일을 가져온다.
include"function.user.php";

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT ordernum, cartnum, id, shop, allcash1, lostcash2, pluscash3, truecash4, bankcash5, ment4, completion, signdate  FROM $jcgdb3 WHERE ordernum = '$number'";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$row = mysql_fetch_row($result);

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_ordernum = $row[0];
   $my_cartnum = $row[1];
   $my_id = $row[2];
   $my_shop = $row[3];   
   $my_allcash1 = $row[4];
   $my_lostcash2 = $row[5];
   $my_pluscash3 = $row[6];
   $my_truecash4 = $row[7];
   $my_bankcash5 = $row[8];
   $my_ment4 = $row[9];
   $my_completion = $row[10];
   $my_signdate = date("Y-m-d H:i",$row[11]);	


?>

<table width='640' cellpadding='0' cellspacing='0' border='0' align='center' valign='top'>

<!------------------------- 이름  --------------------------->

					<tr>
						<td width='100' height='35' style="border-top-width:1px; border-bottom-width:1px; border-top-color:rgb(233,233,233); border-bottom-color:rgb(233,233,233); border-top-style:solid; border-bottom-style:solid;">
						상호
						</td>
						<td width='440' style="border-top-width:1px; border-bottom-width:1px; border-top-color:rgb(233,233,233); border-bottom-color:rgb(233,233,233); border-top-style:solid; border-bottom-style:solid;">
						|&nbsp;&nbsp;<?echo("$my_shop")?>
						</td>
						<td style="border-top-width:1px; border-bottom-width:1px; border-top-color:rgb(233,233,233); border-bottom-color:rgb(233,233,233); border-top-style:solid; border-bottom-style:solid;">
						<p align='right'>
						<a href=# ONCLICK="printDiv('d2');"><img src='print' border='0'></a>
						</p>
						</td>
					</tr>

<!------------------------- 주문일자  --------------------------->

					<tr>
						<td  height='35' style="border-bottom-width:1px; border-bottom-color:rgb(233,233,233); border-bottom-style:solid;">
						주문일자
						</td>
						<td style="border-bottom-width:1px; border-bottom-color:rgb(233,233,233); border-bottom-style:solid;">
						|&nbsp;&nbsp;<?echo("$my_signdate")?>
						</td>
						<td style="border-bottom-width:1px; border-bottom-color:rgb(233,233,233); border-bottom-style:solid;">&nbsp;
						</td>
					</tr>


<?

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 1500;

$result = mysql_query("SELECT count(cartnum) FROM $jcgdb1 WHERE cartnum = $my_cartnum && id = '$my_id' && end = 'Y'");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record1 == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>

<table width="100%" align="center" cellspacing="0" bordercolordark="white" bordercolorlight="black" cellpadding="0" class="body">
	<tr>
		<td height='5' colspan='8' bgcolor='#FFC600'>
		</td>
	</tr>
	<tr>
		<td width='40' height="30" align='center' bgcolor="#F7F7F7">
			<p>번호</p>
		</td>
		<td width='200' height="30" align='center' bgcolor="#F7F7F7">
			<p>품목</p>
		</td>
		<td width='200' height="30" align='center' bgcolor="#F7F7F7">
			<p>규격</p>
		</td>
		<td width='100' height="30" align='center' bgcolor="#F7F7F7">
			<p>단가</p>
		</td>
		<td width='100' height="30" align='center' bgcolor="#F7F7F7">
			<p>수량</p>
		</td>
		<td width='100' height="30" align='center' bgcolor="#F7F7F7">
			<p>합산금액</p>
		</td>
	</tr>

<br>

<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT uid, cartnum, xid, id, fixprice, price, quantity FROM $jcgdb1 WHERE cartnum = '$my_cartnum' && id = '$my_id'  && end = 'Y'";

$result = mysql_query($query);

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_uid = $row[uid];
   $my_cartnum = $row[cartnum];
   $my_xid = $row[xid];
   $my_id = $row[id];
   $my_fixprice = $row[fixprice];
   $my_price = $row[price];
   $my_quantity = $row[quantity];




##### 선택한 게시물의 입력값을 뽑아낸다.
$query2 = "SELECT xid, cat1, name, pack, dan, cost FROM $jcgdb2 WHERE xid = $my_xid";
$result2 = mysql_query($query2);
if(!$result2) {
   error("QUERY_ERROR");
   exit;
}
$row2 = mysql_fetch_row($result2);
 
$my_xid = $row2[0];
$my_cat1 = $row2[1];
$my_name = $row2[2];
$my_pack = $row2[3];
$my_dan = $row2[4];
$my_cost = $row2[5];


$cost_total1 = $my_fixprice * $my_quantity;

$my_fixprice = number_format($my_fixprice); 

 ##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<tr><td width='40'  align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;'>");

echo("$article_num.</td>");

echo("<td height='25' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' align='center'>$my_name</td>");

echo("<td height='25' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' align='center'>$my_pack</td>");  

echo("<td height='25' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;'  align='center'>$my_fixprice&nbsp;원</td>");

echo("<td height='25' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' align='center'>$my_quantity</td>");

$cost_total1 = number_format($cost_total1); 

echo("<td height='25' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' align='center'><b><font color='black'>$cost_total1</font></b>&nbsp;원</td>");

echo("</tr>");
$article_num--;
}
if($total_record == '0'){print"<table width='640' align='center' cellspacing='0' cellpadding='0'  border='1' class='body' bordercolor='#dedede' bordercolordark='white' bordercolorlight='#dedede'><tr><td height='160'><p align='center'>장바구니가 비어있습니다.</p></td></tr></table>";}


print"
<table width='660' align='center' cellspacing='0' cellpadding='0'  border='0' class='body' background='../../graphics/cart_border05.gif'>
			<tr>
				<td height='20'>
			<p align='right'>예상 주문액 합계 
				";

$query = "SELECT SUM(price) FROM $jcgdb1 WHERE cartnum = $my_cartnum && id = '$my_id'  && end = 'Y'";

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$total_cost= mysql_result($result,0,0);

mysql_free_result($result);

$totalmoney = $total_cost ;

$totalmoney_end = number_format($totalmoney);

$total_cost_end = number_format($total_cost);


echo ("&nbsp;&nbsp;<b><font color='red'>$totalmoney_end</font></b> 원");

$total_sum =$my_truecash4 + $my_lostcash2 - $my_bankcash5;
$total_sum = number_format($total_sum);


$my_truecash4 = number_format($my_truecash4);

$my_bankcash5  = number_format($my_bankcash5 );

?>
<?
##### 수정하고자 하는 글의 내용을 가져와 각각의 변수에 저장한다.
$query_misu = "SELECT misu FROM member WHERE id = '$my_id' ";
$result_misu = mysql_query($query_misu);
if(!$result_misu) {
   error("QUERY_ERROR");
   exit;
}

$row_misu = mysql_fetch_object($result_misu);

$my_misu = $row_misu->misu;

$total_misu = number_format($my_misu);

$end_m = $totalmoney + $my_lostcash2;

$end_mo = number_format($end_m);

$total_cost = number_format($total_cost);

$my_lostcash2 = number_format($my_lostcash2);
?>

<table border="1" cellspacing="0" width="100%" bordercolordark="white" bordercolorlight="black" align='center'>
    <tr>
        <td width="50%" height="30">
            <p align='center'>① 전잔액</p>
        </td>
        <td width="50%">
            <p align='center'><font color='red'><b><? echo"$my_lostcash2";?> 원</b></font></p>
        </td>
    </tr>
    <tr>
        <td width="50%" height="30">
            <p align='center'>② 주문 상품 합계</p>
        </td>
        <td width="50%">
            <p align='center'><b><font color='black'><? echo"$total_cost";?> 원</b></font></p>
        </td>
    </tr>
    <tr>
        <td width="50%" height="30">
            <p align='center'>① + ② 합계금액</p>
        </td>
        <td width="50%">
            <p align='center'><b><font color='black'><? echo"$end_mo";?> 원</b></font></p>
        </td>
    </tr>
		<tr>
        <td width="50%" height="30">
            <p align='center'>③ 출고액</p>
        </td>
        <td width="50%">
            <p align='center'><b><font color='red'><? echo"$my_truecash4";?> 원</b></font></p>
        </td>
    </tr>
	
	<tr>
        <td width="50%" height="30">
            <p align='center'>④ 입금액</p>
        </td>
        <td width="50%">
            <p align='center'><b><font color='red'><? echo"$my_bankcash5 ";?> 원</b></font></p>
        </td>
    </tr>
	<tr>
        <td width="50%" height="30">
            <p align='center'>③ + ① - ④ 잔액</p>
        </td>
        <td width="50%">
            <p align='center'><b><font color='red'><? echo"$total_sum";?> 원</b></font></p>
        </td>
    </tr>

	<tr>
        <td width="100%" height="30" colspan='2'>
            <p align='left'><? echo"$my_ment4";?></p>
        </td>
    </tr>
</table>
