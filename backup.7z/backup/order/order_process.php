<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 

$s6_completion ='주문확인';

$query2 = "UPDATE $db6 SET s6_completion  = '$s6_completion' WHERE s6_cartnum  = '$number'";

$result2 = mysql_query($query2);

if (!$result2) {
         error("QUERY_ERROR");
         exit;
      }

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");

?>
