<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";



$query = "UPDATE $db13 SET s13_dex_send_name = '$s13_dex_send_name', s13_dex_send = '$s13_dex_send' WHERE s13_asid  = '$number'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=modify&number=$number'>");
} 

?>
