<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how, s13_as_in_no, s13_meid, s13_dex_no, s13_total_cost, s13_sms1, s13_sms2, s13_bank_check, s13_tax_code, s13_dex_send, s13_dex_send_name, s13_as_out_date FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_asid = $row->s13_asid;
$my_s13_as_center = $row->s13_as_center;
$my_s13_as_in_date = $row->s13_as_in_date;
$my_s13_as_in_how = $row->s13_as_in_how;

$my_s13_as_in_no = $row->s13_as_in_no;
$my_s13_meid = $row->s13_meid;
$my_s13_dex_no = $row->s13_dex_no;
$my_s13_total_cost = $row->s13_total_cost;
$my_s13_sms1 = $row->s13_sms1;
$my_s13_sms2 = $row->s13_sms2;
$my_s13_bank_check = $row->s13_bank_check;
$my_s13_tax_code = $row->s13_tax_code;
$my_s13_dex_send = $row->s13_dex_send;

$my_s13_dex_send_name = $row->s13_dex_send_name;
$my_s13_as_out_date = $row->s13_as_out_date;


$my_s13_as_in_date =date("Y/m/d",$my_s13_as_in_date);
if($my_s13_bank_check == "N"){$bank_on ="&nbsp;";}else{$bank_on ="입금확인";}
if($my_s13_tax_code != "" AND $my_s13_tax_code != "N" ){$tax_on ="발행";}else if($my_s13_tax_code != "" AND $my_s13_tax_code == "N" ){$tax_on ="미발행";}else{$tax_on ="&nbsp;";}

if($my_s13_dex_send_name == ""){$dex_send ="&nbsp;";} else {$dex_send ="$my_s13_dex_send_name<br>($my_s13_dex_send)";}


$my_s13_total_cost = number_format($my_s13_total_cost);	

//------------------업체명

$instant_query = "Select s11_com_name, s11_sec, s11_oaddr, s11_phone1, s11_phone2, s11_phone3 FROM $db11 WHERE s11_meid  ='$my_s13_meid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $s11_com_name=$instant_reply->s11_com_name;
	   $s11_sec=$instant_reply->s11_sec;
	   $s11_oaddr=$instant_reply->s11_oaddr;
	   $s11_phone1=$instant_reply->s11_phone1;
	   $s11_phone2=$instant_reply->s11_phone2;
	   $s11_phone3=$instant_reply->s11_phone3;

	   $phone_num = $s11_phone1."-".$s11_phone2."-".$s11_phone3;
	
   }

}

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p>&nbsp;</p>
		<p align='center'>
		<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
			<tr>
				<td  width='15%' height='50' background="<?echo "$border_bg1";?>">
				<p align='center'><b>입고일</b></p>
				</td>
				<td  width='20%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>업체명</b></p>
				</td>
				<td  width='15%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>접수번호</b></p>
				</td>
				<td  width='10%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>비용합계</b></p>
				</td>
				<td  width='10%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>입금확인</b></p>
				</td>
				<td width='20%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>택배출고정보</b></p>
				</td>
			</tr>
			<tr>
				<td height='50'>
				<p align='center'><? echo"$my_s13_as_in_date";?></p>
				</td>
				<td>
				<p align='center'><? echo"$s11_com_name";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_s13_as_in_no";?></p>
				</td>
				<td>
				<p align='center'><font color='red'><b><? echo"$my_s13_total_cost";?> 원</b></font></p>
				</td>
				<td>
				<p align='center'><? echo"$bank_on";?></p>
				</td>
				<td>
				<p align='center'><? echo"$dex_send";?></p>
				</td>
			</tr>
			<tr>
				<td colspan='10'>
				<?include"as_set2_list.php";?>
			
				</td>
			</tr>
		</table>
		</p>		
		<p>&nbsp;</p>
		</td>
	</td>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center' >
	<tr>
		<td>
		<p align='right'><a href='as_level_down_process.php?number=<?echo("$number");?>'>
		<img src='../<?echo("$icon_dir");?>/button_level_down.gif' align='absmiddle' border='0'></a>&nbsp;
		<a href='<? echo("list.php?in_code=list_view");?>'>
		<img src='../<?echo("$icon_dir");?>/button_blue_cancel.gif' align='absmiddle' border='0'>
		</a>
		</p>
		</td>
	</tr>
</table>
