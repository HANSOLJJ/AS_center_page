<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";



##### 
$s13_as_level = "4";
$s13_as_name3 = $HTTP_SESSION_VARS[member_name];
$signdate = time();

$query = "UPDATE $db13 SET s13_as_level  = '$s13_as_level', s13_as_name3  = '$s13_as_name3', s13_as_out_date = '$signdate' WHERE s13_asid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}


##### 리스트 출력화면으로 이동한다.

echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>