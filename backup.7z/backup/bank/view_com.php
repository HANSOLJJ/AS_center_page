<?

include "../@config.php";
include "../@error_function.php";
include "../@access.php";

?>
<head>
<title>세금계산서</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>
</head>

<script type="text/javascript">
window.resizeTo (700, 760);
window.focus();

function printNow() {
  document.getElementById('command_bar').style.display = 'none';
  window.print();
}
</script>


<?
$db='2010_tax';

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT uid, id, total_year, total_month, total_day, month_1, day_1, item_1, scale_1, ea_1, cost_1, total_cost_1, month_2, day_2, item_2, scale_2, ea_2	, cost_2, total_cost_2, month_3, day_3, item_3, scale_3, ea_3, cost_3, total_cost_3, month_4, day_4, item_4, scale_4, ea_4, cost_4, total_cost_4, bill_sec1, bill_sec2, signdate, state FROM $db10 WHERE signdate = $number";

$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$row = mysql_fetch_row($result);

$my_uid = $row[0];
$my_id = $row[1];
$my_total_year = $row [2];
$my_total_month = $row[3];
$my_total_day = $row[4];

$my_month_1 = $row[5];
$my_day_1 = $row[6];
$my_item_1 = $row[7];
$my_scale_1 = $row[8];
$my_ea_1 = $row[9];
$my_cost_1 = $row[10];
$my_total_cost_1 = $row[11];

$my_month_2 = $row[12];
$my_day_2 = $row[13];
$my_item_2 = $row[14];
$my_scale_2 = $row[15];
$my_ea_2 = $row[16];
$my_cost_1 = $row[17];
$my_total_cost_2 = $row[18];

$my_month_3 = $row[19];
$my_day_3 = $row[20];
$my_item_3 = $row[21];
$my_scale_3 = $row[22];
$my_ea_3 = $row[23];
$my_cost_1 = $row[24];
$my_total_cost_3 = $row[25];

$my_month_4 = $row[26];
$my_day_4 = $row[27];
$my_item_4 = $row[28];
$my_scale_4 = $row[29];
$my_ea_4 = $row[30];
$my_cost_1 = $row[31];
$my_total_cost_4 = $row[32];

$my_bill_sec1 = $row[33];
$my_bill_sec2 = $row[34];
$my_code = $row[35];
$my_state = $row[36];

############# 작성일 정리

$my_total_year = substr("$my_total_year",-2);

############# 총 공급가액


if($my_total_cost_1==''){$my_total_cost_1='0';}
if($my_total_cost_2==''){$my_total_cost_2='0';}
if($my_total_cost_3==''){$my_total_cost_3='0';}
if($my_total_cost_4==''){$my_total_cost_4='0';}

$total_cost = $my_total_cost_1 + $my_total_cost_2 + $my_total_cost_3 + $my_total_cost_4;



############# 공란

$se_len=strlen($total_cost); 

for($ni=0;$ni<10-$se_len;$ni++){ 

$temp_colum = $ni + 2;
} 

############# 세액

$total_tax = $total_cost / 10;
$temp_total_tax = explode(".", $total_tax);
$print_total_tax = $temp_total_tax[sizeof($temp_total_tax)-2];

if($print_total_tax==''){$print_total_tax = $total_tax;}else{$print_total_tax = $print_total_tax;}


########### 합계

$sum_total_cost = $total_cost + $total_tax;

$sum_total_cost = number_format($sum_total_cost);


############# 공란
if($my_cost_1=='0'){$my_cost_1='&nbsp';}
if($my_cost_2=='0'){$my_cost_2='&nbsp';}
if($my_cost_3=='0'){$my_cost_3='&nbsp';}
if($my_cost_4=='0'){$my_cost_4='&nbsp';}

if($my_total_cost_1=='0' OR $my_total_cost_1==''){$print_total_cost_1='&nbsp;';} else{
	$print_total_cost_1 = number_format($my_total_cost_1); 

$tax1 = $my_total_cost_1 / 10;
$temp_tax1 = explode(".", $tax1);
$print_tax1 = $temp_tax1[sizeof($temp_tax1)-2];
if($print_tax1==''){$print_tax1 = $tax1;$print_tax1 = number_format($print_tax1);}else{$print_tax1 =$print_tax1;$print_tax1 = number_format($print_tax1);}

	}
if($my_total_cost_2=='0' OR $my_total_cost_2==''){$print_total_cost_2='&nbsp;';$print_tax2='&nbsp;';} else{
	$print_total_cost_2 = number_format($my_total_cost_2); 

$tax2 = $my_total_cost_2 / 10;
$temp_tax2 = explode(".", $tax2);
$print_tax2 = $temp_tax2[sizeof($temp_tax2)-2];
if($print_tax2==''){$print_tax2 = $tax2;$print_tax2 = number_format($print_tax2);}else{$print_tax2 =$print_tax2;$print_tax2 = number_format($print_tax2);}

	}
if($my_total_cost_3=='0' OR $my_total_cost_3==''){$print_total_cost_3='&nbsp;';$print_tax3='&nbsp;';} else{
	$print_total_cost_3 = number_format($my_total_cost_3); 

$tax3 = $my_total_cost_3 / 10;
$temp_tax3 = explode(".", $tax3);
$print_tax3 = $temp_tax3[sizeof($temp_tax3)-2];
if($print_tax3==''){$print_tax3 = $tax3;$print_tax3 = number_format($print_tax3);}else{$print_tax3 =$print_tax3;$print_tax3 = number_format($print_tax3);}

	}
if($my_total_cost_4=='0' OR $my_total_cost_4==''){$print_total_cost_4='&nbsp;';$print_tax4='&nbsp;';} else{
	$print_total_cost_4 = number_format($my_total_cost_4); 

$tax4 = $my_total_cost_4 / 10;
$temp_tax4 = explode(".", $tax4);
$print_tax4 = $temp_tax4[sizeof($temp_tax4)-2];
if($print_tax4==''){$print_tax4 = $tax4;$print_tax4 = number_format($print_tax4);}else{$print_tax4 =$print_tax4;$print_tax4 = number_format($print_tax4);}

	}






if($my_month_1==''){$my_month_1='&nbsp;';}
if($my_day_1==''){$my_day_1='&nbsp;';}
if($my_item_1==''){$my_item_1='&nbsp;';}
if($my_scale_1==''){$my_scale_1='&nbsp;';}
if($my_ea_1==''){$my_ea_1='&nbsp;';}
if($my_cost_1==''){$my_cost_1='&nbsp;';}
if($my_total_cost_1==''){$my_total_cost_1='&nbsp;';}

if($my_month_2==''){$my_month_2='&nbsp;';}
if($my_day_2==''){$my_day_2='&nbsp;';}
if($my_item_2==''){$my_item_2='&nbsp;';}
if($my_scale_2==''){$my_scale_2='&nbsp;';}
if($my_ea_2==''){$my_ea_2='&nbsp;';}
if($my_cost_2==''){$my_cost_2='&nbsp;';}
if($my_total_cost_2==''){$my_total_cost_2='&nbsp;';}

if($my_month_3==''){$my_month_3='&nbsp;';}
if($my_day_3==''){$my_day_3='&nbsp;';}
if($my_item_3==''){$my_item_3='&nbsp;';}
if($my_scale_3==''){$my_scale_3='&nbsp;';}
if($my_ea_3==''){$my_ea_3='&nbsp;';}
if($my_cost_3==''){$my_cost_3='&nbsp;';}
if($my_total_cost_3==''){$my_total_cost_3='&nbsp;';}

if($my_month_4==''){$my_month_4='&nbsp;';}
if($my_day_4==''){$my_day_4='&nbsp;';}
if($my_item_4==''){$my_item_4='&nbsp;';}
if($my_scale_4==''){$my_scale_4='&nbsp;';}
if($my_ea_4==''){$my_ea_4='&nbsp;';}
if($my_cost_4==''){$my_cost_4='&nbsp;';}
if($my_total_cost_4==''){$my_total_cost_4='&nbsp;';}

################화면정리

if($my_bill_sec1=='A'){$end_sec1='V';$end_sec2='&nbsp;';$end_sec3='&nbsp;';$end_sec4='&nbsp;';}else
if($my_bill_sec1=='B'){$end_sec1='&nbsp;';$end_sec2='V';$end_sec3='&nbsp;';$end_sec4='&nbsp;';}else
if($my_bill_sec1=='C'){$end_sec1='&nbsp;';$end_sec2='&nbsp;';$end_sec3='V';$end_sec4='&nbsp;';}else
if($my_bill_sec1=='D'){$end_sec1='&nbsp;';$end_sec2='&nbsp;';$end_sec3='&nbsp;';$end_sec4='V';}

if($my_bill_sec2=='A'){$end_sec5='영수';}else
if($my_bill_sec2=='B'){$end_sec5='청구';}



#########################################

##### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$result= mysql_query("SELECT s11_com_num1, s11_com_num2, s11_com_num3, s11_com_name, s11_com_man, s11_com_sec1, s11_com_sec2, s11_oaddr  FROM $db11 WHERE s11_meid = '$number'");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장한다.   


$my_com_name = $row[s11_com_name];
$my_com_num1 = $row[s11_com_num1];
$my_com_num2 = $row[s11_com_num2];
$my_com_num3 = $row[s11_com_num3];
$my_com_man = $row[s11_com_man];
$my_com_sec1 = $row[s11_com_sec1];
$my_com_sec2 = $row[s11_com_sec2];
$my_oaddr = $row[s11_oaddr];

$my_com_num = $my_com_num1.'-'.$my_com_num2.'-'.$my_com_num3;


}


#########################################
$jcg1='디지탈컴';
$jcg2='정용호';
$jcg3='215-13-92816';
$jcg4='도.소매,건설,도매';
$jcg5='마이크';
$jcg6='경기도 부천시 오정구 삼정동 36-1 부천 테크노파크 쌍용 3차 801';

#########################################

if($my_state=='승인'){
	print"
<div id='command_bar'>
  A4용지를 준비하고 인쇄버튼을 클릭하세요. &nbsp; <input type='button' value='인쇄하기' onclick='printNow()' />
</div>
";
}else{
	print"
<div id='command_bar'>
 아직 승인되지 않았습니다.
</div>
";
}
?>
<br>

<style type="text/css">

.bout {
  font-family:굴림,바탕;
  border: 3px double blue;
}
body, table, tr, td, select{font-family:굴림, verdana, arial; font-size: 12px;color: #000000; border:1px;}
.ttxt {font-family:굴림, verdana, arial; font-size: 12px;color: #0000FF;}
.cborder {border-top-width:1; border-right-width:1; border-bottom-width:1; border-left-width:1; border-color:BLUE; border-top-style:solid; border-right-style:none; border-bottom-style:solid; border-left-style:solid;}
.ctit {font-size: 22px;color: #0000FF; font-weight:bold;}
.ccmt {font-size: 12px;color: #0000FF;}
.taxidno {font-size: 16px;color: black; font-weight:bold;}

.bout2 {font-family:굴림,바탕;border: 3px double red;}
.ttxt2 {font-family:굴림, verdana, arial; font-size: 12px;color: red;}
.cborder2 {border-top-width:1; border-right-width:1; border-bottom-width:1; border-left-width:1; border-color:red; border-top-style:solid; border-right-style:none; border-bottom-style:solid; border-left-style:solid;}
.ctit2 {font-size: 22px;color:red; font-weight:bold;}
.ccmt2 {font-size: 12px;color:red;}

#command_bar {
  font-size: 10pt;
  background-color: #FEFFD2;
  border: 1px solid #AF9E29;
  padding: 5px;
  margin-bottom: 10px;
}
.sign_area {
  position: relative;
}
.sign_img {
  position: absolute;
  top: 15px;
  left: 230px;
}
</style>


<table width="586" border="0" cellspacing="0" cellpadding="0" align="center">

  <tr>
    <td height="10">
      <table width="100%" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="10" class="ttxt">[별지 제11호 서식]</td>
          <td align="right" class="ttxt"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="586">
      <table width="100%" cellpadding="0" cellspacing="0" class="bout">
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
			  	<td width="20" height="44"></td>
                <td width="359" align="center"><span class="ctit">세 금 계 산 서</span> <span class="ccmt">(공급 받는자 보관용)</span></td>
                <td width="201"><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="25%" class="cborder" align="center" style="border-top-style:none"><span class="ttxt">책 번 호</span></td>
                      <td width="33%" align="right" class="cborder" style="border-top-style:none">&nbsp; <span class="ttxt">권</span> &nbsp;</td>
                      <td width="42%" align="right" class="cborder" style="border-top-style:none">&nbsp;<span class="ttxt">호</span> &nbsp;</td>
                    </tr>
                    <tr>
                      <td class="cborder" align="center" style="border-top-style:none;border-bottom-style:none"><span class="ttxt">일련번호</span></td>
                      <td colspan="2" align="center" class="cborder" style="border-top-style:none;border-bottom-style:none"><? echo("$my_code");?></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td><table width="100%" class="cborder" style="border-left-style:none" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50%"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td width="18" align="center" class="cborder" style="border-left-style:none"><span class="ttxt" style="line-height:35px">공<br>
                        급<br>
                        자</span></td>
                      <td><div class="sign_area"><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr height="35"> 
                            <td width="20%" align="center" class="cborder"><span class="ttxt">등록번호</span></td>
                            <td width="80%" class="cborder" align="center"><span class="taxidno"><? echo("$jcg3");?></span></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder" style="border-top-style:none"><span class="ttxt">상 호<br>
                              (법인명)</span> </td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td class="cborder" style="border-top-style:none" align="center"><? echo("$jcg1");?></td>
                                  <td class="cborder" style="border-top-style:none" align="center" width="15"><span class="ttxt">성<br>
                                    명</span></td>
                                  <td class="cborder" style="border-top-style:none" align="center" width="100"><? echo("$jcg1");?>&nbsp;<span class="ttxt">(인)</span>&nbsp;</td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder" style="border-top-style:none"><span class="ttxt">사업장<br>
                              주 소</span></td>
                            <td class="cborder" style="border-top-style:none" align="center"><? echo("$jcg6");?></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder" style="border-top-style:none"><span class="ttxt">업 태</span></td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td class="cborder" style="border-top-style:none" align="center"><? echo("$jcg4");?></td>
                                  <td class="cborder" style="border-top-style:none" width="15" align="center"><span class="ttxt">종<br>목</span></td>
                                  <td class="cborder" style="border-top-style:none" align="center"><? echo("$jcg5");?></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></div></td>
                    </tr>
                  </table></td>
                <td width="50%"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td class="cborder" width="18" align="center"><span class="ttxt" style="line-height:20px">공<br>
                        급<br>
						            받<br>
						            는<br>
                        자</span></td>
                      <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr height="35"> 
                            <td width="20%" align="center" class="cborder"><span class="ttxt">등록번호</span></td>
                            <td width="80%" class="cborder" align="center"><span class="taxidno"><? echo("$my_com_num");?></span></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder" style="border-top-style:none"><span class="ttxt">상 
                              호<br>
                              (법인명)</span> </td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td class="cborder" style="border-top-style:none" align="center"><? echo("$my_com_name");?></td>
                                  <td class="cborder" style="border-top-style:none" align="center" width="15"><span class="ttxt">성<br>
                                    명</span></td>
                                  <td class="cborder" style="border-top-style:none" width="100" align="center"><? echo("$my_com_man");?>&nbsp;<span class="ttxt">(인)</span></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder" style="border-top-style:none"><span class="ttxt">사업장<br>
                              주 소</span></td>
                            <td class="cborder" style="border-top-style:none" align="center"><? echo("$my_oaddr");?></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder" style="border-top-style:none"><span class="ttxt">업 
                              태</span></td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td class="cborder" style="border-top-style:none" align="center"><? echo("$my_com_sec1");?></td>
                                  <td class="cborder" style="border-top-style:none" width="15" align="center"><span class="ttxt">종<br>
                                    목</span></td>
                                  <td class="cborder" style="border-top-style:none" align="center"><? echo("$my_com_sec2");?></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="cborder" style="border-top-style:none;border-left-style:none">
              <tr height="20"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt">작 성</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">공 &nbsp; &nbsp; 급 
                   &nbsp; &nbsp; 가 &nbsp; &nbsp; 액</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">세 &nbsp; &nbsp; 액</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">비 고</span></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr height="20"> 
                      <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt">년</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">월</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">일</span></td>
                    </tr>
                    <tr height="24"> 
                      <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><? echo("$my_total_year");?></td>
                      <td class="cborder" style="border-top-style:none" align="center"><? echo("$my_total_month");?></td>
                      <td class="cborder" style="border-top-style:none" align="center"><? echo("$my_total_day");?></td>
                    </tr>
                  </table></td>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr height="20"> 
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">공란수</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">백</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">십</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">억</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">천</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">백</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">십</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">만</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">천</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">백</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">십</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">일</span></td>
                    </tr>
                    <tr height="24"> 
						<td class='cborder' style='border-top-style:none' align='center'><?echo"$temp_colum";?></td>



<?

$se_len=strlen($total_cost); 

for($ni=0;$ni<11-$se_len;$ni++){ 
    echo("<td class='cborder' style='border-top-style:none' align='center'>&nbsp;</td>"); 
$temp_colum = $ni;
} 
for($ti=0;$ti<$se_len;$ti++){ 
    $num=substr($total_cost,$ti,1); 
	echo("<td class='cborder' style='border-top-style:none' align='center'>$num</td>"); 


} 

?>

                    </tr>
                  </table></td>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr height="20"> 
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">십</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">억</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">천</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">백</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">십</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">만</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">천</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">백</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">십</span></td>
                      <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">일</span></td>
                    </tr>
                    <tr height="24"> 
<?

$se_len=strlen($print_total_tax); 

for($ni=0;$ni<10-$se_len;$ni++){ 
    echo("<td class='cborder' style='border-top-style:none' align='center'>&nbsp;</td>"); 

} 
for($ti=0;$ti<$se_len;$ti++){ 
    $num=substr($print_total_tax,$ti,1); 
	echo("<td class='cborder' style='border-top-style:none' align='center'>$num</td>"); 


} 

?>
                    </tr>
                  </table></td>
                <td class="cborder" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td>
		  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="cborder" style="border-top-style:none;border-left-style:none">
              <tr height="15"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt">월</span></td>
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt">일</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">품 &nbsp; &nbsp; 목</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">규 격</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">수 량</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">단 가</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">공 급 가 액</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">세 액</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">비 고</span></td>
              </tr>

              <tr height="20"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_1";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_day_1";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_item_1";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_scale_1";?></td>               
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_ea_1";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_cost_1";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$print_total_cost_1";?></td>
				<td class="cborder" style="border-top-style:none" align="center"><?echo"$print_tax1";?></td>
                <td class="cborder" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
             <tr height="20"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_2";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_day_2";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_item_2";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_scale_2";?></td>                
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_ea_2";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_cost_2";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$print_total_cost_2";?></td>
				<td class="cborder" style="border-top-style:none" align="center"><?echo"$print_tax2";?></td>
                <td class="cborder" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
              <tr height="20"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_3";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_day_3";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_item_3";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_scale_3";?></td>                
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_ea_3";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_cost_3";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$print_total_cost_3";?></td>
				<td class="cborder" style="border-top-style:none" align="center"><?echo"$print_tax3";?></td>
                <td class="cborder" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
              <tr height="20"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_4";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_day_4";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_item_4";?></td>
                <td class="cborder" style="border-top-style:none" align="center"><?echo"$my_scale_4";?></td>                
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_ea_4";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$my_cost_4";?></td>
                <td class="cborder" style="border-top-style:none" align="right"><?echo"$print_total_cost_4";?></td>
				<td class="cborder" style="border-top-style:none" align="center"><?echo"$print_tax4";?></td>
                <td class="cborder" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>

            </table>

			</td>
        </tr>
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr height="20"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt">합 계 금 액</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">현 금</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">수 표</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">어 음</span></td>
                <td class="cborder" style="border-top-style:none" align="center"><span class="ttxt">외상미수금</span></td>
                <td class="cborder" style="border-top-style:none;border-bottom-style:none" rowspan="2" align="center"><span class="ttxt">이 금액을</span> 
                  <b><?echo"$end_sec5";?></b> <span class="ttxt">함</span></td>
              </tr>
              <tr height="24"> 
                <td class="cborder" style="border-top-style:none;border-left-style:none;border-bottom-style:none" align="center"><?echo"$sum_total_cost";?></td>
                <td class="cborder" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec1";?></td>
                <td class="cborder" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec2";?></td>
                <td class="cborder" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec3";?></td>
                <td class="cborder" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec4";?></td>
              </tr>
            </table></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td align="right">
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td class="ccmt">[직인과 일련번호가 있어야 유효합니다]</td>

          <td align="right"></td>

        </tr>
      </table>
    </td>
  </tr>



  <tr height="70"> 
    <td><hr size="1"></td>
  </tr>

  <tr>
    <td height="10">
      <table width="100%" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="10" class="ttxt2">[별지 제11호 서식]</td>
          <td align="right" class="ttxt2"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="586">
      <table width="100%" cellpadding="0" cellspacing="0" class="bout2">
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
			  	<td width="20" height="44"></td>
                <td width="359" align="center"><span class="ctit2">세 금 계 산 서</span> <span class="ccmt2">(공급자 보관용)</span></td>
                <td width="201"><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="25%" class="cborder2" align="center" style="border-top-style:none"><span class="ttxt2">책 번 호</span></td>
                      <td width="33%" align="right" class="cborder2" style="border-top-style:none">&nbsp; <span class="ttxt2">권</span> &nbsp;</td>
                      <td width="42%" align="right" class="cborder2" style="border-top-style:none">&nbsp;<span class="ttxt2">호</span> &nbsp;</td>
                    </tr>
                    <tr>
                      <td class="cborder2" align="center" style="border-top-style:none;border-bottom-style:none"><span class="ttxt2">일련번호</span></td>
                      <td colspan="2" align="center" class="cborder2" style="border-top-style:none;border-bottom-style:none"><? echo("$my_code");?></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td><table width="100%" class="cborder2" style="border-left-style:none" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50%"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td width="18" align="center" class="cborder2" style="border-left-style:none"><span class="ttxt2" style="line-height:35px">공<br>
                        급<br>
                        자</span></td>
                      <td><div class="sign_area"><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr height="35"> 
                            <td width="20%" align="center" class="cborder2"><span class="ttxt2">등록번호</span></td>
                            <td width="80%" class="cborder2" align="center"><span class="taxidno"><? echo("$jcg3");?></span></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder2" style="border-top-style:none"><span class="ttxt2">상 호<br>
                              (법인명)</span> </td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td class="cborder2" style="border-top-style:none" align="center"><? echo("$jcg1");?></td>
                                  <td class="cborder2" style="border-top-style:none" align="center" width="15"><span class="ttxt2">성<br>
                                    명</span></td>
                                  <td class="cborder2" style="border-top-style:none" align="center" width="100"><? echo("$jcg2");?>&nbsp;<span class="ttxt2">(인)</span></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder2" style="border-top-style:none"><span class="ttxt2">사업장<br>
                              주 소</span></td>
                            <td class="cborder2" style="border-top-style:none" align="center"><? echo("$jcg6");?></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder2" style="border-top-style:none"><span class="ttxt2">업 태</span></td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td class="cborder2" style="border-top-style:none" align="center"><? echo("$jcg4");?></td>
                                  <td class="cborder2" style="border-top-style:none" width="15" align="center"><span class="ttxt2">종<br>목</span></td>
                                  <td class="cborder2" style="border-top-style:none" align="center"><? echo("$jcg5");?></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></div></td>
                    </tr>
                  </table></td>
                <td width="50%"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td class="cborder2" width="18" align="center"><span class="ttxt2" style="line-height:20px">공<br>
                        급<br>
						            받<br>
						            는<br>
                        자</span></td>
                      <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr height="35"> 
                            <td width="20%" align="center" class="cborder2"><span class="ttxt2">등록번호</span></td>
                            <td width="80%" class="cborder2" align="center"><span class="taxidno"><? echo("$my_com_num");?></span></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder2" style="border-top-style:none"><span class="ttxt2">상 
                              호<br>
                              (법인명)</span> </td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td class="cborder2" style="border-top-style:none" align="center"><? echo("$my_com_name");?></td>
                                  <td class="cborder2" style="border-top-style:none" align="center" width="15"><span class="ttxt2">성<br>
                                    명</span></td>
                                  <td class="cborder2" style="border-top-style:none" width="100" align="center"><? echo("$my_com_man");?>&nbsp;<span class="ttxt2">(인)</span></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder2" style="border-top-style:none"><span class="ttxt2">사업장<br>
                              주 소</span></td>
                            <td class="cborder2" style="border-top-style:none" align="center"><? echo("$my_oaddr");?></td>
                          </tr>
                          <tr height="35"> 
                            <td align="center" class="cborder2" style="border-top-style:none"><span class="ttxt2">업 
                              태</span></td>
                            <td><table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td class="cborder2" style="border-top-style:none" align="center"><? echo("$my_com_sec1");?></td>
                                  <td class="cborder2" style="border-top-style:none" width="15" align="center"><span class="ttxt2">종<br>
                                    목</span></td>
                                  <td class="cborder2" style="border-top-style:none" align="center"><? echo("$my_com_sec2");?></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="cborder2" style="border-top-style:none;border-left-style:none">
              <tr height="20"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt2">작 성</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">공 &nbsp; &nbsp; 급 
                   &nbsp; &nbsp; 가 &nbsp; &nbsp; 액</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">세 &nbsp; &nbsp; 액</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">비 고</span></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr height="20"> 
                      <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt2">년</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">월</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">일</span></td>
                    </tr>
                    <tr height="24"> 
                      <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><? echo("$my_total_year");?></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><? echo("$my_total_month");?></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><? echo("$my_total_day");?></td>
                    </tr>
                  </table></td>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr height="20"> 
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">공란수</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">백</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">십</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">억</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">천</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">백</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">십</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">만</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">천</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">백</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">십</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">일</span></td>
                    </tr>
                    <tr height="24"> 

<td class='cborder2' style='border-top-style:none' align='center'><?echo"$temp_colum";?></td>



<?

$se_len=strlen($total_cost); 

for($ni=0;$ni<11-$se_len;$ni++){ 
    echo("<td class='cborder2' style='border-top-style:none' align='center'>&nbsp;</td>"); 
$temp_colum = $ni;
} 
for($ti=0;$ti<$se_len;$ti++){ 
    $num=substr($total_cost,$ti,1); 
	echo("<td class='cborder2' style='border-top-style:none' align='center'>$num</td>"); 


} 

?>
                    </tr>
                  </table></td>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr height="20"> 
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">십</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">억</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">천</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">백</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">십</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">만</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">천</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">백</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">십</span></td>
                      <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">일</span></td>
                    </tr>
                    <tr height="24"> 
<?

$se_len=strlen($print_total_tax); 

for($ni=0;$ni<10-$se_len;$ni++){ 
    echo("<td class='cborder2' style='border-top-style:none' align='center'>&nbsp;</td>"); 
} 
for($ti=0;$ti<$se_len;$ti++){ 
    $num=substr($print_total_tax,$ti,1); 
	echo("<td class='cborder2' style='border-top-style:none' align='center'>$num</td>"); 


} 

?>
                    </tr>
                  </table></td>
                <td class="cborder2" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="cborder2" style="border-top-style:none;border-left-style:none">
              <tr height="20"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt2">월</span></td>
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt2">일</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">품 &nbsp; &nbsp; 목</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">규 격</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">수 량</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">단 가</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">공 급 가 액</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">세 액</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">비 고</span></td>
              </tr>

              <tr height="20"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_1";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_day_1";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_item_1";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_scale_1";?></td>               
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_ea_1";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_cost_1";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><? echo"$print_total_cost_1";?></td>
				<td class="cborder2" style="border-top-style:none" align="center"><?echo"$print_tax1";?></td>
                <td class="cborder2" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
             <tr height="20"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_2";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_day_2";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_item_2";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_scale_2";?></td>                
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_ea_2";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_cost_2";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$print_total_cost_2";?></td>
				<td class="cborder2" style="border-top-style:none" align="center"><?echo"$print_tax2";?></td>
                <td class="cborder2" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
              <tr height="20"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_3";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_day_3";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_item_3";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_scale_3";?></td>               
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_ea_3";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_cost_3";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$print_total_cost_3";?></td>
				<td class="cborder2" style="border-top-style:none" align="center"><?echo"$print_tax3";?></td>
                <td class="cborder2" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>
              <tr height="20"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><?echo"$my_month_4";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_day_4";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_item_4";?></td>
                <td class="cborder2" style="border-top-style:none" align="center"><?echo"$my_scale_4";?></td>                
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_ea_4";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><?echo"$my_cost_4";?></td>
                <td class="cborder2" style="border-top-style:none" align="right"><? echo"$print_total_cost_4";?></td>
				<td class="cborder2" style="border-top-style:none" align="center"><?echo"$print_tax4";?></td>
                <td class="cborder2" style="border-top-style:none" align="center">&nbsp;</td>
              </tr>

            </table></td>
        </tr>
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr height="20"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none" align="center"><span class="ttxt2">합 계 금 액</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">현 금</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">수 표</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">어 음</span></td>
                <td class="cborder2" style="border-top-style:none" align="center"><span class="ttxt2">외상미수금</span></td>
                <td class="cborder2" style="border-top-style:none;border-bottom-style:none" rowspan="2" align="center"><span class="ttxt2">이 금액을</span> 
                  <b><?echo"$end_sec5";?></b> <span class="ttxt2">함</span></td>
              </tr>
              <tr height="24"> 
                <td class="cborder2" style="border-top-style:none;border-left-style:none;border-bottom-style:none" align="center"><?echo"$sum_total_cost";?></td>
                <td class="cborder2" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec1";?></td>
                <td class="cborder2" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec2";?></td>
                <td class="cborder2" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec3";?></td>
                <td class="cborder2" style="border-top-style:none;border-bottom-style:none" align="center"><?echo"$end_sec4";?></td>
              </tr>
            </table></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td align="right">
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td class="ccmt2">[직인과 일련번호가 있어야 유효합니다]</td>

          <td align="right"></td>
  
        </tr>
      </table>
    </td>
  </tr>

  <tr height="70"> 
    <td><hr size="1"></td>
  </tr>

</table>

<p>&nbsp;</p>
</body>

