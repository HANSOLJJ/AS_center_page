<?
$amount= $s13_total_cost;

$supply = $amount / 1.1;
$tax = $amount - $supply;

$supply = round($supply);
?>
<script language="javascript">
   <!--
   function checkInput (form) {
      	 	  
	
   if(!form.total_year.value) {
      alert('작성일을 선택하세요!');
      form.total_year.focus();
      return;
   }

   if(!form.total_month.value) {
      alert('작성일을 선택하세요!');
      form.total_month.focus();
      return;
   }

   if(!form.total_day.value) {
      alert('작성일을 선택하세요!');
      form.total_day.focus();
      return;
   }

   if(!form.month_1.value) {
      alert('항목1 일자를 선택하세요!');
      form.month_1.focus();
      return;
   }

   if(!form.day_1.value) {
      alert('항목1 일자를 선택하세요!');
      form.day_1.focus();
      return;
   }

   if(!form.item_1.value) {
      alert('항목1 품목를 입력하세요!');
      form.item_1.focus();
      return;
   }

   if(!form.total_cost_1.value) {
      alert('항목1 공급가액을 입력하세요!');
      form.total_cost_1.focus();
      return;
   }

   if(form.total_cost_1.value) {
         if(!IsNumber(form.total_cost_1.name)) {
            alert("항목1 공급가액은 숫자여야 합니다!");
            form.total_cost_1.focus();
            return; 
         }
      }

	if(form.scale_1.value) {
         if(!IsNumber(form.scale_1.name)) {
            alert("항목1 규격은 숫자여야 합니다!");
            form.scale_1.focus();
            return; 
         }
      }


            
   form.submit();
}
   
   function IsNumber(formname) {
      var form = eval("document.signform." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }

//-->
</script>
<br><br>

<table width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name="signform" method="post" action="tax_write_process.php">

<INPUT type='hidden' name='number' value="<? echo"$number";?>">
<INPUT type='hidden' name='s11_meid' value="<? echo"$s11_meid";?>">

<!------------------------- 업체  --------------------------->
		<tr>
			<td  width='30%' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'><b>업체</b></p>
			</td>
			<td  width='70%'>
			&nbsp;&nbsp;

<?
//------------------업체명

$instant_query = "Select s11_com_name, s11_sec, s11_oaddr, s11_phone1, s11_phone2, s11_phone3, s11_com_num1, s11_com_num2, s11_com_num3 FROM $db11 WHERE s11_meid  ='$s11_meid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $s11_com_name=$instant_reply->s11_com_name;
	   $s11_sec=$instant_reply->s11_sec;
	   $s11_oaddr=$instant_reply->s11_oaddr;
	   $s11_phone1=$instant_reply->s11_phone1;
	   $s11_phone2=$instant_reply->s11_phone2;
	   $s11_phone3=$instant_reply->s11_phone3;
	   $s11_com_num1=$instant_reply->s11_com_num1;
	   $s11_com_num2=$instant_reply->s11_com_num2;
	   $s11_com_num3=$instant_reply->s11_com_num3;

	   $phone_num = $s11_phone1."-".$s11_phone2."-".$s11_phone3;
	   $com_num = $s11_com_num1."-".$s11_com_num2."-".$s11_com_num3;
	
   }

}

echo"$s11_com_name&nbsp;($com_num)";
?>
							

			</td>
		</tr>
<!------------------------- 작성일  --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			작성일
			</td>
			<td>
			&nbsp;&nbsp;
<?
$CAST_DATE = date("y",time());	
$FIRST_DAY = $CAST_DATE -1;		// 시작값
$LAST_DAY = $CAST_DATE +1;			// 마지막값
   echo "<select name='total_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 년";      
   }
   echo "</select> &nbsp;";

   echo "<select name='total_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 월";      
   }
   echo "</select> &nbsp;";

   echo "<select name='total_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 일";
   }
   echo "</select>";
?>
			</td>
		</tr>
<!------------------------- 항목 1 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목1
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_1'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 월";      
   }
   echo "</select> &nbsp;";

   echo "<select name='day_1'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 일";
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_1" size="25" maxlength="255" <?echo("$Form_style1");?> value='AS 비용'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_1" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_1" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_1" size="7" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_1" size="8" maxlength="255" <?echo("$Form_style1");?> value="<?echo"$supply";?>"></p>
			</td>
		</tr>
</table>
			</td>
		</tr>
<!------------------------- 항목 2 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목2
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_2'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 월";      
   }
   echo "</select> &nbsp;";

   echo "<select name='day_2'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 일";
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_2" size="25" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_2" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_2" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_2" size="7" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_2" size="8" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
		</tr>
</table>
			</td>
		</tr>
<!------------------------- 항목 3 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목3
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_3'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 월";      
   }
   echo "</select> &nbsp;";

   echo "<select name='day_3'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 일";
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_3" size="25" maxlength="255" <?echo("$Form_style1");?> ></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_3" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_3" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_3" size="7" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_3" size="8" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
		</tr>
</table>
			</td>
		</tr>
<!------------------------- 항목 4 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목4
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_4'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 월";      
   }
   echo "</select> &nbsp;";

   echo "<select name='day_4'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 일";
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_4" size="25" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_4" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_4" size="2" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_4" size="7" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_4" size="8" maxlength="255" <?echo("$Form_style1");?>></p>
			</td>
		</tr>
</table>
			</td>
		</tr>

<!------------------------- 분류1  --------------------------->
		<tr>
			<td height='35' align='center' bgcolor='#F2F8FB'>
			분류 1
			</td>
			<td>
			&nbsp;&nbsp;		
				<input type="radio" name="bill_sec1" value="A" checked>현 금&nbsp;			
				<input type="radio" name="bill_sec1" value="B">수 표
				<input type="radio" name="bill_sec1" value="C">어 음
				<input type="radio" name="bill_sec1" value="D">외상미수금		
			</td>
		</tr>	

<!------------------------- 분류2  --------------------------->
		<tr>
			<td height='35' align='center' bgcolor='#F2F8FB'>
			분류 2
			</td>
			<td>
			&nbsp;&nbsp;		
				<input type="radio" name="bill_sec2" value="A" checked>영 수&nbsp;			
				<input type="radio" name="bill_sec2" value="B">청 구	
			</td>
		</tr>	

<!------------------------- 주의  --------------------------->
		<tr>
			<td height='100' align='center' bgcolor='#F2F8FB'>
			<b><font color='red'>주의</font></b>
			</td>
			<td>
			&nbsp;&nbsp;<font color='red'>공급가액은 쉼표 또는 마침표 없이 숫자만을 기입하셔야 합니다.<br>
			&nbsp;&nbsp;엑셀 또는 백업이 가능한 세금계산서 프로그램을 메인으로 백업 및 사용하시고 <br>
			&nbsp;&nbsp;본 세금계산서 프로그램은 소액의 세금계산서 발행시 우편요금및 온라인 세금계산서 대행금<br>
			&nbsp;&nbsp;절약 차원에서 부수적으로 사용하시기 바랍니다.</font><br>
			</td>
		</tr>	
<!---------------------------------------------------->
</table>
<p align='center'><input type="button" value="작성" onClick="checkInput(this.form)">&nbsp; <input type="reset" value="다시 입력"></p>	

		</form>
