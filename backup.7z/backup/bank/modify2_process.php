<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

if($s13_tax_code =="N"){

$query = "UPDATE $db13 SET s13_tax_code = '$s13_tax_code' WHERE s13_asid  = '$number'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
}

echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=modify&number=$number'>");

}else

if($s13_tax_code =="Y"){

	if($tax_code ==""){

		echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=tax1&number=$number&s11_meid=$s11_meid&s13_total_cost=$s13_total_cost'>");
	}else{
		echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=tax_modify&number=$number&s11_meid=$s11_meid&s13_total_cost=$s13_total_cost&tax_code=$tax_code'>");
	}


  
} 

?>
