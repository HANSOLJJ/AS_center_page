<table  width='100%' cellpadding='0' cellspacing='0' border='1' align='center'bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td  width='18%' height='40' background="<?echo "$border_bg1";?>">
		<p align='center'><b>모델명</b></p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>불량증상</b></p>
		</td>
		<td  width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>AS 내역</b></p>
		</td>
		<td  width='32%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>부품내역</b></p>
		</td>
	</tr>

<?
$query_item_list = "SELECT s14_aiid, s14_asid, s14_model, s14_poor, s14_stat, s14_asrid  FROM $db14 WHERE s14_asid = '$my_s13_asid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}

while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s14_aiid = $row_item_list[s14_aiid];
$my_s14_asid = $row_item_list[s14_asid];
$my_s14_model = $row_item_list[s14_model];
$my_s14_poor = $row_item_list[s14_poor];
$my_s14_stat = $row_item_list[s14_stat];
$my_s14_asrid = $row_item_list[s14_asrid];

if($my_s14_as_nae ==""){$my_s14_as_nae ="&nbsp;";}

//------------------as 데이터 불러오기

$as_query1 = "SELECT s19_result FROM $db19 WHERE s19_asrid = '$my_s14_asrid'";
$as_result1 = mysql_query($as_query1);
if(!$as_result1) {
   error("QUERY_ERROR");
   exit;
}

$as_row1 = mysql_fetch_row($as_result1);

$my_s19_result = $as_row1[0];

if($my_s19_result ==""){$my_s19_result ="-";}
//------------------데이터 불러오기

$small_query1 = "SELECT s15_model_name, s15_model_sn FROM $db15 WHERE s15_amid = '$my_s14_model'";
$small_result1 = mysql_query($small_query1);
if(!$small_result1) {
   error("QUERY_ERROR");
   exit;
}

$small_row1 = mysql_fetch_row($small_result1);

$my_s15_model_name = $small_row1[0];
$my_s15_model_sn = $small_row1[1];

//------------------데이터 불러오기

$small_query2 = "SELECT s16_poor FROM $db16 WHERE s16_apid = '$my_s14_poor'";
$small_result2 = mysql_query($small_query2);
if(!$small_result2) {
   error("QUERY_ERROR");
   exit;
}

$small_row2 = mysql_fetch_row($small_result2);

$my_s16_poor = $small_row2[0];

echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><b>$my_s15_model_name</b><br>($my_s15_model_sn)</td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><font color='red'><b>$my_s16_poor</b></font></td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg>$my_s19_result</td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg>");
include"s_part_list.php";
echo("</td></tr>");

}

?>
</table>