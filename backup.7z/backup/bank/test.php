<?
$amount="1000";
$method="A";

$supply = $amount / 1.1;
$tax = $amount - $supply;

echo round($supply);
echo"<br>";
echo round($tax); 


?>