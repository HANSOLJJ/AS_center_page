<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$query = "UPDATE $db10 SET id = '$s11_meid', total_year = '$total_year', total_month = '$total_month', total_day = '$total_day', month_1 = '$month_1', day_1 = '$day_1', item_1 = '$item_1', scale_1 = '$scale_1', ea_1 = '$ea_1', cost_1 = '$cost_1', total_cost_1 = '$total_cost_1', month_2 = '$month_2', day_2 = '$day_2', item_2 = '$item_2', scale_2 = '$scale_2', ea_2 = '$ea_2', cost_2 = '$cost_2', total_cost_2 = '$total_cost_2', month_3 = '$month_3', day_3 = '$day_3', item_3 = '$item_3', scale_3 = '$scale_3', ea_3 = '$ea_3', cost_3 = '$cost_3', total_cost_3 = '$total_cost_3', month_4 = '$month_4', day_4 = '$day_4', item_4 = '$item_4', scale_4 = '$scale_4', ea_4 = '$ea_4', cost_4 = '$cost_4', total_cost_4 = '$total_cost_4', bill_sec1 = '$bill_sec1', bill_sec2 = '$bill_sec2'  WHERE signdate = '$tax_code'";


$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

   ##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
  echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=modify&number=$number'>");
} 

?>
