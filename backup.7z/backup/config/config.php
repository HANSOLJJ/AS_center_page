<?
$admin_email      = "digitalcoms@digitalcoms.net";  // 관리자 이메일 
$admin_name      = "AS 센터";    // 홈페이지명
$home                 = "index.php";   // 관리자 홈으로 리튼 

$web_title             = "▒ 디지탈컴 ▒";   // 익스플로러 사이트표시
$company            = "디지탈컴";   // 회사명
$explain               = "마이크포유, 마이크, 디지탈컴, 무선마이크, 노래방 무선마이크, 벨트타입 무선마이크, 송신기, 수신기, 충전기, 마이크 소모품";  // 사이트 설명
$telephone1         = "032-624-1980";  // 전화번호 1
$fax1					= "032-624-1985";  // 팩스번호 1


$css                    = "style.css"; //스타일 시트 경로
$img_dir             = "/../../_img";   // 일반페이지 이미지폴더 경로
$icon_dir             = "/../../_icon";  // 아이콘 이미지폴더 경로
$UPLOAD_folder  = "/../../_UPLOAD_FILEZ"; // 파일업로드 폴더 경로
$UPLOAD_folder_admin  = "/../../_UPLOAD_FILEZ"; // 파일업로드 폴더 경로

$DB_Admin_Member = "2010_admin_member"; // 관리자 정보 DB
$DB_web_Member    = "2010_member";        // 회원 정보 DB

$Form_style1   ="style='background-color:rgb(250,250,250);border-width:1px; border-color:rgb(158,200,222); border-style:solid;'";
$list_style1   ="style='border-bottom-width:1px; border-bottom-color:rgb(200,200,200); border-bottom-style:solid;'";
$list_style2   ="style='border-top-width:1px; border-bottom-width:1px; border-top-color:rgb(0,204,153); border-bottom-color:rgb(0,204,204); border-top-style:solid; border-bottom-style:solid;'";

$page_size ="770";

$fontcolor1  = "#606060";
$fontcolor2  = "#0f70bb"; //게시판 리스트 댓글수 글씨색
$bgcolor1    = "#FFFFFF";  // 관리자 게시판 배경색
$bgcolor2    = "#E4F5F9";  // 관리자 게시판 배경색 
$board_bgcolor2  = "bgcolor='#c2efed'";  // 게시판 공지글 배경색 
$board_bgcolor1  = "bgcolor='d2f2ff'";  // 게시판 공지글 배경색 


$admin_border_color1 ="#ffd7a2";
$admin_border_color1_1 ="#fff0db";
$admin_border_color2 ="#9de1f9";
$admin_border_color2_1 ="#edfaff";

$page_link = "page_style.php?sub_num=$sub_num&page_num=$page_num&db=$db";
$board_link = "sub_num=$sub_num&page_num=$page_num&db=$db&page=$page";
$notice_link = "sub_num=$sub_num&page_num=$page_num&db=$db&page=$page";
$instant_link ="sub_num=$sub_num&page_num=$page_num&db=$db&in_code=$in_code&page=$page&number=$number";

$file1= 'com_pro_digitalcom_20100826.pdf';
$file2= 'sche_digitalcom_20100830.pdf';
$file3= 'raintrace.pdf';