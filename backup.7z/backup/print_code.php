<script language="javascript">
<!--
function profileWindow(ref) {
   var window_left = (screen.width-700)/2;
   var window_top = (screen.height-500)/2;   
   window.open(ref,"profileWin",'width=700,height=500,status=no,scrollbars=yes,top=' + window_top + ',left=' + window_left + '');
}
//-->
</script>