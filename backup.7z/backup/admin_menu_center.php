<table  width='230' cellpadding='0' cellspacing='0'>
	

		<tr>
		<td width='20'>
        </td>
		<td width='210' height='25' align='left' onclick='menuclick(submenu1, bar1);' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#00d8ff' onmouseout=this.style.backgroundColor=''  title="Administrator's Tool">&nbsp;<img src="admin_menu_arrow_close.gif" border=0 id="bar1" align="absmiddle">
			<b>AS  愿由</b>
		</td>
	</tr>
	<tr>
		<td Height='5' colspan='2'>
		</td>
	</tr>
	<tr>
		<td>
        </td>
		<td align="left">
			<span id="submenu1" style="margin-left:5; display:none;">

			<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="center_parts/list.php?in_code=list_view" target="admin_target" >1 -  AS  愿由</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>
			<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="center_parts_order/list.php?in_code=list_view" target="admin_target" >2 -  AS  泥</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>
			<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="center_parts_order_list/list.php?in_code=list_view" target="admin_target" >3 -  AS  泥 댁</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>
			
			</span>
		</td>
	</tr>
<!---->

	<tr>
		<td width='20'>
        </td>
		<td width='210' height='25' align='left' onclick='menuclick(submenu2, bar2);' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#00d8ff' onmouseout=this.style.backgroundColor=''  title="Administrator's Tool">&nbsp;<img src="admin_menu_arrow_close.gif" border=0 id="bar2" align="absmiddle">
			<b>AS 愿由</b>
		</td>
	</tr>
	<tr>
		<td Height='5' colspan='2'>
		</td>
	</tr>
	<tr>
		<td>
        </td>
		<td align="left">
			<span id="submenu2" style="margin-left:5; display:none;">

		
			<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="as_center1/list.php" target="admin_target" > AS 怨 愿由</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>
			
			<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="as_center2/list.php" target="admin_target" > AS 愿由</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>	

			<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="as_center3/list.php" target="admin_target" > AS 異怨 愿由</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>	

			<table  width='210' cellpadding='0' cellspacing='0' BGcolor='#EFF8FF' style='cursor:hand;' bgcolor='#5dbff4'   onmouseover=this.style.backgroundColor='#fffdc2' onmouseout=this.style.backgroundColor=''>
				<tr>
					<td width='10'>
					</td>
					<td width='200' Height='25'>
					<a href="as_center4/list.php" target="admin_target" > AS 댁 愿由</a><br>
					</td>
				</tr>
				<tr>
					<td  Height='5' colspan='2' BGcolor='white'>
					</td>
				</tr>
			</table>	

			</span>
		</td>
	</tr>
<!---->
</table>