<?php
/**
 * Modern MySQLi Database Connection
 * Replaces deprecated mysql_* functions
 */

class Database {
    private $conn;
    private $result;

    public function __construct() {
        // Docker 환경에서 정의된 연결 정보
        $host = getenv('DB_HOST') ?: 'mysql';
        $user = getenv('DB_USER') ?: 'mic4u_user';
        $password = getenv('DB_PASSWORD') ?: 'change_me';
        $database = getenv('DB_NAME') ?: 'mic4u';

        $this->conn = new mysqli($host, $user, $password, $database);

        if ($this->conn->connect_error) {
            die('데이터베이스 연결 실패: ' . $this->conn->connect_error);
        }

        $this->conn->set_charset('utf8mb4');
    }

    public function query($sql) {
        $this->result = $this->conn->query($sql);
        if (!$this->result) {
            die('쿼리 실행 실패: ' . $this->conn->error);
        }
        return $this->result;
    }

    public function fetch_assoc() {
        if ($this->result) {
            return $this->result->fetch_assoc();
        }
        return null;
    }

    public function fetch_all() {
        $data = [];
        if ($this->result) {
            while ($row = $this->result->fetch_assoc()) {
                $data[] = $row;
            }
        }
        return $data;
    }

    public function num_rows() {
        return $this->result ? $this->result->num_rows : 0;
    }

    public function affected_rows() {
        return $this->conn->affected_rows;
    }

    public function insert_id() {
        return $this->conn->insert_id;
    }

    public function escape($str) {
        return $this->conn->real_escape_string($str);
    }

    public function close() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}

// Global database instance
$db = new Database();
?>
