<?
include "@config.php";
include "@error_function.php";
include "@access.php";

$admin_ip = getenv('REMOTE_ADDR');
?>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>뱀ъ댄 愿由ы</title>
<link rel='stylesheet' href='<? echo("$css");?>' type=text/css>
</head>

<body leftmargin='0' marginwidth='0' topmargin='0' marginheight='0'>

<table width='100%' Height='100%' border='0' cellpadding='0' cellspacing='0' align='center' >
	<tr>
		<td height='25' bgcolor='#e8e8e8'>&nbsp;&nbsp;
			>&nbsp;<a href="lcm1.php" target="menu_target"><b>AS  愿由</b></a>&nbsp;
			>&nbsp;<a href="lcm2.php" target="menu_target"><b> AS 愿由 </b></a>&nbsp;
			>&nbsp;<a href="lcm3.php" target="menu_target"><b> AS 留 愿由 </b></a>&nbsp;
			>&nbsp;<a href="logout.php"> <b>濡洹몄 </b></a>&nbsp;
		</td>
	</tr>
	<tr>
		<td bgcolor='#e8e8e8'>

		<iframe name="menu_target" src="blank.php" width="100%" height="30" scrolling='no' marginwidth="0" marginheight="0" frameborder="no"></iframe>

		</td>
	</tr>
	<tr>
		<td  height="100%" >

		<iframe name="admin_target" src="welcome.php" width="100%" height="100%" scrolling='auto' marginwidth="0" marginheight="0" frameborder="no"></iframe>

		</td>
	</tr>
</table>