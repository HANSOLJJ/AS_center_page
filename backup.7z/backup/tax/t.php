<table border=1>
<tr>
<?

$se='342424';
$se_len=strlen($se); 

for($ni=1;$ni<11-$se_len;$ni++){ 
    echo("<TD>&nbsp;</TD>"); 
$temp = $ni;
} 
for($ti=1;$ti<$se_len;$ti++){ 
    $num=substr($se,$ti,1); 
    echo("<TD CLASS=inp>$ti-$num</TD>"); 

} 
echo ("$temp");
?>


---------------
<?

$total_cost='12312123';
echo ("$total_cost");
$se_len=strlen($total_cost); 

for($ni=0;$ni<10-$se_len;$ni++){ 
    echo("<td class='cborder' style='border-top-style:none' align='center'>&nbsp;</td>"); 
$temp_colum = $ni;
} 
for($ti=0;$ti<$se_len;$ti++){ 
    $num=substr($total_cost,$ti,1); 
	echo("<td class='cborder' style='border-top-style:none' align='center'>$num</td>"); 


} 


?>