<script language="javascript">
<!--
function profileWindow(ref) {
   var window_left = (screen.width-700)/2;
   var window_top = (screen.height-500)/2;   
   window.open(ref,"profileWin",'width=700,height=500,status=no,scrollbars=yes,top=' + window_top + ',left=' + window_left + '');
}
//-->
</script>

<?
if(!$page) {$page = 1;}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 20;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
if(!eregi("[^[:space:]]+",$key)) {
   $query = "SELECT count(*) FROM $db10";
} else {
   $encoded_key = urlencode($key);
   $query = "SELECT count(*) FROM $db10 WHERE $keyfield LIKE '%$key%'";  
}

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);

mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}

####################

?>
<Br><br>
<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='10%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>No.</b></p>
		</td>
		<td width='10%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>발행번호</b></p>
		</td>
		<td width='10%'height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>업체명</b></p>
		</td>		
		<td width='10%'  height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>공급가액</b></p>
		</td>
		<td width='10%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>작성일</b></p>
		</td>
		<!---
		<td width='10%'  height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>상태</b></p>
		</td>
		<td width='10%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>비고</b></p>
		</td>--->
	</tr>
<?
$time_limit = 60*60*24*$notify_new_article; 



#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
if(!eregi("[^[:space:]]+",$key)) {
	$query = "SELECT uid, id, total_year, total_month, total_day, month_1, day_1, item_1, scale_1, ea_1, cost_1, total_cost_1, month_2, day_2, item_2, scale_2, ea_2, cost_2, total_cost_2, month_3, day_3, item_3, scale_3, ea_3, cost_3, total_cost_3, month_4, day_4, item_4, scale_4, ea_4, cost_4, total_cost_4, bill_sec1, bill_sec2, signdate, state FROM $db10 ORDER BY uid DESC LIMIT $first, $num_per_page ";
} else {
	$query = "SELECT uid, id, total_year, total_month, total_day, month_1, day_1, item_1, scale_1, ea_1, cost_1, total_cost_1, month_2, day_2, item_2, scale_2, ea_2, cost_2, total_cost_2, month_3, day_3, item_3, scale_3, ea_3, cost_3, total_cost_3, month_4, day_4, item_4, scale_4, ea_4, cost_4, total_cost_4, bill_sec1, bill_sec2, signdate, state FROM $db10 WHERE $keyfield LIKE '%$key%' ORDER BY uid DESC LIMIT $first, $num_per_page";
}


$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_uid = $row [uid];
   $my_id = $row [id];
   $my_total_year = $row [total_year];
   $my_total_month = $row [total_month];
   $my_total_day = $row[total_day];
   $my_total_cost_1 = $row [total_cost_1];
   $my_total_cost_2 = $row [total_cost_2];
   $my_total_cost_3 = $row [total_cost_3];
   $my_total_cost_4 = $row [total_cost_4];
   $my_bill_sec1 = $row [bill_sec1];
   $my_bill_sec2 = $row [bill_sec2];
   $my_code = $row [signdate];
   $my_signdate = date("y. m. d",$row [signdate]);
   $my_state = $row [state];

if($my_total_cost_1 ==''){$my_total_cost_1 ='0';}
if($my_total_cost_2 ==''){$my_total_cost_2 ='0';}
if($my_total_cost_3 ==''){$my_total_cost_3 ='0';}
if($my_total_cost_4 ==''){$my_total_cost_4 ='0';}


$total_cost = $my_total_cost_1 + $my_total_cost_2 + $my_total_cost_3 + $my_total_cost_4;

$total_cost = number_format($total_cost);
##############

##### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$result2= mysql_query("SELECT s11_meid, s11_com_name, s11_com_num1, s11_com_num2, s11_com_num3 FROM $db11 WHERE s11_meid = '$my_id'");

if (!$result2) {
   error("QUERY_ERROR");
   exit;
}

##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$row2 = mysql_fetch_row($result2);

$my_com_name = $row2[1];
$my_com_num1 = $row2[2];
$my_com_num2 = $row2[3];
$my_com_num3 = $row2[4];

$my_com_num = $my_com_num1.'-'.$my_com_num2.'-'.$my_com_num3;

if($my_state=='미승인'){
$my_etc= "<a href='tax.php?in_code=tax_modify&number=$my_uid&etc1=$my_id'><img src='../$icon_dir/button_blue_modify.gif' border='0' align='absmiddle'></a>&nbsp;<a href='tax.php?in_code=tax_del&number=$my_uid'><img src='../$icon_dir/button_blue_del.gif' border='0' align='absmiddle'></a>";
} else
if($my_state=='승인'){$my_etc= "승인 완료";} 
##############

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}

echo("<tr>");

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><a href=\"javascript://\" onClick=\"profileWindow('view_com.php?number=" . $my_uid . "')\">$my_code</a></td>");

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg><font  Class='size11'><a href=\"javascript://\" onClick=\"profileWindow('view_com.php?number=" . $my_uid . "')\">$my_com_name<br>($my_com_num)</a></font></td>");

echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg><a href=\"javascript://\" onClick=\"profileWindow('view_com.php?number=" . $my_uid . "')\">$total_cost 원</a></td>");

echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg><a href=\"javascript://\" onClick=\"profileWindow('view_com.php?number=" . $my_uid . "')\">[$my_signdate]</a></td>");

##############echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg><a href=\"javascript://\" onClick=\"profileWindow('view_com.php?number=" . $my_uid . "')\">$my_state</a></td>");

##############echo("	<td height='35' align='center' valign='middle' $list_style1 $td_bg>$my_etc</td>");

$article_num--;
}

echo("</table>");
?>


<table  width="95%" border="0" cellspacing="0" align="center">
    <tr>
<form method="post" action="<?echo("tax.php?page_num=$page_num&db=$db&in_code=tax_list")?>">


							
							<td width='280' height='35'>
							<select name="keyfield" size="1" align='absmiddle' <?echo("$Form_style1");?>>
							   <option value="signdate">발행번호</option>
							</select>
							&nbsp;&nbsp;
							<input type="text" name="key" size='18' <?echo("$Form_style1");?>>&nbsp;&nbsp;&nbsp;
							<input type='submit' STYLE='font-size:9pt;' value='검색'>
							</td>
							
						</form>
							<td  align='center'>

<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지 링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo("<a href=\"tax.php?page_num=$page_num&db=$db&in_code=$in_code&skin=$skin&page=$my_page&keyfield=$keyfield\">←</a>&nbsp;");
}

##### 현재의 페이지 블록범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo("<b>[$direct_page]</b>&nbsp;");
   } else {
      echo("<a href=\"tax.php?page_num=$page_num&db=$db&in_code=$in_code&skin=$skin&page=$direct_page&keyfield=$keyfield\" >[$direct_page]</a>&nbsp;");
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo("<a href=\"tax.php?page_num=$page_num&db=$db&in_code=$in_code&skin=$skin&page=$my_page&keyfield=$keyfield\" >→</a>");
}
?>   


							</td>

						</tr>

					</table>



