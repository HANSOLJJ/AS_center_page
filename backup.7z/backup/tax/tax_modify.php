<? 

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT uid, id, total_year, total_month, total_day, month_1, day_1, item_1, scale_1, ea_1, cost_1, total_cost_1, month_2, day_2, item_2, scale_2, ea_2	, cost_2, total_cost_2, month_3, day_3, item_3, scale_3, ea_3, cost_3, total_cost_3, month_4, day_4, item_4, scale_4, ea_4, cost_4, total_cost_4, bill_sec1, bill_sec2, signdate, state FROM $db10 WHERE uid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_uid = $row->uid;
$my_id = $row->id;
$my_total_year = $row->total_year;
$my_total_month = $row->total_month;
$my_total_day = $row->total_day;

$my_month_1 = $row->month_1;
$my_day_1 = $row->day_1;
$my_item_1 = $row->item_1;
$my_scale_1 = $row->scale_1;
$my_ea_1 = $row->ea_1;
$my_cost_1 = $row->cost_1;

$my_month_2 = $row->month_2;
$my_day_2 = $row->day_2;
$my_item_2 = $row->item_2;
$my_scale_2 = $row->scale_2;
$my_ea_2 = $row->ea_2;
$my_cost_2 = $row->cost_2;

$my_month_3 = $row->month_3;
$my_day_3 = $row->day_3;
$my_item_3 = $row->item_3;
$my_scale_3 = $row->scale_3;
$my_ea_3 = $row->ea_3;
$my_cost_3 = $row->cost_3;

$my_month_4 = $row->month_4;
$my_day_4 = $row->day_4;
$my_item_4 = $row->item_4;
$my_scale_4 = $row->scale_4;
$my_ea_4 = $row->ea_4;
$my_cost_4 = $row->cost_4;

$my_total_cost_1 = $row->total_cost_1;
$my_total_cost_2 = $row->total_cost_2;
$my_total_cost_3 = $row->total_cost_3;
$my_total_cost_4 = $row->total_cost_4;

$my_bill_sec1 = $row->bill_sec1;
$my_bill_sec2 = $row->bill_sec2;
$my_code = $row->signdate;
$my_state = $row->state;


if($my_ea_1=='0'){$my_ea_1='';}
if($my_cost_1=='0'){$my_cost_1='';}

if($my_ea_2=='0'){$my_ea_2='';}
if($my_cost_2=='0'){$my_cost_2='';}

if($my_ea_3=='0'){$my_ea_3='';}
if($my_cost_3=='0'){$my_cost_3='';}

if($my_ea_4=='0'){$my_ea_4='';}
if($my_cost_4=='0'){$my_cost_4='';}


if($my_bill_sec1 =='A'){$bill_ches1='checked';}else
if($my_bill_sec1 =='B'){$bill_ches2='checked';}else
if($my_bill_sec1 =='C'){$bill_ches3='checked';}else
if($my_bill_sec1 =='D'){$bill_ches4='checked';}

if($my_bill_sec2 =='A'){$bill_ches5='checked';}else
if($my_bill_sec2 =='B'){$bill_ches6='checked';}
?>

<script language="javascript">
   <!--
   function checkInput (form) {
      	 	  
	if(!form.id.value) {
      alert('업체를 선택하세요!');
      form.id.focus();
      return;
   }

   if(!form.total_year.value) {
      alert('작성일을 선택하세요!');
      form.total_year.focus();
      return;
   }

   if(!form.total_month.value) {
      alert('작성일을 선택하세요!');
      form.total_month.focus();
      return;
   }

   if(!form.total_day.value) {
      alert('작성일을 선택하세요!');
      form.total_day.focus();
      return;
   }

   if(!form.month_1.value) {
      alert('항목1 일자를 선택하세요!');
      form.month_1.focus();
      return;
   }

   if(!form.day_1.value) {
      alert('항목1 일자를 선택하세요!');
      form.day_1.focus();
      return;
   }

   if(!form.item_1.value) {
      alert('항목1 품목를 입력하세요!');
      form.item_1.focus();
      return;
   }

   if(!form.total_cost_1.value) {
      alert('항목1 공급가액을 입력하세요!');
      form.total_cost_1.focus();
      return;
   }

   if(form.total_cost_1.value) {
         if(!IsNumber(form.total_cost_1.name)) {
            alert("항목1 공급가액은 숫자여야 합니다!");
            form.total_cost_1.focus();
            return; 
         }
      }

	if(form.scale_1.value) {
         if(!IsNumber(form.scale_1.name)) {
            alert("항목1 규격은 숫자여야 합니다!");
            form.scale_1.focus();
            return; 
         }
      }


            
   form.submit();
}
   
   function IsNumber(formname) {
      var form = eval("document.signform." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }

//-->
</script>
<br><br>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name="signform" method="post" action="tax_modify_process.php?number=<?echo("$my_uid");?>">


<!------------------------- 업체  --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			<p align='center'>업체</p>
			</td>
			<td>
			&nbsp;&nbsp;
								<select name="id">
							<option value=''>업체를 선택해 주세요.</option>		
<?

##### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$result= mysql_query("SELECT s11_meid, s11_id, s11_com_name, s11_com_num1, s11_com_num2, s11_com_num3 FROM $db11 WHERE s11_com_name !='' ORDER BY s11_meid");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장한다.   

$my_uid = $row[s11_meid];
$my_id = $row[s11_id];
$my_com_name = $row[s11_com_name];
$my_com_num1 = $row[s11_com_num1];
$my_com_num2 = $row[s11_com_num2];
$my_com_num3 = $row[s11_com_num3];

$my_com_num = $my_com_num1.'-'.$my_com_num2.'-'.$my_com_num3;
##### 

if($my_id == $etc1){$my_id_checked ='selected';}else{$my_id_checked ='';}

echo("<option value='$my_id' $my_id_checked>$my_com_name($my_com_num)</option>");

}
?>

			</select>
			</td>
		</tr>
<!------------------------- 작성일  --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			작성일
			</td>
			<td>
			&nbsp;&nbsp;
<?
$CAST_DATE = date("y",time());	
$FIRST_DAY = $CAST_DATE -1;		// 시작값
$LAST_DAY = $CAST_DATE +1;			// 마지막값
   echo "<select name='total_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
if($i == $my_total_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      	  

   }
   echo "</select> &nbsp;";

   echo "<select name='total_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $my_total_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}  
   }
   echo "</select> &nbsp;";

   echo "<select name='total_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $my_total_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>
			</td>
		</tr>
<!------------------------- 항목 1 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목1
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_1'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $my_month_1){echo "<option value='" . $i . "' selected>" . $i . " 월";      }else{echo "<option value='" . $i . "'>" . $i . " 월";}
   }
   echo "</select> &nbsp;";

   echo "<select name='day_1'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $my_day_1){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_1" size="25" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_item_1");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_1" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_scale_1");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_1" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_ea_1");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_1" size="7" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_cost_1");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_1" size="8" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_total_cost_1");?>'></p>
			</td>
		</tr>
</table>
			</td>
		</tr>
<!------------------------- 항목 2 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목2
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_2'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $my_month_2){echo "<option value='" . $i . "' selected>" . $i . " 월";      }else{echo "<option value='" . $i . "'>" . $i . " 월";} 
   }
   echo "</select> &nbsp;";

   echo "<select name='day_2'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $my_day_2){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_2" size="25" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_item_2");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_2" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_scale_2");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_2" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_ea_2");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_2" size="7" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_cost_2");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_2" size="8" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_total_cost_2");?>'></p>
			</td>
		</tr>
</table>
			</td>
		</tr>
<!------------------------- 항목 3 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목3
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_3'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $my_month_3){echo "<option value='" . $i . "' selected>" . $i . " 월";      }else{echo "<option value='" . $i . "'>" . $i . " 월";} 
   }
   echo "</select> &nbsp;";

   echo "<select name='day_3'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $my_day_3){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_3" size="25" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_item_3");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_3" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_scale_3");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_3" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_ea_3");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_3" size="7" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_cost_3");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_3" size="8" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_total_cost_3");?>'></p>
			</td>
		</tr>
</table>
			</td>
		</tr>
<!------------------------- 항목 4 --------------------------->
		<tr>
			<td  width='100' height='35' align='center' bgcolor='#F2F8FB'>
			항목4
			</td>
			<td>

<table width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p align='center'>월/일</p>
		</td>
		<td>
		<p align='center'>품목</p>
		</td>
		<td>
		<p align='center'>규격</p>
		</td>
		<td>
		<p align='center'>수량</p>
		</td>
		<td>
		<p align='center'>단가</p>
		</td>
		<td>
		<p align='center'>공급가액</p>
		</td>
	</tr>
	<tr>
		<td>

			&nbsp;&nbsp;
<?
   echo "<select name='month_4'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $my_month_4){echo "<option value='" . $i . "' selected>" . $i . " 월";      }else{echo "<option value='" . $i . "'>" . $i . " 월";} 
   }
   echo "</select> &nbsp;";

   echo "<select name='day_4'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $my_day_4){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>

			</td>
			<td>
			<p align='center'><input type="text" name="item_4" size="25" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_item_4");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="scale_4" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_scale_4");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="ea_4" size="2" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_ea_4");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="cost_4" size="7" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_cost_4");?>'></p>
			</td>
			<td>
			<p align='center'><input type="text" name="total_cost_4" size="8" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_total_cost_4");?>'></p>
			</td>
		</tr>
</table>
			</td>
		</tr>

<!------------------------- 분류1  --------------------------->
		<tr>
			<td height='35' align='center' bgcolor='#F2F8FB'>
			분류 1
			</td>
			<td>
			&nbsp;&nbsp;		
				<input type="radio" name="bill_sec1" value="A" <?echo("$bill_ches1");?>>현 금&nbsp;			
				<input type="radio" name="bill_sec1" value="B" <?echo("$bill_ches2");?>>수 표
				<input type="radio" name="bill_sec1" value="C" <?echo("$bill_ches3");?>>어 음
				<input type="radio" name="bill_sec1" value="D" <?echo("$bill_ches4");?>>외상미수금		
			</td>
		</tr>	

<!------------------------- 분류2  --------------------------->
		<tr>
			<td height='35' align='center' bgcolor='#F2F8FB'>
			분류 2
			</td>
			<td>
			&nbsp;&nbsp;		
				<input type="radio" name="bill_sec2" value="A" <?echo("$bill_ches5");?>>영 수&nbsp;			
				<input type="radio" name="bill_sec2" value="B" <?echo("$bill_ches6");?>>청 구	
			</td>
		</tr>	

<!------------------------- 주의  --------------------------->
		<tr>
			<td height='100' align='center' bgcolor='#F2F8FB'>
			<b><font color='red'>주의</font></b>
			</td>
			<td>
			&nbsp;&nbsp;<font color='red'>공급가액은 쉼표 또는 마침표 없이 숫자만을 기입하셔야 합니다.<br>
			&nbsp;&nbsp;엑셀 또는 백업이 가능한 세금계산서 프로그램을 메인으로 백업 및 사용하시고 <br>
			&nbsp;&nbsp;본 세금계산서 프로그램은 소액의 세금계산서 발행시 우편요금및 온라인 세금계산서 대행금<br>
			&nbsp;&nbsp;절약 차원에서 부수적으로 사용하시기 바랍니다.</font><br>
			</td>
		</tr>	
<!---------------------------------------------------->
</table>
<p align='center'><input type="button" value="작성" onClick="checkInput(this.form)">&nbsp; <input type="reset" value="다시 입력"></p>	

		</form>
