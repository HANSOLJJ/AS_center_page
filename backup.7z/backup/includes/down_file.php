<?php


extract($_GET);

$file ='com_pro_digitalcom_20100826.pdf';

	header("Content-Type: file/unknown"); 
	header("Content-Disposition: attachment; filename=$my_filename"); 
	header("Content-Transfer-Encoding: binary"); 

	$file_path= $file;

	$fh = fopen($file_path, "rb"); 

	fpassthru($fh); 


	exit; 


?> 