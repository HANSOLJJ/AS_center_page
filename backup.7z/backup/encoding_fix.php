<?php
/**
 * Encoding detection and conversion helper
 * Automatically converts output from EUC-KR to UTF-8 if needed
 */

// Output buffering with automatic conversion
ob_start(function($buffer) {
    // Detect if buffer appears to be EUC-KR encoded
    if (!mb_check_encoding($buffer, 'UTF-8')) {
        // Try to convert from EUC-KR to UTF-8
        $converted = mb_convert_encoding($buffer, 'UTF-8', 'EUC-KR');
        if ($converted !== false) {
            return $converted;
        }
    }
    return $buffer;
});

// Force output encoding
ini_set('output_encoding', 'UTF-8');
mb_http_output('UTF-8');
?>
