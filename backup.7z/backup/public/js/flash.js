function JS_viewObj(objhtml) { 
    document.write(objhtml); 
} 