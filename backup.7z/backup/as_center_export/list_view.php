<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='100%' height='50' background="<?echo "$border_bg1";?>">
			<p align='center'><SPAN class='admin_title_big'><a href='list.php?in_code=exl_1'>택배용 엑셀출력</a></span></p>	
		</td>
	</tr>
</table>