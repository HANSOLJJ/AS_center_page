<?php
$title = "택배용1";

header( "Content-type: application/vnd.ms-excel; charset=utf-8" ); 
header("Content-Disposition: attachment; filename=".$title.".xls");
 header( "Content-Description: PHP4 Generated Data" ); 
 print("<meta http-equiv=\"Content-Type\" content=\"application/vnd.ms-excel; charset=utf-8\">"); 

?>

<html>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=enc-kr">
</head>
<body>
<table border=1>

<?php
### DB 연결
$mysql_host = 'localhost';     // 호스트명 
$mysql_user = 'mic4u41';     // 사용자 계정 
$mysql_pwd  = 'digidigi';      // 비밀번호 
$mysql_db   = 'mic4u41';       // DB(데이터베이스)명) 
$connect = @mysql_connect($mysql_host, $mysql_user, $mysql_pwd) or die("서버 접속에 실패 했습니다. 계정 또는 패스워드를 확인하세요.");
@mysql_select_db($mysql_db, $connect) or die("DB 연결에 실패 했습니다. 데이터베이스명을 확인하세요.");

####날짜변환
$s_d = mktime(0,0,0,$s_month, $s_day, $s_year);
$e_d = mktime(0,0,0,$e_month, $e_day, $e_year);
###
$query = "SELECT ex_company, ex_address_no, ex_address, ex_tel FROM step13_as WHERE s13_as_level LIKE '5'  AND s13_as_center  = '$center' AND s13_as_in_date BETWEEN '$s_d' AND '$e_d' ORDER BY s13_asid DESC";
$result= mysql_query($query);

if (!$result) {
   error("등록된 데이터가 없습니다.");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

	// 이부분에 데이터를 출력시킨다.
$n1 = $row[ex_company];
$n2 = $row[ex_address_no];
$n3 = $row[ex_address];
$n4 = $row[ex_tel];

print"<tr><td>$n1</td><td>$n2</td><td>$n3</td><td>$n4</td></tr>";


}?>



</table>
</body>
</html>
