<script language="javascript">
<!--
function sendit() {
	
	if(!form.s12_sms_category.value) {
      alert('카테고리를 선택해 주세요!');
      form.s12_sms_category.focus();
      return;
   }

	if(!form.contents.value) {
      alert('SMS 내용을 입력하세요!');
      form.contents.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>
<script>

function GetTextLength(text){
	return text.length;
}

function GetTextByte(text){
	var length = 0;
	var ch;
	for (var i = 0; i < text.length; i++) {
		ch = escape(text.charAt(i));
		if ( ch.length == 1 ) {
			length++;


		}else if (ch.indexOf("%u") != -1) {
			length += 2;
		}else if (ch.indexOf("%") != -1) {
			length += ch.length/3;
		}
	}
	return length;
}


function viewByte(obj, objid){
	var obj = document.getElementById("view1");
	var obj2 = document.getElementById("view2");
	var text = document.getElementById("contents").value;
	obj.value = GetTextByte(text);
	obj2.value = GetTextLength(text);	

	if (obj.value == '81') {
		alert('SMS 내용은 최대 80Byte 입니다. 80Byte 가 넘어가면 자동으로 80Byte 까지만 저장됩니다.');
		}
			
}
</script>

<body onkeydown="viewByte()" onkeypress="viewByte()" onkeyup="viewByte()">

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='write_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>' enctype='multipart/form-data'>

<!------------------------- 카테고리  --------------------------->
		<tr>
			<td height='40' align='center' bgcolor='#fbfbfb' align='center'>
			<b>카테고리</b>
			</td>
			<td>
			<select name="s12_sms_category"<?echo("$Form_style1");?>>
			<option value=''>카테고리를 선택해 주세요.</option>
			<option value='접수'>접수</option>
			<option value='택배'>택배</option>
			<option value='입금'>입금</option>
			</select>
			</td>
		</tr>
<!------------------------- 내용  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>SMS 내용</b>
			</td>
			<td width='70%'>
			<textarea name="contents" rows="5" cols="16" <?echo("$Form_style1");?>></textarea><br>
			<input type="text" id="view2" style="text-align:right;width:50;" />자<br>
			<input type="text" id="view1" style="text-align:right;width:50;"/>Byte
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>