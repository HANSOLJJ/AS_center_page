<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s12_ssid, s12_sms_category, s12_sms_sample FROM $db12 WHERE s12_ssid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s12_ssid = $row->s12_ssid;
$my_s12_sms_category = $row->s12_sms_category;
$my_s12_sms_sample = $row->s12_sms_sample;

if($my_s12_sms_category =="접수"){$category_select1="selected";}else
if($my_s12_sms_category =="택배"){$category_select2="selected";}else
if($my_s12_sms_category =="입금"){$category_select3="selected";}

##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {
	

	if(!form.contents.value) {
      alert('SMS 내용을 입력하세요!');
      form.contents.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>
<script>

function GetTextLength(text){
	return text.length;
}

function GetTextByte(text){
	var length = 0;
	var ch;
	for (var i = 0; i < text.length; i++) {
		ch = escape(text.charAt(i));
		if ( ch.length == 1 ) {
			length++;


		}else if (ch.indexOf("%u") != -1) {
			length += 2;
		}else if (ch.indexOf("%") != -1) {
			length += ch.length/3;
		}
	}
	return length;
}


function viewByte(obj, objid){
	var obj = document.getElementById("view1");
	var obj2 = document.getElementById("view2");
	var text = document.getElementById("contents").value;
	obj.value = GetTextByte(text);
	obj2.value = GetTextLength(text);	

	if (obj.value == '81') {
		alert('SMS 내용은 최대 80Byte 입니다. 80Byte 가 넘어가면 자동으로 80Byte 까지만 저장됩니다.');
		}
			
}
</script>

<body onkeydown="viewByte()" onkeypress="viewByte()" onkeyup="viewByte()">

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>

<!------------------------- 카테고리  --------------------------->
		<tr>
			<td height='40' align='center' bgcolor='#fbfbfb' align='center'>
			<b>카테고리</b>
			</td>
			<td>
<? echo"$my_s12_sms_category";?>
			</td>
		</tr>
<!------------------------- 내용  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>SMS 내용</b>
			</td>
			<td width='70%'>
			<textarea name="contents" rows="5" cols="16" <?echo("$Form_style1");?>><? echo("$my_s12_sms_sample");?></textarea><br>
			<input type="text" id="view2" style="text-align:right;width:50;" />자<br>
			<input type="text" id="view1" style="text-align:right;width:50;"/>Byte
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>