<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 사용자가 아무값도 입력하지 않았거나 입력한 값이 허용되지 않는 값일 경우 에러메시지를 출력하고 스크립트를 종료한다.

if(!ereg("([^[:space:]]+)", $s1_name)) {
   error("NOT_ALLOWED_s1_name");
   exit;
}

$query = "INSERT INTO $db (s1_caid, s1_name, s1_erp, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1, s1_cost_won) VALUES ('$s1_caid', '$s1_name', '$s1_erp', '$s1_cost_c_1', '$s1_cost_a_1', '$s1_cost_a_2', '$s1_cost_n_1', '$s1_cost_n_2', '$s1_cost_s_1', '$s1_cost_won')";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>
