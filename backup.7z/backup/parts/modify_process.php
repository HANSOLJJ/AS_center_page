<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$query = "UPDATE $db SET s1_caid = '$s1_caid', s1_name = '$s1_name', s1_erp = '$s1_erp', s1_cost_c_1 = '$s1_cost_c_1', s1_cost_a_1 = '$s1_cost_a_1', s1_cost_a_2 = '$s1_cost_a_2', s1_cost_n_1 = '$s1_cost_n_1', s1_cost_n_2 = '$s1_cost_n_2', s1_cost_s_1 = '$s1_cost_s_1', s1_cost_won = '$s1_cost_won' WHERE s1_uid  = '$number'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>
