<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>


<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<? echo"$title_b_1"; ?>

<?
$db= 'step1_parts';
switch ($in_code) {

// 일반페이지


case ("") : 	include"list_view.php"; Break;
case ("list_view") : 	include"list_view.php"; Break;
case ("write") : 	include"write.php"; Break;
case ("modify") : 	include"modify.php"; Break;
case ("del") : 	include"del.php"; Break;
case ("view") : 	include"view.php"; Break;

}

?>
