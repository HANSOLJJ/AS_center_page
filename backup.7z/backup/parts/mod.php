<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";


$s1_caid1 ="13";
$s1_caid2 ="113";

$query = "UPDATE step1_parts SET s1_caid  = '$s1_caid2' WHERE s1_caid  = '$s1_caid1'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>
