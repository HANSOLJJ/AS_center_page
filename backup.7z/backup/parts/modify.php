<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s1_uid, s1_caid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1, s1_cost_won FROM $db WHERE s1_uid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s1_uid = $row->s1_uid;
$my_s1_caid = $row->s1_caid;
$my_s1_erp = $row->s1_erp;
$my_s1_name = $row->s1_name;
$my_s1_cost_c_1 = $row->s1_cost_c_1;
$my_s1_cost_a_1 = $row->s1_cost_a_1;
$my_s1_cost_a_2 = $row->s1_cost_a_2;
$my_s1_cost_n_1 = $row->s1_cost_n_1;
$my_s1_cost_n_2 = $row->s1_cost_n_2;
$my_s1_cost_s_1 = $row->s1_cost_s_1;
$my_s1_cost_won = $row->s1_cost_won;

##### 제목과 본문에 대하여 테이블에 저장할 때(post.php) addslashes() 함수로 escape시킨 문자열을 원래대로 되돌려 놓는다.
$my_s1_name = stripslashes($my_s1_name);

##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s1_caid.value) {
      alert('카테고리를 입력하세요!');
      form.s1_caid.focus();
      return;
   }


   if(!form.s1_erp.value) {
      alert('ERP CODE를 입력하세요!');
      form.s1_erp.focus();
      return;
   }
	
	if(!form.s1_name.value) {
      alert('부품명을 입력하세요!');
      form.s1_name.focus();
      return;
   }

if(!form.s1_cost_c_1.value) {
      alert('A/S CENTER 공급가를 입력하세요!');
      form.s1_cost_c_1.focus();
      return;
   }

   if(form.s1_cost_c_1.value) {
         if(!IsNumber(form.s1_cost_c_1.name)) {
            alert("A/S CENTER 공급가는 숫자여야 합니다!");
            form.s1_cost_c_1.focus();
            return; 
         }
      }

if(!form.s1_cost_a_1.value) {
      alert('대리점 공급가(개별판매)를 입력하세요!');
      form.s1_cost_a_1.focus();
      return;
   }

   if(form.s1_cost_a_1.value) {
         if(!IsNumber(form.s1_cost_a_1.name)) {
            alert("대리점 공급가(개별판매)는 숫자여야 합니다!");
            form.s1_cost_a_1.focus();
            return; 
         }
      }

if(!form.s1_cost_a_2.value) {
      alert('대리점 공급가(수리시)를 입력하세요!');
      form.s1_cost_a_2.focus();
      return;
   }

   if(form.s1_cost_a_2.value) {
         if(!IsNumber(form.s1_cost_a_2.name)) {
            alert("대리점 공급가(수리시)는 숫자여야 합니다!");
            form.s1_cost_a_2.focus();
            return; 
         }
      }

if(!form.s1_cost_n_1.value) {
      alert('일반 판매(개별판매)를 입력하세요!');
      form.s1_cost_n_1.focus();
      return;
   }

   if(form.s1_cost_n_1.value) {
         if(!IsNumber(form.s1_cost_n_1.name)) {
            alert("일반 판매(개별판매)는 숫자여야 합니다!");
            form.s1_cost_n_1.focus();
            return; 
         }
      }

if(!form.s1_cost_n_2.value) {
      alert('일반 판매(수리시)를 입력하세요!');
      form.s1_cost_n_2.focus();
      return;
   }

   if(form.s1_cost_n_2.value) {
         if(!IsNumber(form.s1_cost_n_2.name)) {
            alert("일반 판매(수리시)는 숫자여야 합니다!");
            form.s1_cost_n_2.focus();
            return; 
         }
      }

if(!form.s1_cost_s_1.value) {
      alert('특별공급가를 입력하세요!');
      form.s1_cost_s_1.focus();
      return;
   }

   if(form.s1_cost_s_1.value) {
         if(!IsNumber(form.s1_cost_s_1.name)) {
            alert("특별공급가는 숫자여야 합니다!");
            form.s1_cost_s_1.focus();
            return; 
         }
      }

if(!form.s1_cost_won.value) {
      alert('원가를 입력하세요!');
      form.s1_cost_won.focus();
      return;
   }

   if(form.s1_cost_won.value) {
         if(!IsNumber(form.s1_cost_won.name)) {
            alert("원가는 숫자여야 합니다!");
            form.s1_cost_won.focus();
            return; 
         }
      }
           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>

<!------------------------- 카테고리  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>카테고리</b>
			</td>
			<td width='70%'>
			<select name="s1_caid"<?echo("$Form_style1");?>>
			<option value=''>카테고리를 선택해 주세요.</option>
<?php
     

##### 레코드 세트
$result= mysql_query("SELECT s5_caid, s5_category FROM $db5");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장   

$my_s5_caid = $row[s5_caid];
$my_s5_category = $row[s5_category];  
##### 

//변환1
if($my_s1_caid == $my_s5_caid){$selected_option = "selected";}else{$selected_option = "";}

echo("<option value='$my_s5_caid' $selected_option>$my_s5_category</option>");
}
?>

			</select>
			</td>
		</tr>
<!------------------------- ERP  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>ERP CODE</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_erp" size="64" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_s1_erp");?>'>
			</td>
		</tr>
<!------------------------- 이름  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>부품명</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_name" size="128" maxlength="255" <?echo("$Form_style1");?> value='<? echo("$my_s1_name");?>'>
			</td>
		</tr>
<!------------------------- 가격  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>A/S CENTER 공급가</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_cost_c_1" size="64" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_s1_cost_c_1");?>'>&nbsp;&nbsp; <font color='#FF0000'>가격은 숫자만 입력 가능합니다.</font>
			</td>
		</tr>
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>대리점 공급가(개별판매)</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_cost_a_1" size="64" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_s1_cost_a_1");?>'>&nbsp;&nbsp; <font color='#FF0000'>가격은 숫자만 입력 가능합니다.</font>
			</td>
		</tr>
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>대리점 공급가(수리시)</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_cost_a_2" size="64" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_s1_cost_a_2");?>'>&nbsp;&nbsp; <font color='#FF0000'>가격은 숫자만 입력 가능합니다.</font>
			</td>
		</tr>
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>일반 판매(개별판매)</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_cost_n_1" size="64" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_s1_cost_n_1");?>'>&nbsp;&nbsp; <font color='#FF0000'>가격은 숫자만 입력 가능합니다.</font>
			</td>
		</tr>
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>일반 판매(수리시)</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_cost_n_2" size="64" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_s1_cost_n_2");?>'>&nbsp;&nbsp; <font color='#FF0000'>가격은 숫자만 입력 가능합니다.</font>
			</td>
		</tr>
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>특별공급가</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_cost_s_1" size="64" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_s1_cost_s_1");?>'>&nbsp;&nbsp; <font color='#FF0000'>가격은 숫자만 입력 가능합니다.</font>
			</td>
		</tr>
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>원가</b>
			</td>
			<td width='70%'>
			<input type="text" name="s1_cost_won" size="64" maxlength="255" <?echo("$Form_style1");?>  value='<? echo("$my_s1_cost_won");?>'>&nbsp;&nbsp; <font color='#FF0000'>가격은 숫자만 입력 가능합니다.</font>
			</td>
		</tr>


</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>