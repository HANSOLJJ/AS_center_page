<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 신청한 아이디와 동일한 아이디가 존재하는지 확인한다.
$result = mysql_query("SELECT count(s11_com_name) FROM $db11 WHERE s11_com_name  = '$s11_com_name'");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

$rows = mysql_result($result,0,0);

if ($rows) {

echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=write2-1&s11_com_name=$s11_com_name'>");

}

mysql_free_result($result);

echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=write2-2&s11_com_name=$s11_com_name'>");

?>