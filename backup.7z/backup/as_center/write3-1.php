<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		① 업체명 확인</b>&nbsp;→&nbsp;
		② 업체 정보 등록 및 선택&nbsp;→&nbsp;
		<font color='red'><b>③ 입고정보 입력</font>
		</td>
	</tr>
</table>
<br>
<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id ='$center_id_s'");
$center_name = mysql_result($center_query,0,0);

//------------------업체 데이터 불러오기

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s11_meid, s11_com_name, s11_com_man, s11_sec FROM $db11 WHERE s11_meid = $s11_meid";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$row = mysql_fetch_row($result);

$my_s11_meid = $row[0];
$my_s11_com_name = $row[1];
$my_s11_com_man = $row[2];
$my_s11_sec = $row[3];
?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s13_dex_no.value) {
      alert('송장번호를 입력하세요!');
      form.s13_dex_no.focus();
      return;
   }

   if(!form.in_year.value) {
      alert('입고일을 입력하세요!');
      form.in_year.focus();
      return;
   }

   if(!form.in_month.value) {
      alert('입고일을 입력하세요!');
      form.in_month.focus();
      return;
   }

   if(!form.in_day.value) {
      alert('입고일을 입력하세요!');
      form.in_day.focus();
      return;
   }
           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name='form' method='POST' action='write3_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>' enctype='multipart/form-data'>
<INPUT type='hidden' name='center_id_s' value="<? echo"$center_id_s";?>">
<INPUT type='hidden' name='s13_meid' value="<? echo"$my_s11_meid";?>">
<INPUT type='hidden' name='s13_as_in_how' value="택배">
<!------------------------- 지점  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>AS 지점</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;<?echo("$center_name");?>
			</td>
		</tr>

<!------------------------- 업체  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>업체명</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;<?echo("$my_s11_com_name");?>&nbsp;&nbsp;[<?echo("$my_s11_sec");?>]
			</td>
		</tr>
<!------------------------- 업체  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>대표명</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;<?echo("$my_s11_com_man");?>
			</td>
		</tr>
<!------------------------- 카테고리  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>수탁방법</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<a href='<? echo"list.php?in_code=write3&number=$my_s11_meid";?>'>[내방]</a>&nbsp;&nbsp;			
			<b>[택배]</B>
			</td>
		</tr>
<!------------------------- 송장번호  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>송장번호</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s13_dex_no" size="64" maxlength="255" <?echo("$Form_style1");?>>			
			</td>
		</tr>
<!-------------------------입고일  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>입고일</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;
<?
$CAST_DATE = date("Y",time());	
$FIRST_DAY = $CAST_DATE -1;		// 시작값
$LAST_DAY = $CAST_DATE +1;			// 마지막값
   echo "<select name='in_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 년";      
   }
   echo "</select> &nbsp;";

   echo "<select name='in_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 월";      
   }
   echo "</select> &nbsp;";

   echo "<select name='in_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 일";
   }
   echo "</select>";
?>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>