<?
##### 주소 데이터베이스에서 사용자가 입력한 주소를 포함하는 레코드를 검색한다.
$query = "SELECT uid,zipcode,sido,gugun,dong,bunji FROM zipcode WHERE dong LIKE '%$addr%' ORDER BY uid";
$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}   
$rows = mysql_num_rows($result);

##### 검색결과가 존재하면 리스트박스 형태로 출력한다.
if ($rows) {
?>

<form name="zipsearch" method="post" action="<?echo("$PHP_SELF")?>?what=<?echo($what)?>&step=<?echo("$next_step")?>">
<table width="532" border="0" cellpadding="1" cellspacing="0" align="center">
<tr>
   <td colspan="2" align="right">STEP [<b><?echo("$step")?></b> / <b>4</b>]</td>
</tr>   
<tr>
   <td bgColor="brown">
   <table width="530" border="0" cellpadding="5" cellspacing="1" align="center">
   <tr>
      <td bgColor="#BAF2BA" colspan="2" align="center">총 <b><?echo("$rows")?></b>개의 주소가 검색되었습니다.</td>
   </tr>
   <tr>
      <td bgColor="lightyellow" colspan="2" align="center">      
      <select name="searched_addr_uid">
<?
   while($row = mysql_fetch_object($result)) {
      $my_uid = $row->uid;
      $my_zipcode = $row->zipcode;
      $my_sido = $row->sido;
      $my_gugun = $row->gugun;
      $my_dong = $row->dong;
      $my_bunji = $row->bunji;
      
      $address = "[$my_zipcode] $my_sido $my_gugun $my_dong $my_bunji";
      echo "<option value='" . $row->uid . "'>" . $address;
   }
?>      
      </select>
      </td>      
   </tr>
   <tr>
      <td bgColor="lightyellow" colspan="2" align="center">
      위의 주소중에서 자신의 주소를 선택한 후 다음버튼을 클릭하여 주십시오.<p>
      <input type="submit" value="다음 단계로 이동">
      </td>
   </tr>
   </table>
   </td>
</tr>
</table>
</form>

<?
##### 검색결과가 하나도 존재하지 않으면 재입력을 받는다.
} else {
?>

<form name="zipsearch" method="post" action="<?echo("$PHP_SELF")?>?what=<?echo($what)?>&step=<?echo("$step")?>">
<table width="532" border="0" cellpadding="1" cellspacing="0" align="center">
<tr>
   <td colspan="2" align="right">STEP [<b><?echo("$step")?></b> / <b>4</b>]</td>
</tr>   
<tr>
   <td bgColor="brown">
   <table width="530" border="0" cellpadding="5" cellspacing="1" align="center">
   <tr>
      <td bgColor="#BAF2BA" colspan="2" align="center"><b>검색된 주소가 없습니다.</b></td>
   </tr>
   <tr>
      <td bgColor="lightyellow" colspan="2" align="center">입력하신 주소와 일치하는 정보가 존재하지 않습니다.<br> 다시한번 확인하시고 아래의 항목에 입력하여 주시기 바랍니다.</td>
   </tr>   
   <tr>
      <td bgColor="#BAF2BA" align="center"><input type="text" name="addr" size="15"></td>
      <td bgColor="#BAF2BA" align="center"><font size=2><input type="submit" value="주소 자동검색"></font></td>
   </tr>
   </table>
   </td>
</tr>
</table>
</form>

<?   
}
?>