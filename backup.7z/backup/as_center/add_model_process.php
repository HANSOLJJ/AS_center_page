<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$s14_stat ='입고';

$query = "INSERT INTO $db14 (s14_asid, s14_model, s14_poor, s14_stat) VALUES ('$s14_asid', '$s14_model', '$s14_poor', '$s14_stat')";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=write4&number=$number'>");
} 

?>
