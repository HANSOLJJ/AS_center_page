<script language="javascript">
<!--
function sendit() {

   if(!form.s14_as_nae.value) {
      alert('AS내역을 입력하세요!');
      form.s14_as_nae.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name='form' method='POST' action='as_nae_write_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>' enctype='multipart/form-data'>
<INPUT type='hidden' name='s14_aiid' value="<?echo"$s14_aiid";?>">
<!-------------------------내역  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			AS 내역
			</td>
			<td width='70%'>
			<select name="s14_as_nae"<?echo("$Form_style1");?>>
			<option value=''>AS 내역을 선택해 주세요.</option>
<?php
     
##### 레코드 세트
$result= mysql_query("SELECT s19_asrid, s19_result FROM $db19");

if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장   

$my_s19_asrid = $row[s19_asrid];
$my_s19_result = $row[s19_result];

  
##### 

echo("<option value='$my_s19_asrid'>$my_s19_result</option>");

}
?>

			</select>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>