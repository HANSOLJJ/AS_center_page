<?
##### 
$total_cost= "19870203";
$se_len=strlen($total_cost); 



echo"$se_len<br>";

for($slash=0;$slash<$se_len;$slash++){ 
    $num=substr($total_cost,$slash,1); 
	echo("$num"); 

}
?>