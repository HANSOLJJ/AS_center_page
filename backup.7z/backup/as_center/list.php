<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>


<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<? echo"$title_b_11"; ?>

<?

switch ($in_code) {

// 일반페이지


case ("") : 	include"list_view.php"; Break;
case ("list_view") : 	include"list_view.php"; Break;
case ("write1") : 	include"write1.php"; Break;
case ("write2-1") : 	include"write2-1.php"; Break;
case ("write2-2") : 	include"write2-2.php"; Break;
case ("write3") : 	include"write3.php"; Break;
case ("write3-1") : 	include"write3-1.php"; Break;
case ("write4") : 	include"write4.php"; Break;
case ("cure_list") : 	include"cure_list.php"; Break;
case ("cure_write") :

print"<table width='100%' align='center' cellspacing='0' cellpadding='0'>
			<tr>
				<td align='center' width='50%' valign='top'>";
				include"cure_parts_list.php";
	print"</td>
	<td width='50%' valign='top' align='center'>";
	include"cure_view.php";
	print"</td>
	</tr>
	</table>"; 
	Break;



case ("write") : 	include"write.php"; Break;
case ("modify") : 	include"modify.php"; Break;
case ("del") : 	include"del.php"; Break;
case ("view") : 	include"view.php"; Break;
case ("as_nae_write") : 	include"as_nae_write.php"; Break;
}

?>
