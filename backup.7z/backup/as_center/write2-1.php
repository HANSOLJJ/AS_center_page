<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		① 업체명 확인</b>&nbsp;→&nbsp;
		<font color='red'><b>② 업체 정보 등록 및 선택</font>&nbsp;→&nbsp;
		③ 제품정보 입력
		</td>
	</tr>
</table>
<br>
<?
##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
$query = "SELECT count(*) FROM $db11 WHERE s11_com_name LIKE '%$s11_com_name%'";  
$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
mysql_free_result($result);


?>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td width='5%' height='50' background="<?echo "$border_bg1";?>">
		<p align='center'><b>No</b></p>
		</td>
		<td  width='25%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>상호</b></p>
		</td>
		<td  width='25%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>대표자</b></p>
		</td>
		<td width='25%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>연락처</b></p>
		</td>
		<td width='20%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>선택</b></p>
		</td>
	</tr>

<?
#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$query = "SELECT s11_meid, s11_com_name, s11_phone1, s11_phone2, s11_phone3, s11_com_man FROM $db11 WHERE s11_com_name LIKE '%$s11_com_name%'";

$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다. 
   $article_num = 1;
   $my_s11_meid = $row[s11_meid];
   $my_s11_com_name = $row[s11_com_name];
   $my_s11_phone1 = $row[s11_phone1];
   $my_s11_phone2 = $row[s11_phone2];
   $my_s11_phone3 = $row[s11_phone3];
   $my_s11_com_man = $row[s11_com_man];

$my_phone_num = $my_s11_phone1."-".$my_s11_phone2."-".$my_s11_phone3;


if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}
//--------------------------------------------------------------------
echo("<tr>");


##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg>$my_s11_com_name</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg>$my_s11_com_man</td>");
##### 

echo("	<td align='center' valign='middle' $list_style1 $td_bg>$my_phone_num</td>");

##### 

echo("	<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=write3&number=$my_s11_meid'><img src='../$icon_dir/button_blue_select.gif' border='0'></a></td>");

$article_num = $article_num  + 1;
$article_num--;
}
echo("</table>");
?>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>