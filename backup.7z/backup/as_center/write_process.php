<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";


$center_id_s = $HTTP_SESSION_VARS[member_center_id];

############# 공란

//$month_long = strlen($in_month); 

//if($month_long =="1"){$in_month = "0"."$in_month";}else{$in_month=$in_month;}

//$day_long = strlen($in_day); 

//if($day_long =="1"){$in_day = "0"."$in_day";}else{$in_day=$in_day;}

##########

$in_date = mktime(0,0,1,$in_month,$in_day,$in_year);


echo"$in_year";
?>