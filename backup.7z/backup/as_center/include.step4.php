<?
##### 검색된 주소의 우편번호를 앞자리와 뒷자리로 나누어 배열($addr_code)에 저장한다.
$addr_code = explode("-",$zipcode);
?>

<script language="javascript">
function selectIt(form,what) {
   var form_object = eval("opener.document.form");
   if(what == 1) {
      form_object.s11_com_zip1.value = '<?echo("$addr_code[0]")?>';
      form_object.s11_com_zip2.value = '<?echo("$addr_code[1]")?>';
      form_object.s11_oaddr.value = '<?echo("$address")?>';
   }
   if(what == 2) {
      form_object.ozipcode1.value = '<?echo("$addr_code[0]")?>';
      form_object.ozipcode2.value = '<?echo("$addr_code[1]")?>';   
      form_object.oaddr.value = '<?echo("$address")?>';
   }
   self.close();
}
</script>

<form name="zipsearch" method="post" action="<?echo("$PHP_SELF")?>?what=<?echo($what)?>&step=<?echo("$next_step")?>">
<table width="532" border="0" cellpadding="1" cellspacing="0" align="center">
<tr>
   <td colspan="2" align="right">STEP [<b><?echo("$step")?></b> / <b>4</b>]</td>
</tr>   
<tr>
   <td bgColor="brown">
   <table width="530" border="0" cellpadding="5" cellspacing="1" align="center">
   <tr>
      <td width="100" bgColor="#BAF2BA" align="center">우편번호</td>
      <td width="430" bgColor="#BAF2BA" align="center">주소</td>
   </tr>
   <tr>
      <td bgColor="#BAF2BA" align="center"><?echo("$zipcode")?></td>
      <td bgColor="#BAF2BA" align="center"><?echo("$address")?></td>
   </tr>   
   <tr>
      <td bgColor="lightyellow" colspan="2" align="center">            
      <input type="button" value="위와같은 주소와 우편번호를 입력합니다." onClick="selectIt(this.form,<?echo("$what")?>)">
      </td>
   </tr>
   </table>
   </td>
</tr>
</table>
</form>