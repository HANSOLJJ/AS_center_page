<script language="javascript">
var old_menu = '';

function menuclick(list)
{
  if( old_menu != list ) {
    if( old_menu !='' ) {
      old_menu.style.display = 'none';
    }
    list.style.display = 'block';
    old_menu = list;


  } else {
    list.style.display = 'none';
    old_menu = '';

  }
}
</script>

<?
if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 1000;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
$query = "SELECT count(*) FROM $db14 WHERE s14_asid LIKE '$number'";  

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='50' align='left'>
		<b>[ 해당 조건에 검색된 등록된 AS 정보 : <?echo"$total_record ";?> 건 ]</b>
		</td>
	</tr>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td  width='15%' height='40' background="<?echo "$border_bg1";?>">
		<p align='center'><b>모델명</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>시리얼</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>불량증상</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>AS 진행사항</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>AS 내역</b></p>
		</td>
		<td  width='15%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>부품내역</b></p>
		</td>
	</tr>

<?

$time_limit = 60*60*24*$notify_new_article; 

#### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$query = "SELECT s14_aiid, s14_asid, s14_model, s14_poor FROM $db14 WHERE s14_asid = '$number'";

$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

if($total_record=='0'){print"<tr><td height='200' colspan='20'><table width='600' align='center' cellspacing='0' cellpadding='0'  border='0' ><tr><td height='160'><p align='center'>등록된 데이터가 없습니다.</p></td></tr></table></td></tr>";}


##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s14_aiid = $row[s14_aiid];
$my_s14_asid = $row[s14_asid];
$my_s14_model = $row[s14_model];
$my_s14_poor = $row[s14_poor];

//------------------데이터 불러오기

$small_query1 = "SELECT s15_model_name, s15_model_sn FROM $db15 WHERE s15_amid = '$my_s14_model'";
$small_result1 = mysql_query($small_query1);
if(!$small_result1) {
   error("QUERY_ERROR");
   exit;
}

$small_row1 = mysql_fetch_row($small_result1);

$my_s15_model_name = $small_row1[0];
$my_s15_model_sn = $small_row1[1];

//------------------데이터 불러오기

$small_query2 = "SELECT s16_poor FROM $db16 WHERE s16_apid = '$my_s14_poor'";
$small_result2 = mysql_query($small_query2);
if(!$small_result2) {
   error("QUERY_ERROR");
   exit;
}

$small_row2 = mysql_fetch_row($small_result2);

$my_s16_poor = $small_row2[0];


if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'"; $cell_color='#fbfbfb';}else{$td_bg="bgcolor='#FFFFFF'"; $cell_color='#FFFFFF';}
//--------------------------------------------------------------------
echo("<tr>");


##### [컬럼 1 : 게시물의 번호를 출력한다.]
echo("<td height='35' align='center' valign='middle' $list_style1 $td_bg onclick='menuclick(list$article_num);' onmouseover=this.style.backgroundColor='#acd373' onmouseout=this.style.backgroundColor='$cell_color'>$my_s15_model_name</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg onclick='menuclick(list$article_num);' onmouseover=this.style.backgroundColor='#acd373' onmouseout=this.style.backgroundColor='$cell_color'>$my_s15_model_sn</td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg onclick='menuclick(list$article_num);' onmouseover=this.style.backgroundColor='#acd373' onmouseout=this.style.backgroundColor='$cell_color'><font color='red'><b>$my_s16_poor</b></font></td>");

echo("<td align='center' valign='middle' $list_style1 $td_bg onclick='menuclick(list$article_num);' onmouseover=this.style.backgroundColor='#acd373' onmouseout=this.style.backgroundColor='$cell_color'>&nbsp;</td>");

##### 

echo("<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=modify&number=$my_s13_asid'><img src='../$icon_dir/button_blue_modify.gif' border='0'></a></td>");

##### 

echo("<td align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=cure_write&number=$my_s13_asid'><img src='../$icon_dir/button_blue_add_cure.gif' border='0'></a></td>");


$article_num--;
}
echo("</table>");
?>

<table  width='95%' height='50' cellpadding='0' cellspacing='0' border='0' align='center'>
    <tr>
		<td align='right'>
<?
if($HTTP_SESSION_VARS["member_id"] !="" AND $HTTP_SESSION_VARS["member_sid"] !="" AND $HTTP_SESSION_VARS["member_level"] == "0"){print"<p align='right'><a href='list.php?in_code=write1&page=$page&db=$db'><img src='../$icon_dir/button_blue_submit.gif' border='0' align='absmiddle'></a>";}
?>
		</td>
	</tr>
</table>

