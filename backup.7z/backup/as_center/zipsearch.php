<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>우편번호 검색</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>

<body>

<?
##### $step의 값이 정해져 있지 않으면 1로 설정한다.
if(!$step) {
   $step = 1;
}

if($step == 1) {
   $next_step = $step + 1;
?>

<form name="zipsearch" method="post" action="<?echo("$PHP_SELF")?>?what=<?echo($what)?>&step=<?echo("$next_step")?>">
<table width="532" border="0" cellpadding="1" cellspacing="0" align="center">
<tr>
   <td colspan="2" align="right">STEP [<b><?echo("$step")?></b> / <b>4</b>]</td>
</tr>   
<tr>
   <td bgColor="brown">
   <table width="530" border="0" cellpadding="5" cellspacing="1" align="center">
   <tr>
      <td bgColor="#BAF2BA" align="center"><input type="text" name="addr" size="15"></td>
      <td bgColor="#BAF2BA" align="center"><font size=2><input type="submit" value="주소 자동검색"></font></td>
   </tr>
   <tr>
      <td bgColor="lightyellow" colspan="2">자신의 주소중에서 [시/도]와 [구/군]을 제외한 [읍/면/동]을 입력하십시오!<p>
      예1) 주소가 '서울특별시 종로구 명륜동' 인 경우 <font color="red">명륜동</font> 혹은 <font color="red">명륜</font>을 입력하시면 됩니다.<br>
      예2) 주소가 '경기도 연천군 연천읍' 인 경우 <font color="red">연천읍</font>을 입력하시면 됩니다.<br>
      예3) 주소가 '경상북도 예천군 개포면'인 경우 <font color="red">개포면</font>을 입력하시면 됩니다.
      </td>
   </tr>
   </table>
   </td>
</tr>
</table>
</form>

<?
} 
if ($step == 2) {
   $next_step = $step + 1;
   include "include.step2.php";   
} 
if ($step == 3) {
   $next_step = $step + 1;   
   include "include.step3.php";
} 
if ($step == 4) {   
   include "include.step4.php";
} 
?>


</body>
</html>