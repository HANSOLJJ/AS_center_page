<table  width='100%' cellpadding='0' cellspacing='0' border='0' align='center'>

<?

##### 
$instant_query = "SELECT s18_accid, s18_aiid, s18_uid, s18_quantity FROM $db18 WHERE s18_aiid = '$my_s14_aiid'";
$instant_result = mysql_query($instant_query);
if(!$instant_result) {
   error("QUERY_ERROR");
   exit;
}
$instant_rows = mysql_num_rows($instant_result);
if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   $my_s18_accid = $instant_reply->s18_accid;
	   $my_s18_aiid = $instant_reply->s18_aiid;
	   $my_s18_uid = $instant_reply->s18_uid;
	   $my_s18_quantity = $instant_reply->s18_quantity;

//------------------데이터 불러오기

$small_query1 = "SELECT s1_uid, s1_caid, s1_erp, s1_name FROM $db1 WHERE s1_uid = '$my_s18_uid'";
$small_result1 = mysql_query($small_query1);
if(!$small_result1) {
   error("QUERY_ERROR");
   exit;
}

$small_row1 = mysql_fetch_row($small_result1);

$my_s1_uid = $small_row1[0];
$my_s1_caid = $small_row1[1];
$my_s1_erp = $small_row1[2];
$my_s1_name = $small_row1[3];


//------------------데이터 불러오기


print "	
<tr >
<td align='left'>
&nbsp;-&nbsp;$my_s1_name&nbsp;&nbsp;[$my_s1_erp]
</td>
<td align='right'>
<font color='red'><b>$my_s18_quantity&nbsp;개</b>&nbsp;</font><br>
 </td>
 </tr>";
   }
}
?>
</table>