<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 게시물의 암호와 사용자가 입력한 암호가 같으면 게시물을 수정한다. 
  $query = "UPDATE $db18 SET s18_quantity  = '$s18_quantity' WHERE s18_accid  = '$s18_accid'";
  $result = mysql_query($query);
  if (!$result) {
	 error("QUERY_ERROR");
	 exit;
  }
    
 ##### 리스트 출력화면으로 이동한다.
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=cure_write&number=$number&s18_aiid=$s18_aiid'>");   
  
  
  ?>
