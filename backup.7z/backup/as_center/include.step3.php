<?
##### 주소 데이터베이스에서 사용자가 선택한 주소의 각 필드값을 가져온다.
$query = "SELECT uid,zipcode,sido,gugun,dong,bunji FROM zipcode WHERE uid = $searched_addr_uid";
$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_zipcode = $row->zipcode;
$my_sido = $row->sido;
$my_gugun = $row->gugun;
$my_dong = $row->dong;
$my_bunji = $row->bunji;

$address = "$my_sido $my_gugun $my_dong";
$address = rtrim($address);
?>

<form name="zipsearch" method="post" action="<?echo("$PHP_SELF")?>?what=<?echo($what)?>&step=<?echo("$next_step")?>">
<table width="532" border="0" cellpadding="1" cellspacing="0" align="center">
<tr>
   <td colspan="2" align="right">STEP [<b><?echo("$step")?></b> / <b>4</b>]</td>
</tr>   
<tr>
   <td bgColor="brown">
   <table width="530" border="0" cellpadding="5" cellspacing="1" align="center">
   <tr>
      <td width="100" bgColor="#BAF2BA" align="center">우편번호</td>
      <td width="430" bgColor="#BAF2BA" align="center">주소</td>
   </tr>
   <tr>
      <td bgColor="#BAF2BA" align="center"><?echo("$my_zipcode")?></td>
      <td bgColor="#BAF2BA" align="center"><?echo("$address")?></td>
   </tr>   
   <tr>
      <td bgColor="lightyellow" colspan="2" align="center">      
      주소의 나머지 부분을 입력하여 주십시오
      </td>      
   </tr>
   <tr>
      <td bgColor="lightyellow" colspan="2" align="center">      
      <input type="text" name="address" value="<?echo("$address")?>" size="45">
      <input type="hidden" name="zipcode" value="<?echo("$my_zipcode")?>">      
      <input type="submit" value="다음 단계로 이동">
      </td>
   </tr>
   </table>
   </td>
</tr>
</table>
</form>