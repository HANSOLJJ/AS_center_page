<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_asid = $row->s13_asid;
$my_s13_as_center = $row->s13_as_center;
$my_s13_as_in_date = $row->s13_as_in_date;
$my_s13_as_in_how = $row->s13_as_in_how;

$my_s13_as_in_date =date("Y/m/d",$my_s13_as_in_date);

##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p>&nbsp;</p>
		<p align="center"><b>[<? echo("$my_s13_as_in_date");?>]</p>
		<p></p>
		<p align='center'><font color='red'><b>이글을 삭제하시려면 하단의 삭제버튼을 눌러주세요.<br>삭제된 글은 복원할 수 없습니다.</font></p>
		<p>&nbsp;</p>
		</td>
	</td>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center' >
	<tr>
		<td>
		<p align='right'><a href='del_process.php?number=<?echo("$number");?>&db=<?echo("$db");?>'>
		<img src='../<?echo("$icon_dir");?>/button_blue_del.gif' align='absmiddle' border='0'></a>&nbsp;
		<a href='<? echo("list.php?in_code=list_view");?>'>
		<img src='../<?echo("$icon_dir");?>/button_blue_cancel.gif' align='absmiddle' border='0'>
		</a>
		</p>
		</td>
	</tr>
</table>
