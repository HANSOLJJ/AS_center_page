<?

$center_id_s = $HTTP_SESSION_VARS[member_center_id];

if(!$page) {
   $page = 1;
}

##### 한 페이지당 출력할 게시물의 수
$num_per_page = 1500;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;

##### 현재 자료실 테이블에 등록되어 있는 총 레코드의 개수를 구한다. 
$query = "SELECT count(*) FROM $db1";

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);
mysql_free_result($result);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>
<p align='center'><b>자재 리스트</b></p>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE' class="body">
	<tr>
		<td  height='50' background="<?echo "$border_bg1";?>">
			<p align="center"><b>번호</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>카테고리</b></p>
		</td>
		<td  background="<?echo "$border_bg1";?>">
			<p align="center"><b>ERP</b></p>
		</td>
		<td background="<?echo "$border_bg1";?>">
			<p align="center"><b>자재명</b></p>
		</td>
		<td background="<?echo "$border_bg1";?>">
			<p align="center"><b>담기</b></p>
		</td>
	</tr>

<?
##### 
$time_limit = 60*60*24*$notify_new_article; 

$query = "SELECT s1_uid, s1_caid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1 FROM $db1 ORDER BY s1_caid ASC LIMIT $first, $num_per_page";

$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
  $my_s1_uid = $row[s1_uid];
   $my_s1_caid = $row[s1_caid];
   $my_s1_erp = $row[s1_erp];
   $my_s1_name = $row[s1_name];
   $my_s1_cost_c_1 = $row[s1_cost_c_1];
   $my_s1_cost_a_1 = $row[s1_cost_a_1];
   $my_s1_cost_a_2 = $row[s1_cost_a_2];
   $my_s1_cost_n_1 = $row[s1_cost_n_1];
   $my_s1_cost_n_2 = $row[s1_cost_n_2];
   $my_s1_cost_s_1 = $row[s1_cost_s_1];
 

if($my_s1_caid % 9 =="1"){$my_color='#fdc689';}else
if($my_s1_caid % 9 =="2"){$my_color='#fff200';}else
if($my_s1_caid % 9 =="3"){$my_color='#c69c6d';}else
if($my_s1_caid % 9 =="4"){$my_color='#7accc8';}else
if($my_s1_caid % 9 =="5"){$my_color='#7cc57';}else
if($my_s1_caid % 9 =="6"){$my_color='#cccccc';}else
if($my_s1_caid % 9 =="7"){$my_color='#fff200';}else
if($my_s1_caid % 9 =="8"){$my_color='#f5989d';}else
if($my_s1_caid % 9 =="9"){$my_color='#f5989d';}else
if($my_s1_caid % 10 =="10"){$my_color='#fdc689';}

//------------------카테고리명 부르기
$category_query = mysql_query("Select s5_category FROM $db5 WHERE s5_caid ='$my_s1_caid'");
$my_s1_caid = mysql_result($category_query,0,0);

echo("<tr>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td height='35' align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$article_num.</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$my_s1_caid</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$my_s1_erp</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

echo("<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p>$my_s1_name</p></td>");

##### [컬럼 3 : 글쓴이의 아이디를 출력한다.]

$cart_query = mysql_query("Select count(s18_accid) FROM $db18 WHERE s18_aiid ='$s18_aiid' AND s18_uid = '$my_s1_uid' AND s18_end ='N'"); 

$cart_nums = mysql_result($cart_query,0,0);

if($cart_nums=='0') {
echo"<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p align='center'><a href='into_cart.php?number=$my_s1_uid&s18_aiid=$s18_aiid'><img src='../$icon_dir/cart_into.gif' border='0'></a></p></td>";} else {
echo"<td align='center' style='border-bottom-width:1px; border-bottom-color:rgb(204,204,204); border-bottom-style:solid;' bgcolor='$my_color'><p align='center'>-</p></td>";
}




echo("</tr>");

$article_num--;
}
echo("</table>");
?>

<p>&nbsp; </p><p> &nbsp;</p>