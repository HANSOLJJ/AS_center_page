<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		① 업체명 확인</b>&nbsp;→&nbsp;
		② 업체 정보 등록 및 선택&nbsp;→&nbsp;
		③ 입고정보 입력&nbsp;→&nbsp;
		<font color='red'><b>④ 제품 정보 입력</font>
		</td>
	</tr>
</table>
<br>
<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id ='$center_id_s'");
$center_name = mysql_result($center_query,0,0);

//------------------업체 데이터 불러오기

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_asid, s13_meid FROM $db13 WHERE s13_as_in_no = '$number'";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$row = mysql_fetch_row($result);

$my_s13_asid = $row[0];
$my_s13_meid = $row[1];

##### 선택한 게시물의 입력값을 뽑아낸다.
$query2 = "SELECT s11_com_name, s11_sec FROM $db11 WHERE s11_meid = '$my_s13_meid'";
$result2 = mysql_query($query2);
if(!$result2) {
   error("QUERY_ERROR");
   exit;
}

$row2 = mysql_fetch_row($result2);

$my_s11_com_name = $row2[0];
$my_s11_sec = $row2[1];
?>



<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<!------------------------- 지점  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>AS 지점</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;<?echo("$center_name");?>
			</td>
		</tr>

<!------------------------- 업체  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>업체명</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;<?echo("$my_s11_com_name");?>&nbsp;&nbsp;[<?echo("$my_s11_sec");?>]
			</td>
		</tr>

</table>

<? include"add_model.php"; ?>


<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
			</td>
		</tr>

</table>