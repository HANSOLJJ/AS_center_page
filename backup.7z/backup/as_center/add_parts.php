cart1>cart2

<br>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<?
##### 현재 조회중인 글에 대하여 작성된 답변글이 있으면 그 내용을 가져온다.
$instant_query = "SELECT s14_aiid, s14_asid, s14_model, s14_poor  FROM $db14 WHERE s14_asid = '$my_s13_asid'";
$instant_result = mysql_query($instant_query);
if(!$instant_result) {
   error("QUERY_ERROR");
   exit;
}
$instant_rows = mysql_num_rows($instant_result);
if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   $my_s14_aiid = $instant_reply->s14_aiid;
	   $my_s14_asid = $instant_reply->s14_asid;
	   $my_s14_model = $instant_reply->s14_model;
	   $my_s14_poor = $instant_reply->s14_poor;

//------------------데이터 불러오기

$small_query1 = "SELECT s15_model_name, s15_model_sn FROM $db15 WHERE s15_amid = '$my_s14_model'";
$small_result1 = mysql_query($small_query1);
if(!$small_result1) {
   error("QUERY_ERROR");
   exit;
}

$small_row1 = mysql_fetch_row($small_result1);

$my_s15_model_name = $small_row1[0];
$my_s15_model_sn = $small_row1[1];

//------------------데이터 불러오기

$small_query2 = "SELECT s16_poor FROM $db16 WHERE s16_apid = '$my_s14_poor'";
$small_result2 = mysql_query($small_query2);
if(!$small_result2) {
   error("QUERY_ERROR");
   exit;
}

$small_row2 = mysql_fetch_row($small_result2);

$my_s16_poor = $small_row2[0];

	   print "
			<tr>
				<td width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>제품</b>
			</td>

		   <td width='70%'>
		   &nbsp;&nbsp; $my_s15_model_name&nbsp;&nbsp;[$my_s15_model_sn]&nbsp;&nbsp;<font color='red'><b>$my_s16_poor</b></font>&nbsp;&nbsp;<a href='add_model_del_process.php?s14_aiid=$my_s14_aiid&number=$number'><img src='../$icon_dir/button_blue_del.gif' border='0' align='absmiddle'></a></td>
		 </td></tr>";
   }
}
?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s14_model.value) {
      alert('제품을 선택하세요!');
      form.s14_model.focus();
      return;
   }

   if(!form.s14_poor.value) {
      alert('불량 증상을 선택하세요!');
      form.s14_poor.focus();
      return;
   }

          
   form.submit();
}

//-->
</script>


<form name='form' method='POST' action='add_model_process.php?number=<? echo"$number";?>&s14_asid=<? echo"$my_s13_asid";?>' enctype='multipart/form-data'>
<!------------------------- 제품1  --------------------------->
		<tr>
			<td  height='40' align='center' bgcolor='#fbfbfb'>
			<b>제품</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;
			<select name="s14_model">
			<option value=''>모델명을 선택해 주세요.</option>

<?
##### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$result3= mysql_query("SELECT s15_amid, s15_model_name, s15_model_sn FROM $db15");

if (!$result3) {
   error("QUERY_ERROR");
   exit;
}

while($row3 = mysql_fetch_array($result3,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장한다.   

$my_s15_amid = $row3[s15_amid];
$my_s15_model_name = $row3[s15_model_name];
$my_s15_model_sn = $row3[s15_model_sn];

$my_model = $my_s15_model_name.'['.$my_s15_model_sn.']';
##### 

echo("<option value='$my_s15_amid'>$my_model</option>");

}
?>
							
			</select>
			&nbsp;&nbsp;
<select name="s14_poor">
			<option value=''>불량증상을 선택해 주세요.</option>

<?
##### 현재 페이지에 출력할 결과레코드 세트를 얻는다.
$result4= mysql_query("SELECT s16_apid, s16_poor FROM $db16");

if (!$result4) {
   error("QUERY_ERROR");
   exit;
}

while($row4 = mysql_fetch_array($result4,MYSQL_ASSOC)) {

##### 각 게시물 레코드의 필드값을 변수에 저장한다.   

$my_s16_apid = $row4[s16_apid];
$my_s16_poor = $row4[s16_poor];

##### 

echo("<option value='$my_s16_apid'>$my_s16_poor</option>");

}
?>
							
			</select>
			&nbsp;&nbsp;
			<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/board_blue_as_ad.gif");?>' border='0' align='absmiddle'></a>
			</td>
		</tr>
</form>

