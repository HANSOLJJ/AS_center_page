<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";


$query = "UPDATE $db14 SET s14_as_nae  = '$s14_as_nae' WHERE s14_aiid  = '$s14_aiid'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");
} 

?>

