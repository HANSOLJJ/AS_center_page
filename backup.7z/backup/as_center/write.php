<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id ='$center_id_s'");
$center_name = mysql_result($center_query,0,0);
?>

<script language="javascript">
<!--
function sendit() {

  if(!form.s13_as_in_how.value) {
      alert('수탁방법을 입력하세요!');
      form.s13_as_in_how.focus();
      return;
   }

   if(!form.in_year.value) {
      alert('입고일을 입력하세요!');
      form.in_year.focus();
      return;
   }

   if(!form.in_month.value) {
      alert('입고일을 입력하세요!');
      form.in_month.focus();
      return;
   }

   if(!form.in_day.value) {
      alert('입고일을 입력하세요!');
      form.in_day.focus();
      return;
   }
           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='write_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>' enctype='multipart/form-data'>
<!------------------------- 지점  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>AS 지점</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;<?echo("$center_name");?>
			</td>
		</tr>


<!------------------------- 카테고리  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>수탁방법</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<select name="s13_as_in_how"<?echo("$Form_style1");?>>
			<option value=''>수탁방법을 선택해 주세요.</option>
			<option value='내방'>내방</option>
			<option value='택배'>택배</option>
			</select>
			</td>
		</tr>
<!-------------------------입고일  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>입고일</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;
<?
$CAST_DATE = date("Y",time());	
$FIRST_DAY = $CAST_DATE -1;		// 시작값
$LAST_DAY = $CAST_DATE +1;			// 마지막값
   echo "<select name='in_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 년";      
   }
   echo "</select> &nbsp;";

   echo "<select name='in_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 월";      
   }
   echo "</select> &nbsp;";

   echo "<select name='in_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 일";
   }
   echo "</select>";
?>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>