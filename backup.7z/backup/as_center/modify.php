<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id ='$center_id_s'");
$center_name = mysql_result($center_query,0,0);

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_asid = $row->s13_asid;
$my_s13_as_center = $row->s13_as_center;
$my_s13_as_in_date = $row->s13_as_in_date;
$my_s13_as_in_how = $row->s13_as_in_how;

$my_s13_as_in_date;

$in_year= date(Y,$my_s13_as_in_date);
$in_month= date(m,$my_s13_as_in_date);
$in_day= date(d,$my_s13_as_in_date);
##
if($my_s13_as_in_how == "내방"){$as_in_how1="selected";}else
if($my_s13_as_in_how == "택배"){$as_in_how2="selected";}

##### 검색문자열을 인코딩한다.
$encoded_key = urlencode($key);

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>

<script language="javascript">
<!--
function sendit() {

  if(!form.s13_as_in_how.value) {
      alert('수탁방법을 입력하세요!');
      form.s13_as_in_how.focus();
      return;
   }

   if(!form.in_year.value) {
      alert('입고일을 입력하세요!');
      form.in_year.focus();
      return;
   }

   if(!form.in_month.value) {
      alert('입고일을 입력하세요!');
      form.in_month.focus();
      return;
   }

   if(!form.in_day.value) {
      alert('입고일을 입력하세요!');
      form.in_day.focus();
      return;
   }
           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='modify_process.php?db=<? echo("$db"); ?>&page=<? echo("$page"); ?>&number=<? echo("$number"); ?>' enctype='multipart/form-data'>
<!------------------------- 지점  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>AS 지점</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;<?echo("$center_name");?>
			</td>
		</tr>
<!------------------------- 카테고리  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>수탁방법</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<select name="s13_as_in_how"<?echo("$Form_style1");?>>
			<option value=''>수탁방법을 선택해 주세요.</option>
			<option value='내방'<?echo"$as_in_how1";?>>내방</option>
			<option value='택배'<?echo"$as_in_how2";?>>택배</option>
			</select>
			</td>
		</tr>

<!-------------------------입고일  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>입고일</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;
<?
$CAST_DATE = date("Y",time());	
$FIRST_DAY = $CAST_DATE -1;		// 시작값
$LAST_DAY = $CAST_DATE +1;			// 마지막값
   echo "<select name='in_year'>";
   echo "<option value=''>년도";
   for($i = $FIRST_DAY; $i <= $LAST_DAY; $i++) {
      echo "<option value='" . $i . "'>" . $i . " 년";  
	  if($i == $in_year){echo "<option value='" . $i . "' selected>" . $i . " 년";      }else{echo "<option value='" . $i . "'>" . $i . " 년";}      
   }
   echo "</select> &nbsp;";

   echo "<select name='in_month'>";
   echo "<option value=''>월";
   for($i = 1; $i <= 12; $i++) {
if($i == $in_month){echo "<option value='" . $i . "' selected>" . $i . " 월";     }else{ echo "<option value='" . $i . "'>" . $i . " 월";}        
   }
   echo "</select> &nbsp;";

   echo "<select name='in_day'>";
   echo "<option value=''>일";
   for($i = 1; $i <= 31; $i++) {
if($i == $in_day){echo "<option value='" . $i . "' selected>" . $i . " 일";      }else{echo "<option value='" . $i . "'>" . $i . " 일";}
   }
   echo "</select>";
?>
			</td>
		</tr>

</table>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>