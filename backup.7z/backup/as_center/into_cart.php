<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s1_uid , s1_caid, s1_name FROM $db1 WHERE s1_uid = '$number'";

$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$row = mysql_fetch_row($result);

$my_s1_uid = $row[0];
$my_s1_caid = $row[1];
$my_s1_name = $row[2];



$id = $HTTP_SESSION_VARS["member_id"];
$member_center_id = $HTTP_SESSION_VARS["member_center_id"];

$signdate = time();

##### 테이블에 입력값을 등록한다.
$query = "INSERT INTO $db18 (s18_aiid,  s18_quantity,  s18_signdate, s18_end, s18_uid) VALUES ('$s18_aiid', '1', '$signdate', 'N', '$my_s1_uid')";
$result = mysql_query($query);

$query2 = "UPDATE $db14 SET s14_stat = '진행중' WHERE s14_aiid = '$s18_aiid'";
$result2 = mysql_query($query2);

if (!$result2) {      
   error("QUERY_ERROR");
   exit;

} else {

   ##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=cure_write&number=$number&s18_aiid=$s18_aiid'>");
} 

?>
