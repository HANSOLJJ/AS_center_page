<table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
	<tr>
		 <td width="10%"  height='30'><p align='center'><b>No.</b></p></td>
		<td width="20%"  height='30'><p align='center'><b>모델명</b></p></td>
		<td width="20%"  height='30'><p align='center'><b>A/S 처리내용</b></p></td>
		<td width="50%" height='15'><p align='center'><b>소모품신청</b></p></td>
</tr>

<?
$query_item_list = "SELECT s14_aiid, s14_asid, s14_model, s14_poor, s14_stat, s14_asrid, cost_name, cost_sn, as_start_view, as_end_result  FROM $db14 WHERE s14_asid = '$my_s13_asid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}
$no='0';
while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   



$my_s14_aiid = $row_item_list[s14_aiid];
$no++;
$my_s14_asid = $row_item_list[s14_asid];
$my_s14_model = $row_item_list[s14_model];
$my_s14_poor = $row_item_list[s14_poor];
$my_s14_stat = $row_item_list[s14_stat];
$my_s14_asrid = $row_item_list[s14_asrid];

//추가 코드 
$my_cost_name = $row_item_list[cost_name];
$my_cost_sn = $row_item_list[cost_sn];
$my_as_start_view = $row_item_list[as_start_view];
$my_as_end_result = $row_item_list[as_end_result];

echo("<td height='50' align='center' valign='middle'><b>$no</td>");
echo("<td height='50' align='center' valign='middle' ><b>$my_cost_name</b><br>($my_cost_sn)</td>");
echo("<td height='50' align='center' valign='middle' ><font color='red'><b>$my_as_end_result</b></font></td>");
echo("<td height='50' align='center' valign='middle'>");
include"test_s_part_list.php";
echo("</td></tr>");
}

$no++;
$no2 =$no+1;

?>
<tr>
	<td height='50' align='center' valign='middle'><b><?echo"$no";?></td>
	<td height='50' align='center' valign='middle' ><b>처리비용 총액</b></td>
	<td height='50' align='center' valign='middle' ><b>-</b></td>
	<td height='50' align='right' valign='middle' ><font color='red'><b><?include"add_sum_total_cost.php";?></b></font></td>
	</td>
</tr>
</table>