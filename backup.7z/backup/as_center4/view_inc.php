<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how, s13_as_in_no, s13_meid, s13_dex_no, s13_sms1, s13_sms2, s13_bank_check, s13_tax_code, s13_dex_send, s13_dex_send_name, s13_as_out_date FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_asid = $row->s13_asid;
$my_s13_as_center = $row->s13_as_center;
$my_s13_as_in_date = $row->s13_as_in_date;
$my_s13_as_in_how = $row->s13_as_in_how;

$my_s13_as_in_no = $row->s13_as_in_no;
$my_s13_meid = $row->s13_meid;
$my_s13_dex_no = $row->s13_dex_no;
$my_s13_sms1 = $row->s13_sms1;
$my_s13_sms2 = $row->s13_sms2;
$my_s13_bank_check = $row->s13_bank_check;
$my_s13_tax_code = $row->s13_tax_code;
$my_s13_dex_send = $row->s13_dex_send;

$my_s13_dex_send_name = $row->s13_dex_send_name;
$my_s13_as_out_date = $row->s13_as_out_date;


$my_s13_as_in_date =date("Y/m/d",$my_s13_as_in_date);

//------------------업체명

$instant_query = "Select s11_com_name, s11_sec, s11_oaddr, s11_phone1, s11_phone2, s11_phone3 FROM $db11 WHERE s11_meid  ='$my_s13_meid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $s11_com_name=$instant_reply->s11_com_name;
	   $s11_sec=$instant_reply->s11_sec;
	   $s11_oaddr=$instant_reply->s11_oaddr;
	   $s11_phone1=$instant_reply->s11_phone1;
	   $s11_phone2=$instant_reply->s11_phone2;
	   $s11_phone3=$instant_reply->s11_phone3;

	   $phone_num = $s11_phone1."-".$s11_phone2."-".$s11_phone3;
	
   }

}

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<table  width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
				<td  height='50' width='20%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>수탁방법</b></p>
				</td>
				<td  width='20%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>형태</b></p>
				</td>
				<td  width='30%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>주소</b></p>
				</td>
				<td  width='30%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>연락처</b></p>
				</td>
			</tr>
			<tr>
				<td height='50'>
				<p align='center'><? echo"$my_s13_as_in_how";?></p>
				</td>
				<td>
				<p align='center'><? echo"$s11_sec";?></p>
				</td>
				<td>
				<p align='center'><? echo"$s11_oaddr";?></p>
				</td>
				<td>
				<p align='center'><? echo"$phone_num";?></p>
				</td>
			</tr>
			<tr>
				<td colspan='20' colspan='10'>
				<? include"view_inc_parts.php";?>
				</td>
			</tr>
		</table>

