<?
$title = "speedmotors";
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=".$title.".xls");
//$title 변수명으로 저장됩니다.
header("Content-Description:PHP4 Generated Data");


### DB 연결
$mysql_host = 'localhost';     // 호스트명 
$mysql_user = 'mic4u41';     // 사용자 계정 
$mysql_pwd  = 'digidigi';      // 비밀번호 
$mysql_db   = 'mic4u41';       // DB(데이터베이스)명) 
$connect = @mysql_connect($mysql_host, $mysql_user, $mysql_pwd) or die("서버 접속에 실패 했습니다. 계정 또는 패스워드를 확인하세요.");
@mysql_select_db($mysql_db, $connect) or die("DB 연결에 실패 했습니다. 데이터베이스명을 확인하세요.");
###


?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=ks_c_5601-1987">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 9">


</head>

<body link=blue vlink=purple>

<table x:str border=0 cellpadding=0 cellspacing=0 width=480 style='border-collapse:
 collapse;table-layout:fixed;width:360pt'>
 <col width=80 span=6 style='width:60pt'>
 <tr height=18 style='height:13.5pt'>
  <td height=18 width=80 style='height:13.5pt;width:60pt'>이름</td>
  <td width=80 style='width:60pt'>나이</td>
  <td width=80 style='width:60pt'>성별</td>
  <td width=80 style='width:60pt'>전화</td>
  <td width=80 style='width:60pt'>휴대폰</td>
  <td width=80 style='width:60pt'>주소</td>
 </tr>
<?
$result=mysql_query("select * from step13_as");
while($row=mysql_fetch_array($result))
{

// 이부분에 데이터를 출력시킨다.

}
?>

 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=80 style='width:60pt'></td>
  <td width=80 style='width:60pt'></td>
  <td width=80 style='width:60pt'></td>
  <td width=80 style='width:60pt'></td>
  <td width=80 style='width:60pt'></td>
  <td width=80 style='width:60pt'></td>
 </tr>
 <![endif]>
</table>

</body>

</html>
