<table border="0" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">

<?
$query_item_list = "SELECT s14_aiid, s14_asid, s14_model, s14_poor, s14_stat, s14_asrid, cost_name, cost_sn, as_start_view, as_end_result  FROM $db14 WHERE s14_asid = '$my_s13_asid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}
while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   



$my_s14_aiid = $row_item_list[s14_aiid];
$no++;
$my_s14_asid = $row_item_list[s14_asid];
$my_s14_model = $row_item_list[s14_model];
$my_s14_poor = $row_item_list[s14_poor];
$my_s14_stat = $row_item_list[s14_stat];
$my_s14_asrid = $row_item_list[s14_asrid];

//추가 코드 
$my_cost_name = $row_item_list[cost_name];
$my_cost_sn = $row_item_list[cost_sn];
$my_as_start_view = $row_item_list[as_start_view];
$my_as_end_result = $row_item_list[as_end_result];

echo("<td height='50' align='center' valign='middle'>");
include"view_inc_parts_cost_end.php";
echo("</td></tr>");
}


?>

</table>