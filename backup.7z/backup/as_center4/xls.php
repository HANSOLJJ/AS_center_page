<?php
$title = "출고정보1";

header( "Content-type: application/vnd.ms-excel; charset=utf-8" ); 
header("Content-Disposition: attachment; filename=".$title.".xls");
 header( "Content-Description: PHP4 Generated Data" ); 
 print("<meta http-equiv=\"Content-Type\" content=\"application/vnd.ms-excel; charset=utf-8\">"); 

?>

<html>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=enc-kr">
</head>
<body>
<table border=1>
<tr>
	<td>입고일</td>
	<td>수탁방법</td>
	<td>접수번호</td>
	<td>업체명</td>
	<td>형태</td>
	<td>주소</td>
	<td>연락처</td>
	<td>입금확인</td>
	<td>세금계산서발행</td>
	<td>택배</td>
</tr>

<?php
### DB 연결
$mysql_host = 'localhost';     // 호스트명 
$mysql_user = 'mic4u41';     // 사용자 계정 
$mysql_pwd  = 'digidigi';      // 비밀번호 
$mysql_db   = 'mic4u41';       // DB(데이터베이스)명) 
$connect = @mysql_connect($mysql_host, $mysql_user, $mysql_pwd) or die("서버 접속에 실패 했습니다. 계정 또는 패스워드를 확인하세요.");
@mysql_select_db($mysql_db, $connect) or die("DB 연결에 실패 했습니다. 데이터베이스명을 확인하세요.");
###
$query = "SELECT s13_asid, s13_as_center, s13_as_in_date, s13_as_in_how, s13_as_in_no, s13_meid, s13_dex_no, s13_total_cost, s13_sms1, s13_sms2, s13_bank_check, s13_tax_code, s13_dex_send, s13_dex_send_name, s13_as_out_date FROM step13_as";
$result= mysql_query($query);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

	// 이부분에 데이터를 출력시킨다.

$s1 = date("y-m-d",$row[s13_as_in_date]);
$s2 = $row[s13_as_in_how];
$s3 = $row[s13_as_in_no];
$s4_num = $row[s13_meid];

$s8_check = $row[s13_bank_check];
if($s8_check =="T"){$s8="입금";}else{$s8="미입금";}

$s9_check = $row[s13_tax_code];
if($s9_check !=""){$s9="발행";}else{$s9="미발행";}

$s10_check1 = $row[s13_dex_send_name];
$s10_check2 = $row[s13_dex_send];
 
if($s10_check1 !=""){$s10="$s10_check1($s10_check2)";}else{$s10="-";}


//------------------업체명

$instant_query = "Select s11_com_name, s11_sec, s11_oaddr, s11_phone1, s11_phone2, s11_phone3 FROM step11_member
 WHERE s11_meid  ='$s4_num'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $s11_com_name=$instant_reply->s11_com_name;
	   $s11_sec=$instant_reply->s11_sec;
	   $s11_oaddr=$instant_reply->s11_oaddr;
	   $s11_phone1=$instant_reply->s11_phone1;
	   $s11_phone2=$instant_reply->s11_phone2;
	   $s11_phone3=$instant_reply->s11_phone3;

	   
	$s4 = $s11_com_name;
	$s5 = $s11_sec;
	$s6 = $s11_oaddr;
	$s7 = $s11_phone1."-".$s11_phone2."-".$s11_phone3;
   }
}

print"<tr><td>$s1</td><td>$s2</td><td>$s3</td><td>$s4</td><td>$s5</td><td>$s6</td><td>$s7</td><td>$s8</td><td>$s9</td><td>$s10</td><td>$s11</td></tr>";


}?>



</table>
</body>
</html>
