<?
//-------------센터별 전화번호 출력
$member_center_id = $HTTP_SESSION_VARS["member_center_id"];

//------------------센터명
$center_query = mysql_query("Select s2_center_tel FROM step2_center WHERE s2_center_id ='$member_center_id'");
$center_tel = mysql_result($center_query,0,0);
$remote_callback = $center_tel;
?>