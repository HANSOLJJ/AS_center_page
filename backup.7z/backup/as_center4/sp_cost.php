<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$query = "UPDATE $db18 SET s18_sp_cost = 's' WHERE s18_accid = '$s18_accid'";

$result = mysql_query($query);
//$query2 = "UPDATE $db13 SET s13_total_cost = s13_total_cost - $parts_cost WHERE s13_asid = '$s18_asid'";

$query2 = "UPDATE $db13 SET s13_total_cost = s13_total_cost - $j_total_cost WHERE s13_asid = '$s18_asid'";

$result2 = mysql_query($query2);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

   ##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
  echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=test&number=$number'>");
} 

?>
