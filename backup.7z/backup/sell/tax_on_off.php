<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 

$query = "UPDATE $db20 SET s20_tax_code  = '$tax' WHERE s20_sellid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

##### 리스트 출력화면으로 이동한다.

echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>