<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>
<script language="javascript">
<!--
function sendit() {

   if(!form.s21_quantity.value) {
      alert('수량을 입력하세요!');
      form.s21_quantity.focus();
      return;
   }

if(form.s21_quantity.value) {
         if(!IsNumber(form.s21_quantity.name)) {
            alert("수량는 숫자여야 합니다!");
            form.s21_quantity.focus();
            return; 
         }
      }

           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }

//-->
</script>
<table  width='100%'  height='35' cellpadding='0' cellspacing='0' border='0' align='center' valign='middle'>
	<tr>
		<td valign='middle'>
<form name='form' method='POST' action='<? echo("num_process.php?page=$page&s21_accid=$s21_accid&s21_sellid=$s21_sellid&s21_uid=$s21_uid&s11_sec=$s11_sec&keyfield=$keyfield&key=$key");?>' target='admin_target' enctype='multipart/form-data'>
<input type='text' name='s21_quantity' size='4' maxlength='4'  <? echo"$Form_style1";?> value='<? echo"$my_s21_quantity";?>'>&nbsp;<A href='javascript:sendit()'><img src='../<?echo"$icon_dir";?>/cart_modi.gif' border='0' align='absmiddle'></a>
		</td>
	</tr>
	</form>
</table>