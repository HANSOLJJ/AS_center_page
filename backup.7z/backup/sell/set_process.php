<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";



##### 
$s20_as_level  = "2";
$s20_sell_name1 = $HTTP_SESSION_VARS[member_name];
$signdate = time();

####
$today = date("ymd");        

$today_query = "select max(s20_as_in_no2) from $db20 where s20_as_time ='$today'";
$today_result = mysql_query($today_query);
$today_row = mysql_fetch_row($today_result);

$temp_no = $today_row[0];

$str1 = substr($temp_no, 6, 3);   


$mcount = $str1 + 1;
$mcount =sprintf("%03d",$mcount);

$s20_as_in_no = "NO".$today."-".$mcount;

$s20_as_in_no2 = $today.$mcount;
####

$s20_as_in_date = mktime(0, 0, 0, $in_month, $in_day, $in_year);
//$s13_as_in_no = 'as'.time();
$s20_as_time =date("ymd");  


$query = "UPDATE $db20 SET s20_as_time = '$s20_as_time', s20_as_in_no = '$s20_as_in_no', s20_as_in_no2 = '$s20_as_in_no2', s20_as_level  = '$s20_as_level', s20_sell_name1  = '$s20_sell_name1', s20_as_out_date = '$signdate', s20_total_cost ='$j_total_cost'  WHERE s20_sellid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

#####파츠 수량 정리

//------기존 수량 확인
$center_id_s = $HTTP_SESSION_VARS[member_center_id];



$query1 = "SELECT s21_uid, s21_quantity FROM $db21 WHERE s21_sellid = '$number'";
$result1 = mysql_query($query1);

while($row1 = mysql_fetch_array($result1,MYSQL_ASSOC)) {

	$my_s21_uid = $row1[s21_uid];
	$my_s21_quantity = $row1[s21_quantity];



$query2 = "UPDATE $db7 SET s7_num = s7_num - '$my_s21_quantity' WHERE s7_center_id  = '$center_id_s' AND s7_uid ='$my_s21_uid'";
$result2 = mysql_query($query2);


}

##### 리스트 출력화면으로 이동한다.

echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>