<?
$sellid = $my_s20_sellid;
$sec = $s11_sec;

$query_sum1 = "SELECT s21_accid, s21_sellid, s21_uid, s21_quantity, s21_sp_cost FROM $db21 WHERE s21_sellid = '$sellid'";
$result_sum1= mysql_query($query_sum1);
if (!$result_sum1) {
   error("QUERY_ERROR");
   exit;
}

$no_code="0";
$kid_total  ="0";

while($row_sum1 = mysql_fetch_array($result_sum1,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s21_accid = $row_sum1[s21_accid];
$no_code++;
$my_s21_sellid = $row_sum1[s21_sellid];
$my_s21_uid = $row_sum1[s21_uid];
$my_s21_quantity = $row_sum1[s21_quantity];
$my_s21_sp_cost = $row_sum1[s21_sp_cost];
//echo"$my_s21_sellid-$my_s21_uid-$my_s21_quantity-$my_s21_sp_cost<br>";
//--------------------------- 부품정보


$query_sum2 = "SELECT s1_cost_c_1, s1_cost_a_2, s1_cost_n_2, s1_cost_s_1 FROM $db1 WHERE s1_uid = '$my_s21_uid'";
$result_sum2 = mysql_query($query_sum2);
if(!$result_sum2) {
   error("QUERY_ERROR");
   exit;
}

$row_sum2 = mysql_fetch_row($result_sum2);

$my_s1_cost_c_1 = $row_sum2[0];
$my_s1_cost_a_2 = $row_sum2[1];
$my_s1_cost_n_2 = $row_sum2[2];
$my_s1_cost_s_1 = $row_sum2[3];

if($sec =="일반" AND  $my_s21_sp_cost ==""){$n_cost=$my_s1_cost_n_2;}else
if($sec =="대리점" AND  $my_s21_sp_cost ==""){$n_cost=$my_s1_cost_a_2;}else
if($sec =="딜러" AND  $my_s21_sp_cost ==""){$n_cost=$my_s1_cost_c_1;}else
if($sec =="일반" AND  $my_s21_sp_cost !=""){$n_cost=$my_s1_cost_s_1;}else
if($sec =="대리점" AND  $my_s21_sp_cost !=""){$n_cost=$my_s1_cost_s_1;}else
if($sec =="딜러" AND  $my_s21_sp_cost !=""){$n_cost=$my_s1_cost_s_1;}


$kid_cost[$no_code] = $my_s21_quantity * $n_cost;
//---------------가격 테스트 코드

//echo "$kid_cost[$no_code] $my_s21_quantity X $n_cost<br>";

//-----------------------------
$kid_total = $kid_total + $kid_cost[$no_code];

}
$kid_total_default = $kid_total;
$kid_total =number_format($kid_total);
echo"<b>$kid_total 원</b>";
?>
