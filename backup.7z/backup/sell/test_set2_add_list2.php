<table border="1" width="100%" cellspacing="0" bordercolordark="black" bordercolorlight="black">
	<tr>
		 <td width="10%"  height='30'><p align='center'><b>No.</b></p></td>
		<td width="20%"  height='30'><p align='center'><b>모델명</b></p></td>
		<td width="20%"  height='30'><p align='center'><b>A/S 처리내용</b></p></td>
		<td width="50%" height='15'><p align='center'><b>소모품신청</b></p></td>
</tr>

   <!---             <tr>
                    <td  height="15"><p align='center'><b>품목</b></p></td>
                    <td  height="15"><p align='center'><b>수량</b></p></td>
                </tr>
--->

<?
$query_item_list = "SELECT s14_aiid, s14_asid, s14_model, s14_poor, s14_stat, s14_asrid  FROM $db14 WHERE s14_asid = '$my_s13_asid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}

while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$no='0';


$my_s14_aiid = $row_item_list[s14_aiid];
$no++;
$my_s14_asid = $row_item_list[s14_asid];
$my_s14_model = $row_item_list[s14_model];
$my_s14_poor = $row_item_list[s14_poor];
$my_s14_stat = $row_item_list[s14_stat];
$my_s14_asrid = $row_item_list[s14_asrid];

if($my_s14_as_nae ==""){$my_s14_as_nae ="&nbsp;";}

//------------------as 데이터 불러오기

$as_query1 = "SELECT s19_result FROM $db19 WHERE s19_asrid = '$my_s14_asrid'";
$as_result1 = mysql_query($as_query1);
if(!$as_result1) {
   error("QUERY_ERROR");
   exit;
}

$as_row1 = mysql_fetch_row($as_result1);

$my_s19_result = $as_row1[0];

if($my_s19_result ==""){$my_s19_result ="-";}
//------------------데이터 불러오기

$small_query1 = "SELECT s15_model_name, s15_model_sn FROM $db15 WHERE s15_amid = '$my_s14_model'";
$small_result1 = mysql_query($small_query1);
if(!$small_result1) {
   error("QUERY_ERROR");
   exit;
}

$small_row1 = mysql_fetch_row($small_result1);

$my_s15_model_name = $small_row1[0];
$my_s15_model_sn = $small_row1[1];

//------------------데이터 불러오기

$small_query2 = "SELECT s16_poor FROM $db16 WHERE s16_apid = '$my_s14_poor'";
$small_result2 = mysql_query($small_query2);
if(!$small_result2) {
   error("QUERY_ERROR");
   exit;
}

$small_row2 = mysql_fetch_row($small_result2);

$my_s16_poor = $small_row2[0];

echo("<td height='50' align='center' valign='middle'><b>$no</td>");
echo("<td height='50' align='center' valign='middle' ><b>$my_s15_model_name</b><br>($my_s15_model_sn)</td>");
echo("<td height='50' align='center' valign='middle' ><font color='red'><b>$my_s19_result</b></font></td>");
echo("<td height='50' align='center' valign='middle'>");
include"test_s_part_list.php";
echo("</td></tr>");
}

?>
</table>