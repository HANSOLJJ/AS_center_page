<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";


$member_center_id = $HTTP_SESSION_VARS["member_center_id"];

################
$query_sum = "SELECT s7_cpid, s7_uid, s7_num  FROM $db7 WHERE s7_center_id = '$member_center_id' AND s7_uid ='$s21_uid'";
  $result_sum = mysql_query($query_sum);
  if (!$result_sum) {
	 error("QUERY_ERROR");
	 exit;
  }

$row_sum = mysql_fetch_object($result_sum);
$my_s7_cpid = $row_sum->s7_cpid;
$my_s7_uid = $row_sum->s7_uid;
$my_s7_num = $row_sum->s7_num;

$total_record = $my_s7_num - $s21_quantity;

if ($total_record <"0") {      
   popup_msg("재고량이 부족합니다,. \\n\\n다시한번 확인하시고 입력하여 주십시오.");
// popup_msg("$my_s7_num - $s21_quantity = $total_record");
         break;    
  exit;}


##### 
  $query = "UPDATE $db21 SET s21_quantity  = '$s21_quantity' WHERE s21_accid  = '$s21_accid'";
  $result = mysql_query($query);
  if (!$result) {
	 error("QUERY_ERROR");
	 exit;
  }
    
 ##### 리스트 출력화면으로 이동한다.
echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=sell_write&number=$number&s21_sellid=$s21_sellid&s11_sec=$s11_sec&keyfield=$keyfield&key=$key'>");   
  
  
  ?>
