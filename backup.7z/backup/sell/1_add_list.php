<table  width='100%' cellpadding='0' cellspacing='0' border='1' align='center'bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td  width='70%' height='40' background="<?echo "$border_bg1";?>">
		<p align='center'><b>부품명</b></p>
		</td>
		<td  width='30%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>수량</b></p>
		</td>
	</tr>

<?
$query_item_list = "SELECT s21_accid, s21_sellid, s21_uid, s21_quantity, s21_signdate, s21_end, s21_sp_cost, cost_name, cost_sn FROM $db21 WHERE s21_sellid = '$my_s20_sellid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}

while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.  
$my_s21_accid = $row_item_list[s21_accid];
$my_s21_sellid = $row_item_list[s21_sellid];
$my_s21_uid = $row_item_list[s21_uid];
$my_s21_quantity = $row_item_list[s21_quantity];
$my_s21_sp_cost = $row_item_list[s21_sp_cost];
$my_cost_name = $row_item_list[cost_name];
$my_cost_sn = $row_item_list[cost_sn];

echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><b>$my_cost_name</b><br>($my_cost_sn)</td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><font color='red'><b>$my_s21_quantity</b></font></td></tr>");
}

?>
</table>