<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		① 업체명 확인&nbsp;→&nbsp;
		<font color='red'><b>② 업체 정보 등록 및 선택</b></font>&nbsp;→&nbsp;
		③ 판매정보 입력
		</td>
	</tr>
</table>
<br>
<?
$center_id_s = $HTTP_SESSION_VARS[member_center_id];

//------------------센터명 부르기

$center_query = mysql_query("Select s2_center FROM $db2 WHERE s2_center_id ='$center_id_s'");
$center_name = mysql_result($center_query,0,0);
?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s11_com_num1.value) {
      alert('사업자 등록 번호1을 입력하세요!');
      form.s11_com_num1.focus();
      return;
   }

   if(!form.s11_com_num2.value) {
      alert('사업자 등록 번호2을 입력하세요!');
      form.s11_com_num2.focus();
      return;
   }

   if(!form.s11_com_num3.value) {
      alert('사업자 등록 번호3을 입력하세요!');
      form.s11_com_num3.focus();
      return;
   }

	 if(form.s11_com_num1.value) {
         if(!IsNumber(form.s11_com_num1.name)) {
            alert("사업자 등록 번호1은 숫자여야 합니다!");
            form.s11_com_num1.focus();
            return; 
         }
      }

	  if(form.s11_com_num2.value) {
         if(!IsNumber(form.s11_com_num2.name)) {
            alert("사업자 등록 번호2은 숫자여야 합니다!");
            form.s11_com_num2.focus();
            return; 
         }
      }

	  if(form.s11_com_num3.value) {
         if(!IsNumber(form.s11_com_num3.name)) {
            alert("사업자 등록 번호3은 숫자여야 합니다!");
            form.s11_com_num3.focus();
            return; 
         }
      }

	  if(!form.s11_com_sec1.value) {
      alert('업종을 입력하세요!');
      form.s11_com_sec1.focus();
      return;
   }

   if(!form.s11_com_sec2.value) {
      alert('업태을 입력하세요!');
      form.s11_com_sec2.focus();
      return;
   }

   if(!form.s11_com_man.value) {
      alert('대표자를 입력하세요!');
      form.s11_com_man.focus();
      return;
   }

   if(!form.s11_com_zip1.value) {
      alert('우편번호를 입력하세요!');
      form.s11_com_zip1.focus();
      return;
   }

	 if(form.s11_com_zip1.value) {
         if(!IsNumber(form.s11_com_zip1.name)) {
            alert("우편번호는 숫자여야 합니다!");
            form.s11_com_zip1.focus();
            return; 
         }
      }

	  if(!form.s11_com_zip2.value) {
      alert('우편번호를 입력하세요!');
      form.s11_com_zip2.focus();
      return;
   }

	 if(form.s11_com_zip2.value) {
         if(!IsNumber(form.s11_com_zip2.name)) {
            alert("우편번호는 숫자여야 합니다!");
            form.s11_com_zip2.focus();
            return; 
         }
      }

	  if(!form.s11_oaddr.value) {
      alert('주소를 입력하세요!');
      form.s11_oaddr.focus();
      return;
   }

   if(!form.s11_phone1.value) {
      alert('전화번호를 입력하세요!');
      form.s11_phone1.focus();
      return;
   }

   if(!form.s11_phone2.value) {
      alert('전화번호를 입력하세요!');
      form.s11_phone2.focus();
      return;
   }

   if(!form.s11_phone3.value) {
      alert('전화번호를 입력하세요!');
      form.s11_phone3.focus();
      return;
   }

	 if(form.s11_phone1.value) {
         if(!IsNumber(form.s11_phone1.name)) {
            alert("전화번호는 숫자여야 합니다!");
            form.s11_phone1.focus();
            return; 
         }
      }

	   if(form.s11_phone2.value) {
         if(!IsNumber(form.s11_phone2.name)) {
            alert("전화번호는 숫자여야 합니다!");
            form.s11_phone2.focus();
            return; 
         }
      }

	   if(form.s11_phone3.value) {
         if(!IsNumber(form.s11_phone3.name)) {
            alert("전화번호는 숫자여야 합니다!");
            form.s11_phone3.focus();
            return; 
         }
      }

	   if(!form.s11_phone4.value) {
      alert('전화번호를 입력하세요!');
      form.s11_phone4.focus();
      return;
   }

   if(!form.s11_phone5.value) {
      alert('전화번호를 입력하세요!');
      form.s11_phone5.focus();
      return;
   }

   if(!form.s11_phone6.value) {
      alert('전화번호를 입력하세요!');
      form.s11_phone6.focus();
      return;
   }

	 if(form.s11_phone4.value) {
         if(!IsNumber(form.s11_phone4.name)) {
            alert("전화번호는 숫자여야 합니다!");
            form.s11_phone4.focus();
            return; 
         }
      }

	   if(form.s11_phone5.value) {
         if(!IsNumber(form.s11_phone5.name)) {
            alert("전화번호는 숫자여야 합니다!");
            form.s11_phone5.focus();
            return; 
         }
      }

	   if(form.s11_phone6.value) {
         if(!IsNumber(form.s11_phone6.name)) {
            alert("전화번호는 숫자여야 합니다!");
            form.s11_phone6.focus();
            return; 
         }
      }


           
   form.submit();
}

   function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }

   function ZipWindow(ref,what) {
      var window_left = (screen.width-640)/2;
      var window_top = (screen.height-480)/2;
      ref = ref + "?what=" + what;      
      window.open(ref,"zipWin",'width=550,height=200,status=no,top=' + window_top + ',left=' + window_left + '');
   }

//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>


<form name='form' method='POST' action='write2_process.php' enctype='multipart/form-data'>
<INPUT type='hidden' name='s11_com_name' value="<? echo"$s11_com_name";?>">
<INPUT type='hidden' name='mode_se' value="yes">

<!------------------------- 업체명  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>업체명</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<? echo"$s11_com_name";?>&nbsp;&nbsp;<a href='list.php?in_code=write2-2&s11_com_name=<? echo"$s11_com_name";?>'><b><font color='red'>[사업자 정보 삭제]</font></b></a>
			</td>
		</tr>
<!------------------------- 형태  --------------------------->
		<tr>
			<td  height='40' align='center' bgcolor='#fbfbfb'>
			<b>형태</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="radio" name="s11_sec" value="일반" checked>&nbsp;일반&nbsp;
			<input type="radio" name="s11_sec" value="대리점">&nbsp;대리점&nbsp;
			<input type="radio" name="s11_sec" value="딜러">&nbsp;AS 센터 공급가&nbsp;
			</td>
		</tr>
<!------------------------- 사업자 정보  --------------------------->
		<tr>
			<td  height='40' align='center' bgcolor='#fbfbfb'>
			<b>사업자 등록번호</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="text" name="s11_com_num1" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_com_num2" size="2" maxlength="2" <?echo("$Form_style1");?>>&nbsp; -&nbsp;
			<input type="text" name="s11_com_num3" size="5" maxlength="5" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!-------------------------업종업태  --------------------------->
		<tr>
			<td  height='40' align='center' bgcolor='#fbfbfb'>
			<b>업종 / 업태</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="text" name="s11_com_sec1" size="32" maxlength="255" <?echo("$Form_style1");?>>&nbsp;/&nbsp;
			<input type="text" name="s11_com_sec2" size="32" maxlength="255" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 대표자  --------------------------->
		<tr>
			<td  height='40' align='center' bgcolor='#fbfbfb'>
			<b>대표자</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="text" name="s11_com_man" size="32" maxlength="32" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- 주소  --------------------------->
		<tr>
			<td  height='60' align='center' bgcolor='#fbfbfb'>
			<b>업체 주소</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="text" name="s11_com_zip1" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp;-&nbsp; 
			<input type="text" name="s11_com_zip2" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp; 
			<input type="button" value="우편번호 및 주소 자동입력" onClick="ZipWindow('zipsearch.php',1)">
			<br>
			&nbsp;&nbsp;
			<input type="text" name="s11_oaddr" size="64" maxlength="255" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- sms  --------------------------->
		<tr>
			<td  height='40' align='center' bgcolor='#fbfbfb'>
			<b>연락처(SMS용 핸드폰)</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="text" name="s11_phone1" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp;-&nbsp;<input type="text" name="s11_phone2" size="4" maxlength="4" <?echo("$Form_style1");?>>&nbsp;-&nbsp;<input type="text" name="s11_phone3" size="4" maxlength="4" <?echo("$Form_style1");?>>
			</td>
		</tr>
<!------------------------- sms  --------------------------->
		<tr>
			<td  height='40' align='center' bgcolor='#fbfbfb'>
			<b>연락처(일반전화)</b>
			</td>
			<td>&nbsp;&nbsp;
			<input type="text" name="s11_phone4" size="3" maxlength="3" <?echo("$Form_style1");?>>&nbsp;-&nbsp;<input type="text" name="s11_phone5" size="4" maxlength="4" <?echo("$Form_style1");?>>&nbsp;-&nbsp;<input type="text" name="s11_phone6" size="4" maxlength="4" <?echo("$Form_style1");?>>
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>