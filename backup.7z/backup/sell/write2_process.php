<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

if($mode_se=="yes"){
$query = "INSERT INTO $db11 (s11_sec, s11_phone1, s11_phone2, s11_phone3, s11_phone4, s11_phone5, s11_phone6, s11_com_num1, s11_com_num2, s11_com_num3, s11_com_name, s11_com_man, s11_com_sec1, s11_com_sec2, s11_oaddr, s11_com_zip1, s11_com_zip2) VALUES ('$s11_sec', '$s11_phone1', '$s11_phone2', '$s11_phone3', '$s11_phone4', '$s11_phone5', '$s11_phone6', '$s11_com_num1', '$s11_com_num2', '$s11_com_num3', '$s11_com_name', '$s11_com_man', '$s11_com_sec1', '$s11_com_sec2', '$s11_oaddr', '$s11_com_zip1', '$s11_com_zip2')";
}else{
$query = "INSERT INTO $db11 (s11_sec, s11_phone1, s11_phone2, s11_phone3, s11_phone4, s11_phone5, s11_phone6, s11_com_num1, s11_com_num2, s11_com_num3, s11_com_name, s11_com_man, s11_com_sec1, s11_com_sec2, s11_oaddr, s11_com_zip1, s11_com_zip2) VALUES ('$s11_sec', '$s11_phone1', '$s11_phone2', '$s11_phone3', '$s11_phone4', '$s11_phone5', '$s11_phone6', '-', '-', '-', '$s11_com_name', '$s11_com_man', '-', '-', '-', '-', '-')";
}

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {


$query2 = "SELECT s11_meid FROM $db11 WHERE s11_com_name  = '$s11_com_name' AND s11_com_man  = '$s11_com_man'";
$result2= mysql_query($query2);

if(!$result2) {
   error("QUERY_ERROR");
   exit;
}
$result2_row = mysql_fetch_row($result2);

$my_s11_meid = $result2_row[0];

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=write_20_process.php?s11_meid=$my_s11_meid'>");
} 

?>

