<?

$query = "SELECT s11_com_name FROM $db11";

$result= mysql_query($query);

while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {

$s11_com_name = $row[s11_com_name];
$s11_com_name = "\"".$s11_com_name."\"";


if($data==""){$data = $s11_com_name;}else{$data = $data.",".$s11_com_name;}

}
//echo"$data";
?>
