<?
$sellid = $my_s20_sellid;
$sec = $s11_sec;

$query_sum1 = "SELECT s21_accid, s21_sellid, s21_uid, s21_quantity, s21_sp_cost, cost1, cost2 FROM $db21 WHERE s21_sellid = '$sellid'";
$result_sum1= mysql_query($query_sum1);
if (!$result_sum1) {
   error("QUERY_ERROR");
   exit;
}

$no_code="0";
$kid_total  ="0";

while($row_sum1 = mysql_fetch_array($result_sum1,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
$my_s21_accid = $row_sum1[s21_accid];
$no_code++;
$my_s21_sellid = $row_sum1[s21_sellid];
$my_s21_uid = $row_sum1[s21_uid];
$my_s21_quantity = $row_sum1[s21_quantity];
$my_s21_sp_cost = $row_sum1[s21_sp_cost];
$my_cost1= $row_sum1[cost1];
$my_cost2 = $row_sum1[cost2];

//echo"$my_s21_sellid - $my_s21_uid - $my_s21_quantity X $my_cost1($my_s21_sp_cost)<br>";


if($my_s21_sp_cost ==""){$kid_cost[$no_code] = $my_s21_quantity * $my_cost1;}
//---------------가격 테스트 코드

echo "<p align='left'>$my_s21_quantity X $my_cost1 = $kid_cost[$no_code] <br></p>";

//-----------------------------
$kid_total = $kid_total + $kid_cost[$no_code];

}
$kid_total_default = $kid_total;
$kid_total =number_format($kid_total);
echo"<b>$kid_total 원</b>";
?>
