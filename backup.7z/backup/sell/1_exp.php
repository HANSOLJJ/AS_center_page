<?
$query_read = "SELECT s11_sec, s11_phone1, s11_phone2, s11_phone3, s11_phone4, s11_phone5, s11_phone6, s11_com_num1, s11_com_num2, s11_com_num3, s11_com_name, s11_com_man, s11_com_sec1, s11_com_sec2, s11_oaddr, s11_com_zip1, s11_com_zip2 FROM step11_member WHERE s11_meid = $s11_meid ";
$result_read = mysql_query($query_read);
if(!$result_read) {
   error("QUERY_ERROR");
   exit;
}
$row_read = mysql_fetch_object($result_read);

$my_s11_meid = $row_read->s11_meid;
$my_s11_sec = $row_read->s11_sec;
$my_s11_phone1 = $row_read->s11_phone1;
$my_s11_phone2 = $row_read->s11_phone2;
$my_s11_phone3 = $row_read->s11_phone3;
$my_s11_phone4 = $row_read->s11_phone4;
$my_s11_phone5 = $row_read->s11_phone5;
$my_s11_phone6 = $row_read->s11_phone6;
$my_s11_com_num1 = $row_read->s11_com_num1;
$my_s11_com_num2 = $row_read->s11_com_num2;
$my_s11_com_num3 = $row_read->s11_com_num3;
$my_s11_com_name = $row_read->s11_com_name;
$my_s11_com_man = $row_read->s11_com_man;
$my_s11_com_sec1 = $row_read->s11_com_sec1;
$my_s11_com_sec2 = $row_read->s11_com_sec2;
$my_s11_oaddr = $row_read->s11_oaddr;
$my_s11_com_zip1 = $row_read->s11_com_zip1;
$my_s11_com_zip2 = $row_read->s11_com_zip2;

$ex_sms_no = $my_s11_phone1."".$my_s11_phone2."".$my_s11_phone3;
$ex_tel = $my_s11_phone4."-".$my_s11_phone5."-".$my_s11_phone6;
$ex_sec2  = $my_s11_com_sec1."(".$my_s11_com_sec2.")";
$ex_company = $my_s11_com_name;
$ex_man = $my_s11_com_man;
$ex_address = $my_s11_oaddr;
$ex_address_no = $my_s11_com_zip1."-".$my_s11_com_zip2;
$ex_company_no = $my_s11_com_num1."-".$my_s11_com_num2."-".$my_s11_com_num3;

$query_33 = "UPDATE step20_sell SET ex_tel  = '$ex_tel', ex_sms_no  = '$ex_sms_no', ex_sec1  = '$my_s11_sec', ex_sec2  = '$ex_sec2', ex_company  = '$ex_company', ex_man  = '$ex_man', ex_address  = '$ex_address', ex_address_no  = '$ex_address_no', ex_company_no  = '$ex_company_no'  WHERE s20_sell_in_date = '$s20_sell_in_date'";
  $result_33 = mysql_query($query_33);
  if (!$result_33) {
	 error("QUERY_ERROR");
	 exit;
  }
  ?>