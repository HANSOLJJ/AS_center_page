<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";


$signdate = time();
$query = "UPDATE $db20 SET s20_bank_check = '$signdate', s20_bankcheck_w = 'center' WHERE s20_sellid  = '$bcode'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?page=$page'>");
} 

?>
