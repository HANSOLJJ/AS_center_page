<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s1_uid , s1_caid, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1, s1_cost_won, s1_erp FROM $db1 WHERE s1_uid = '$number'";

$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}

$row = mysql_fetch_row($result);

$my_s1_uid = $row[0];
$my_s1_caid = $row[1];
$my_s1_name = $row[2];

///-------------------------------------------------------추가 코드
$my_s1_cost_c_1 = $row[3];
$my_s1_cost_a_1 = $row[4];
$my_s1_cost_a_2 = $row[5];
$my_s1_cost_n_1 = $row[6];
$my_s1_cost_n_2 = $row[7];
$my_s1_cost_s_1 = $row[8];
$my_s1_cost_won = $row[9];
$my_s1_erp = $row[10];

//참조 ---  s1_cost_c_1 -- A/S CENTER 공급가
//참조 ---  s1_cost_a_1 -- 대리점 공급가(개별판매)
//참조 ---  s1_cost_a_2 -- 대리점 공급가(수리시)
//참조 ---  s1_cost_n_1 -- 일반 판매(개별판매)
//참조 ---  s1_cost_n_2 -- 일반 판매(수리시)
//참조 ---  s1_cost_s_1 -- 특별공급가
//참조 ---  s1_cost_won -- 원가

if($s11_sec =="일반"){$cost1 ="$my_s1_cost_n_1";}else
if($s11_sec =="대리점"){$cost1 ="$my_s1_cost_a_1";}else
if($s11_sec =="딜러"){$cost1 ="$my_s1_cost_c_1";}
$cost2 = $my_s1_cost_s_1;
$cost3 = $my_s1_cost_won;
$cost_sec = $s11_sec;
///-------------------------------------------------------추가 코드

$id = $HTTP_SESSION_VARS["member_id"];
$member_center_id = $HTTP_SESSION_VARS["member_center_id"];

$signdate = time();

##### 테이블에 입력값을 등록한다.s21_sellid,  s21_uid,  s21_quantity,  s21_signdate,  s21_end,  s21_sp_cost 
$query = "INSERT INTO $db21 (s21_sellid,  s21_uid,  s21_quantity,  s21_signdate,  s21_end, cost1, cost2, cost3, cost_sec, cost_name, cost_sn) VALUES ('$s21_sellid', '$my_s1_uid', '1', '$signdate', 'N', '$cost1', '$cost2', '$cost3', '$cost_sec', '$my_s1_name', '$my_s1_erp')";
$result = mysql_query($query);


  ##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=sell_write&page=$page&number=$s13_as_in_n&s11_meid=$s11_meid&s21_sellid=$s21_sellid&s11_sec=$s11_sec&keyfield=$keyfield&key=$key'>");


?>
