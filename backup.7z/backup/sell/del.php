<?
##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s20_sellid,  s20_as_center,  s20_sell_in_date, s20_total_cost,  s20_bank_check,  s20_tax_code,  s20_dex_send,  s20_dex_send_name,  s20_as_out_date,  s20_as_level,  s20_sell_name1, s20_meid FROM $db20 WHERE s20_sellid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s20_sellid = $row->s20_sellid;
$my_s20_as_center = $row->s20_as_center;
$my_s20_sell_in_date =date("y/m/d",$row->s20_sell_in_date);
$my_s20_total_cost = $row->s20_total_cost;

$my_s20_bank_check = $row->s20_bank_check;
$my_s20_tax_code = $row->s20_tax_code;
$my_s20_dex_send = $row->s20_dex_send;
$my_s20_dex_send_name = $row->s20_dex_send_name;
$my_s20_as_out_date = $row->s20_as_out_date;
$my_s20_as_level = $row->s20_as_level;
$my_s20_sell_name1 = $row->s20_sell_name1;
$my_s20_meid = $row->s20_meid;



//------------------업체명

$instant_query = "Select s11_com_name, s11_sec, s11_oaddr, s11_phone1, s11_phone2, s11_phone3 FROM $db11 WHERE s11_meid  ='$my_s20_meid'";
$instant_result = mysql_query($instant_query);

$instant_rows = mysql_num_rows($instant_result);

if($instant_rows > 0) {

   while($instant_reply = mysql_fetch_object($instant_result)) {
	   
	   
	   $s11_com_name=$instant_reply->s11_com_name;
	   $s11_sec=$instant_reply->s11_sec;
	   $s11_oaddr=$instant_reply->s11_oaddr;
	   $s11_phone1=$instant_reply->s11_phone1;
	   $s11_phone2=$instant_reply->s11_phone2;
	   $s11_phone3=$instant_reply->s11_phone3;

	   $phone_num = $s11_phone1."-".$s11_phone2."-".$s11_phone3;
	
   }

}

##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td>
		<p>&nbsp;</p>
		<p align='center'>
		<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
			<tr>
				<td  width='10%' height='50' background="<?echo "$border_bg1";?>">
				<p align='center'><b>판매일</b></p>
				</td>
				<td  width='10%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>업체명</b></p>
				</td>
				<td  width='10%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>연락처</b></p>
				</td>
				<td  width='30%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>판매품목</b></p>
				</td>
			</tr>
			<tr>
				<td height='50'>
				<p align='center'><? echo"$my_s20_sell_in_date";?></p>
				</td>
				<td>
				<p align='center'><? echo"$s11_com_name";?></p>
				</td>
				<td>
				<p align='center'><? echo"$phone_num";?></p>
				</td>
				<td>
				<p align='center'><? include"add_list.php";?></p>
				</td>
			</tr>
		</table>
		</p>
		<p align='center'><font color='red'><b>이글을 삭제하시려면 하단의 삭제버튼을 눌러주세요.<br>삭제된 글은 복원할 수 없습니다.</font></p>
		<p>&nbsp;</p>
		</td>
	</td>
</table>

<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center' >
	<tr>
		<td>
		<p align='right'><a href='del_process.php?number=<?echo("$number");?>&db=<?echo("$db");?>'>
		<img src='../<?echo("$icon_dir");?>/button_blue_del.gif' align='absmiddle' border='0'></a>&nbsp;
		<a href='<? echo("list.php?in_code=list_view");?>'>
		<img src='../<?echo("$icon_dir");?>/button_blue_cancel.gif' align='absmiddle' border='0'>
		</a>
		</p>
		</td>
	</tr>
</table>
