<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$s20_sell_in_date = time();
//$s13_as_in_no = 'as'.time();
$s20_as_time =date("ymd");  

$center_id_s = $HTTP_SESSION_VARS[member_center_id];
$s20_sell_name1 = $HTTP_SESSION_VARS[member_name];

$query = "INSERT INTO $db20 (s20_as_center,  s20_sell_in_date,  s20_total_cost,  s20_bank_check,  s20_tax_code,  s20_dex_send,  s20_dex_send_name,  s20_as_out_date,  s20_sell_name1, s20_meid) VALUES ('$center_id_s',  '$s20_sell_in_date', '$s20_total_cost', '$s20_bank_check', '$s20_tax_code', '$s20_dex_send', '$s20_dex_send_name', '$s20_as_out_date', '$s20_sell_name1', '$s11_meid')";
$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;

####

} else {

####추가정보 입력/3월
include"1_exp.php";
    
####셀 아이디값 얻기

$queryzz = "SELECT s20_sellid FROM $db20 WHERE s20_sell_in_date = '$s20_sell_in_date'";
$resultzz = mysql_query($queryzz);
if(!$resultzz) {
   error("QUERY_ERROR");
   exit;
}
$rowzz = mysql_fetch_row($resultzz);
$my_s20_sellid = $rowzz[0];

##### 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=sell_write&number=$s13_as_in_n&s11_meid=$s11_meid&s21_sellid=$my_s20_sellid&s20_sell_in_date=$s20_sell_in_date&s11_sec=$s11_sec'>");
} 

?>

