<table  width='100%' cellpadding='0' cellspacing='0' border='1' align='center'bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td  width='70%' height='40' background="<?echo "$border_bg1";?>">
		<p align='center'><b>부품명</b></p>
		</td>
		<td  width='30%' background="<?echo "$border_bg1";?>">
		<p align='center'><b>수량</b></p>
		</td>
	</tr>

<?
$query_item_list = "SELECT s21_accid, s21_sellid, s21_uid, s21_quantity, s21_signdate, s21_end, s21_sp_cost FROM $db21 WHERE s21_sellid = '$my_s20_sellid'";

$result_item_list= mysql_query($query_item_list);
if (!$result_item_list) {
   error("QUERY_ERROR");
   exit;
}

while($row_item_list = mysql_fetch_array($result_item_list,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.  
$my_s21_accid = $row_item_list[s21_accid];
$my_s21_sellid = $row_item_list[s21_sellid];
$my_s21_uid = $row_item_list[s21_uid];
$my_s21_quantity = $row_item_list[s21_quantity];
$my_s21_sp_cost = $row_item_list[s21_sp_cost];

if($my_s14_as_nae ==""){$my_s14_as_nae ="&nbsp;";}

//------------------as 데이터 불러오기

$as_query1 = "SELECT s1_uid, s1_erp, s1_name, s1_cost_c_1, s1_cost_a_1, s1_cost_a_2, s1_cost_n_1, s1_cost_n_2, s1_cost_s_1  FROM $db1 WHERE  s1_uid  = '$my_s21_uid'";
$as_result1 = mysql_query($as_query1);
if(!$as_result1) {
   error("QUERY_ERROR");
   exit;
}

$as_row1 = mysql_fetch_row($as_result1);

$my_s1_uid = $as_row1[0];
$my_s1_erp = $as_row1[1];
$my_s1_name = $as_row1[2];
$my_s1_cost_c_1 = $as_row1[3];
$my_s1_cost_a_1 = $as_row1[4];
$my_s1_cost_a_2 = $as_row1[5];
$my_s1_cost_n_1 = $as_row1[6];
$my_s1_cost_n_2 = $as_row1[7];
$my_s1_cost_s_1 = $as_row1[8];

echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><b>$my_s1_name</b><br>($my_s1_erp)</td>");
echo("<td height='50' align='center' valign='middle' $list_style1 $td_bg><font color='red'><b>$my_s21_quantity</b></font></td></tr>");
}

?>
</table>