<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";
?>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><? echo("$admin_name");?> 웹사이트 관리툴</title>
<link rel='stylesheet' href='<? echo("../$css");?>' type=text/css>

<?include"../print_code.php";?>

<Body LeftMargin='0' MarginWidth='0' TopMargin='0' MarginHeight='0'>

<? echo"$title_b_30"; ?>

<?

switch ($in_code) {

// 일반페이지


case ("") : 	include"list_view.php"; Break;
case ("list_view") : 	include"list_view.php"; Break;
case ("list_view2") : 	include"list_view2.php"; Break;
case ("del") : 	include"del.php"; Break;
case ("write1") : 	include"write1.php"; Break;
case ("write2-1") : 	include"write2-1.php"; Break;
case ("write2-2") : 	include"write2-2.php"; Break;
case ("write2-3") : 	include"write2-3.php"; Break;
case ("set1") : 	include"set1.php"; Break;
case ("set2") : 	include"set2.php"; Break;
case ("sell_write") :

print"<table width='100%' align='center' cellspacing='0' cellpadding='0'>
			<tr>
				<td align='center' width='50%' valign='top'>";
				include"cure_parts_list.php";
	print"</td>
	<td width='50%' valign='top' align='center'>";
include"cure_view.php";
	print"</td>
	</tr>
	</table>"; 
	Break;
}

?>
