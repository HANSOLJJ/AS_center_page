<?php
require_once 'session.php';

Session::logout();
header('Location: index.php');
exit;
?>
