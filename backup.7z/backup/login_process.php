<?php
/**
 * AS System - Login Processing (원본 구조 기반)
 * 로그인 폼 처리 및 인증
 */

header('Content-Type: text/html; charset=utf-8');

// 원본 @config.php 포함 (session_start() 포함)
include "@config.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$id = isset($_POST['admin_id']) ? trim($_POST['admin_id']) : '';
$passwd = isset($_POST['admin_password']) ? trim($_POST['admin_password']) : '';

// 입력값 검증
if (empty($id) || empty($passwd)) {
    $_SESSION['login_error'] = 'ID와 비밀번호를 입력해주세요.';
    header('Location: login.php');
    exit;
}

// ID 형식 검증 (5-10자의 알파벳/숫자)
if (!preg_match('/^[a-zA-Z0-9]{5,10}$/', $id)) {
    $_SESSION['login_error'] = '올바른 ID 형식이 아닙니다.';
    header('Location: login.php');
    exit;
}

// 비밀번호 형식 검증 (4-16자의 알파벳/숫자)
if (!preg_match('/^[a-zA-Z0-9]{4,16}$/', $passwd)) {
    $_SESSION['login_error'] = '올바른 비밀번호 형식이 아닙니다.';
    header('Location: login.php');
    exit;
}

// 데이터베이스에서 관리자 정보 조회
// $DB_Admin_Member는 @config.php에서 정의됨 ("2010_admin_member")
$result = @mysql_query("SELECT passwd, userlevel FROM $DB_Admin_Member WHERE id = '$id'");

if (!$result) {
    $_SESSION['login_error'] = '데이터베이스 쿼리 오류가 발생했습니다.';
    header('Location: login.php');
    exit;
}

$rows = @mysql_num_rows($result);

// 조회된 사용자가 없는 경우
if (!$rows) {
    $_SESSION['login_error'] = '존재하지 않는 관리자 ID입니다.';
    header('Location: login.php');
    exit;
}

// 조회된 관리자 정보 처리
$row = @mysql_fetch_object($result);
$db_passwd = $row->passwd;
$db_userlevel = $row->userlevel;

// 입력된 비밀번호를 MySQL PASSWORD() 함수로 암호화
$result = @mysql_query("SELECT password('$passwd')");
$user_passwd = @mysql_result($result, 0, 0);

// 저장된 비밀번호 길이가 16자인 경우 (구 MySQL PASSWORD 형식) 
// PASSWORD() 함수 결과의 처음 16자와 비교
if (strlen($db_passwd) <= 16) {
    $user_passwd = substr($user_passwd, 0, 16);
}

// 비밀번호 비교 (=== 연산자 사용)
$password_match = ($db_passwd === $user_passwd);

if ($password_match) {
    // 로그인 성공
    if (headers_sent()) {
        $_SESSION['login_error'] = 'HTTP 헤더가 이미 전송되었습니다.';
        header('Location: login.php');
        exit;
    }

    // 기존 쿠키 삭제
    setcookie("member_id", "", 0, "/");
    setcookie("member_sid", "", 0, "/");
    setcookie("member_email", "", 0, "/");
    setcookie("member_name", "", 0, "/");
    setcookie("member_level", "", 0, "/");

    // 세션 변수 설정
    $_SESSION['member_id'] = $id;
    $_SESSION['member_level'] = $db_userlevel;
    $_SESSION['member_sid'] = session_id();
    
    // dashboard.php로 리다이렉트
    header('Location: dashboard.php');
    exit;
} else {
    // 비밀번호 불일치
    $_SESSION['login_error'] = '비밀번호가 일치하지 않습니다.';
    header('Location: login.php');
    exit;
}

@mysql_close();
?>
