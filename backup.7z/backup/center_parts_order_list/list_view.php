<?
$member_center_id = $HTTP_SESSION_VARS["member_center_id"];


##### 한 페이지당 출력할 게시물의 수
$num_per_page = 50;

##### 게시물 출력목록 하단에 링크를 걸 페이지의 개수
$page_per_block = 10;


if(!$page) {
   $page = 1;
}

##### 전체게시물의 총 개수를 각각 구한다.
$query = "SELECT count(s6_cartnum) FROM $db6 WHERE s6_center_id  = '$member_center_id'";

$result = mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}
$total_record = mysql_result($result,0,0);

##### 전체 페이지수를 계산한다.
$total_page = ceil($total_record/$num_per_page);

##### 지정한 페이지에 대하여 출력할 레코드번호의 범위를 결정한다.
if($total_record == 0) {
   $first = 1;
   $last = 0;
} else {
   $first = $num_per_page*($page-1);
   $last = $num_per_page*$page;
}
?>

<script language="javascript">
<!--
function profileWindow(ref) {
   var window_left = (screen.width-700)/2;
   var window_top = (screen.height-500)/2;   
   window.open(ref,"profileWin",'width=700,height=500,status=no,scrollbars=yes,top=' + window_top + ',left=' + window_left + '');
}
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
    <tr>
		<td width="33%" height='50' background="<?echo "$border_bg1";?>">
            <p align="center"><b>No.</b></p>
        </td>
        <td width="33%" height='50' background="<?echo "$border_bg1";?>">
            <p align="center"><b>주문일</b></p>
        </td>
        <td width="33%" height='50' background="<?echo "$border_bg1";?>">
            <p align="center"><b>진행상태</b></p>
        </td>
    </tr>


<?
$time_limit = 60*60*24*$notify_new_article; 


##### 현재페이지의 범위내에 출력할 결과레코드세트를 얻는다.
 $query = "SELECT s6_orid, s6_cartnum, s6_center_id, s6_center_member, s6_completion, s6_signdate FROM $db6 WHERE s6_center_id  = '$member_center_id' ORDER BY s6_orid DESC LIMIT $first, $num_per_page";

   
$result= mysql_query($query);
if (!$result) {
   error("QUERY_ERROR");
   exit;
}

##### 게시물의 가상번호(게시물의 개수에 따른 일련번호)
$article_num = $total_record - $num_per_page*($page-1);

while($info = mysql_fetch_array($result,MYSQL_ASSOC)) {

   ##### 각 게시물 레코드의 필드값을 변수에 저장한다.   
   $my_s6_orid = $info[s6_orid];
   $my_s6_cartnum = $info[s6_cartnum];   
   $my_s6_center_id = $info[s6_center_id];
   $my_s6_center_member = $info[s6_center_member];
   $my_s6_completion = $info[s6_completion];
   $my_s6_signdate = date("Y.m.d",$info[s6_signdate]);

if($article_num % 2 =="1"){$td_bg="bgcolor='#fbfbfb'";}else{$td_bg="bgcolor='#FFFFFF'";}
######################################1

echo "<tr>";
   
echo "<td height='35' align='center' valign='middle' $list_style1 $td_bg>$article_num.</td>";

   #####

echo " <td height='35' align='center' valign='middle' $list_style1 $td_bg><a href='list.php?in_code=view&number=$my_s6_cartnum'><b>" . $my_s6_signdate . "</b></a></td>";


     ##### 


if($my_s6_completion =='주문접수'){$max="<font color=red><b>[주문접수]</b></font>-주문확인";} else
if($my_s6_completion =='주문확인'){$max="주문접수-<font color=red><b>[주문확인]</b></font>";} else
if($my_s6_completion =='발송완료'){$max="주문접수-주문확인-<font color=red><b>[발송완료]</b></font>";}
 

   ##### [컬럼 3 : 회원의 아이디를 출력한다.]   
echo "<td height='35' align='center' valign='middle' $list_style1 $td_bg>" . $max . "</td>";

  
   echo("</tr>");      

   $article_num--;
}
?>
	
</table>
<br>
<table width="700" border="0" cellspacing="0" cellpadding="0" align="center">
<tr>
   <td align="center">
<?
##### 게시물 목록 하단의 각 페이지로 직접 이동할 수 있는 페이지링크에 대한 설정을 한다.
$total_block = ceil($total_page/$page_per_block);
$block = ceil($page/$page_per_block);

$first_page = ($block-1)*$page_per_block;
$last_page = $block*$page_per_block;

if($total_block <= $block) {
   $last_page = $total_page;
}

##### 이전페이지블록에 대한 페이지 링크
if($block > 1) {
   $my_page = $first_page;
   echo "<a href=\"list.php?page=" . $my_page . "&keyfield=" . $keyfield . "&key=" . $encoded_key . "\" onMouseOver=\"status='load previous " . $page_per_block . " pages';return true;\" onMouseOut=\"status=''\">[이전 " . $page_per_block . "개]</a>";
}

##### 현재의 페이지 블럭범위내에서 각 페이지로 바로 이동할 수 있는 하이퍼링크를 출력한다.
for($direct_page = $first_page+1; $direct_page <= $last_page; $direct_page++) {
   if($page == $direct_page) {
      echo "<b>[$direct_page]</b>";
   } else {
      echo "<a href=\"list.php?page=" . $direct_page . "&keyfield=" . $keyfield . "&key=" . $encoded_key . "\" onMouseOver=\"status='jump to page " . $direct_page . "';return true;\" onMouseOut=\"status=''\">[" . $direct_page . "]</a>";
   }
}

##### 다음페이지블록에 대한 페이지 링크
if($block < $total_block) {
   $my_page = $last_page+1;
   echo "<a href=\"list.php?page=" . $my_page . "&keyfield=" . $keyfield . "&key=" . $encoded_key . "\" onMouseOver=\"status='load next " . $page_per_block . " pages';return true;\" onMouseOut=\"status=''\">[다음 " . $page_per_block . "개]</a>";
}
?>   
   </td>
</tr>
</table>
