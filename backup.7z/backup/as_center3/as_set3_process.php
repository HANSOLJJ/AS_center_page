<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";



##### 
$s13_as_level = "4";
$s13_as_name3 = $HTTP_SESSION_VARS[member_name];
$signdate = time();

$query = "UPDATE $db13 SET s13_as_level  = '$s13_as_level', s13_as_name3  = '$s13_as_name3', s13_as_out_date = '$signdate' WHERE s13_asid  = '$number'";
$result = mysql_query($query);
if (!$result) {
 error("QUERY_ERROR");
 exit;
}

##### 선택한 게시물의 입력값을 뽑아낸다.
$query2 = "SELECT s13_as_in_how, s13_meid,s13_total_cost  FROM $db13 WHERE s13_asid = '$number'";
$result2 = mysql_query($query2);
if(!$result2) {
   error("QUERY_ERROR");
   exit;
}
$row2 = mysql_fetch_object($result2);

$s13_as_in_how = $row2->s13_as_in_how;
$s13_meid = $row2->s13_meid;
$s13_total_cost = $row2->s13_total_cost;
$s13_total_cost = $s13_total_cost + 2500;
$s13_total_cost = number_format($s13_total_cost);	
####

//if($s13_as_in_how =="택배" OR $s13_as_in_how =="퀵"){
//include"sms_center_key.php";
//echo"$remote_callback";
//include"sms.php";
//}

##### 리스트 출력화면으로 이동한다.

echo("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=list_view'>");   
   ?>