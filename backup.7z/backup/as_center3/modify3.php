<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		<b>택배 출고 정보</b>
		</td>
	</tr>
</table>
<br>
<?

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_dex_send_name, s13_dex_send  FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_dex_send_name = $row->s13_dex_send_name;
$my_s13_dex_send= $row->s13_dex_send;

if($my_s13_dex_send_name =="CJ택배"){$check1= "selected";}

//------------------업체명
?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s13_dex_send_name.value) {
      alert('택배사를 선택하세요!');
      form.s13_dex_send_name.focus();
      return;
   }

   if(!form.s13_dex_send.value) {
      alert('택배 송장 번호를 입력하세요!');
      form.s13_dex_send.focus();
      return;
   }

   if(form.s13_dex_send.value) {
         if(!IsNumber(form.s13_dex_send.name)) {
            alert("택배 송장 번호는 숫자여야 합니다!");
            form.s13_dex_send.focus();
            return; 
         }
      }


           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name='form' method='POST' action='modify3_process.php?page=<? echo("$page"); ?>' enctype='multipart/form-data'>
<INPUT type='hidden' name='number' value="<? echo"$number";?>">

<!-------------------------입고일  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>택배사</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;

   <select name='s13_dex_send_name'>
   <option value=''>택배사를 선택하세요
  <option value= '로젠택배' <? echo"$check1";?>>로젠택배
   <option value= 'CJ택배' <? echo"$check1";?>>CJ택배

   </select>

			</td>
		</tr>
<!------------------------- 업체명  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>택배 송장 번호</b>
			</td>
			<td width='70%'>&nbsp;&nbsp;
			<input type="text" name="s13_dex_send" size="64" maxlength="255" <?echo("$Form_style1");?> value="<? echo"$my_s13_dex_send";?>">
			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>