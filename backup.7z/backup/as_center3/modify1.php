<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
		<td height='40' align='center' bgcolor='#fbfbfb'>
		<b>입금 확인</b>
		</td>
	</tr>
</table>
<br>
<?

##### 선택한 게시물의 입력값을 뽑아낸다.
$query = "SELECT s13_bank_check, s13_as_in_how, s13_meid  FROM $db13 WHERE s13_asid = $number";
$result = mysql_query($query);
if(!$result) {
   error("QUERY_ERROR");
   exit;
}
$row = mysql_fetch_object($result);

$my_s13_bank_check = $row->s13_bank_check;
$my_s13_as_in_how = $row->s13_as_in_how;
$my_s13_meid = $row->s13_meid;

if($my_s13_bank_check =="T"){$check1= "selected";}

//------------------업체명
?>

<script language="javascript">
<!--
function sendit() {

   if(!form.s13_bank_check.value) {
      alert('입금확인 유무를 선택하세요!');
      form.s13_bank_check.focus();
      return;
   }


           
   form.submit();
}

function IsNumber(formname) {
      var form = eval("document.form." + formname);

      for(var i = 0; i < form.value.length; i++) {
         var chr = form.value.substr(i,1);
         if(chr < '0' || chr > '9') {            
            return false;
         }
      }
      return true;   
   }
//-->
</script>

<table  width='95%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>

<form name='form' method='POST' action='modify1_process.php?page=<? echo("$page"); ?>&s13_as_in_how=<? echo("$my_s13_as_in_how"); ?>&s13_meid=<? echo("$my_s13_meid"); ?>' enctype='multipart/form-data'>
<INPUT type='hidden' name='number' value="<? echo"$number";?>">

<!-------------------------입고일  --------------------------->
		<tr>
			<td  width='30%' height='40' align='center' bgcolor='#fbfbfb'>
			<b>입금 확인</b>
			</td>
			<td width='70%'>
			&nbsp;&nbsp;

   <select name='s13_bank_check'>
   <option value=''>입금확인 유무를 선택하세요.
   <option value= 'T' <? echo"$check1";?>>입금확인
<!---   <option value= 'N'>미확인--->
   </select>

			</td>
		</tr>

</table>
<!---------------------------------------------------->
<table  width='95%' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td height='70' align='right' colspan='2'>
				<A href='javascript:sendit()'>
				<img src='<? echo("../$icon_dir/button_blue_write.gif");?>' border='0'></a>
				&nbsp;
				<a href='list.php'>
				<img src='<? echo("../$icon_dir/button_blue_cancel.gif");?>' border='0'></a>
			</td>
		</tr>
		</form>
</table>