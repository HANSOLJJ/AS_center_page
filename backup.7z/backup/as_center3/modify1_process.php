<?
include "../@config.php";
include "../@error_function.php";
include "../@access.php";

$query = "UPDATE $db13 SET s13_bank_check = '$s13_bank_check' WHERE s13_asid  = '$number'";

$result = mysql_query($query);

if (!$result) {      
   error("QUERY_ERROR");
   exit;
} else {

if($s13_as_in_how =="택배" OR $s13_as_in_how =="퀵"){
include"sms_center_key.php";
//echo"$remote_callback";
include"sms.php";
}

##### 회원가입이 성공적으로 되었을 때에 출력하는 페이지로 이동한다.
   echo ("<meta http-equiv='Refresh' content='0; URL=list.php?in_code=modify&number=$number'>");
} 

?>
