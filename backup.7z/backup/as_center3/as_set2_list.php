<?
##### 로그인을 거치지 않았을 경우 회원 로그인 화면으로 되돌려보낸다.
if($member_level == "")   {
   echo ("<meta http-equiv='Refresh' content='0; URL=../index.php'>");
   exit;
}
?>


<table  width='100%' cellpadding='0' cellspacing='0' border='1' align='center' valign='top'  bordercolor='#9EC8DE' bordercolordark='white' bordercolorlight='#9EC8DE'>
	<tr>
				<td  height='50' width='20%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>수탁방법</b></p>
				</td>
				<td  width='20%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>형태</b></p>
				</td>
				<td  width='30%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>주소</b></p>
				</td>
				<td  width='30%' background="<?echo "$border_bg1";?>">
				<p align='center'><b>연락처</b></p>
				</td>
			</tr>
			<tr>
				<td height='50'>
				<p align='center'><? echo"$my_s13_as_in_how";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_ex_sec1";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_ex_address";?></p>
				</td>
				<td>
				<p align='center'><? echo"$my_ex_tel";?></p>
				</td>
			</tr>
			<tr>
				<td colspan='20' colspan='10'>
				<? include"as_set2_add_list.php";?>
				</td>
			</tr>
		</table>

