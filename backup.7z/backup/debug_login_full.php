<?php
/**
 * AS System - Full Login Debug
 * 로그인 전체 프로세스 디버깅
 */

header('Content-Type: text/html; charset=utf-8');

// MySQL 호환성 레이어 먼저 로드
require_once 'mysql_compat.php';

echo "<h2>로그인 디버그</h2>";
echo "<pre>";

$id = 'raintrace';
$passwd = 'raintrace';

echo "1. 입력값\n";
echo "   - ID: $id (길이: " . strlen($id) . ")\n";
echo "   - PASSWORD: $passwd (길이: " . strlen($passwd) . ")\n";

// ID 형식 검증
echo "\n2. ID 형식 검증 (/^[a-zA-Z0-9]{5,10}$/)\n";
if (preg_match('/^[a-zA-Z0-9]{5,10}$/', $id)) {
    echo "   ✓ PASS\n";
} else {
    echo "   ✗ FAIL\n";
    exit;
}

// 비밀번호 형식 검증
echo "\n3. 비밀번호 형식 검증 (/^[a-zA-Z0-9]{4,16}$/)\n";
if (preg_match('/^[a-zA-Z0-9]{4,16}$/', $passwd)) {
    echo "   ✓ PASS\n";
} else {
    echo "   ✗ FAIL\n";
    exit;
}

// DB 연결
echo "\n4. DB 연결\n";
$connect = mysql_connect('mysql', 'mic4u_user', 'change_me');
if (!$connect) {
    echo "   ✗ FAIL\n";
    exit;
}
mysql_select_db('mic4u', $connect);
echo "   ✓ PASS\n";

// 쿼리 실행
echo "\n5. 관리자 쿼리\n";
$result = mysql_query("SELECT passwd, userlevel FROM 2010_admin_member WHERE id = '$id'");
if (!$result) {
    echo "   ✗ FAIL\n";
    exit;
}

$rows = mysql_num_rows($result);
echo "   ✓ PASS (조회 행: $rows)\n";

if ($rows === 0) {
    echo "   ✗ ID 없음\n";
    exit;
}

$row = mysql_fetch_object($result);
$db_passwd = $row->passwd;
$db_userlevel = $row->userlevel;

echo "   - 저장된 비밀번호: $db_passwd (길이: " . strlen($db_passwd) . ")\n";
echo "   - 레벨: $db_userlevel\n";

// PASSWORD 함수
echo "\n6. PASSWORD 함수\n";
$result = mysql_query("SELECT password('$passwd')");
$user_passwd = mysql_result($result, 0, 0);
echo "   - PASSWORD('$passwd'): $user_passwd (길이: " . strlen($user_passwd) . ")\n";

// 16자로 잘라내기
if (strlen($db_passwd) <= 16) {
    $user_passwd = substr($user_passwd, 0, 16);
    echo "   - 16자로 잘라낸 값: $user_passwd\n";
}

// 비밀번호 비교
echo "\n7. 비밀번호 비교\n";
echo "   - 저장된 값: '$db_passwd'\n";
echo "   - 입력한 값: '$user_passwd'\n";
echo "   - 완전 일치 (===): " . ($db_passwd === $user_passwd ? "YES" : "NO") . "\n";

if ($db_passwd === $user_passwd) {
    echo "\n✓ 로그인 성공!\n";
} else {
    echo "\n✗ 비밀번호 불일치\n";
}

echo "</pre>";

mysql_close();
?>
