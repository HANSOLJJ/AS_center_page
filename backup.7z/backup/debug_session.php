<?php
header('Content-Type: text/html; charset=utf-8');
require_once 'session.php';
require_once 'db.php';

echo "<h1>세션 디버그</h1>";
echo "<pre>";
echo "SESSION 내용:\n";
print_r($_SESSION);
echo "\n";
echo "is_logged_in(): " . (Session::is_logged_in() ? 'TRUE' : 'FALSE') . "\n";
echo "user_id: " . Session::get_user_id() . "\n";
echo "user_level: " . Session::get_user_level() . "\n";
echo "</pre>";

echo "<h2>테이블 존재 확인</h2>";
echo "<pre>";
$result = $db->query("SHOW TABLES LIKE 'step3_member'");
if ($db->num_rows() > 0) {
    echo "✓ step3_member 테이블 존재\n";
    $db->query("SELECT * FROM step3_member LIMIT 3");
    $rows = $db->fetch_all();
    echo "데이터: " . count($rows) . "개\n";
    foreach ($rows as $row) {
        echo "  - ID: " . $row['s3_mid'] . ", 레벨: " . $row['s3_level'] . "\n";
    }
} else {
    echo "✗ step3_member 테이블 없음\n";
}
echo "</pre>";

echo "<h2>로그인 테스트</h2>";
echo "<pre>";
$result = $db->query("SELECT * FROM step3_member WHERE s3_mid = 'admin' LIMIT 1");
$admin = $db->fetch_assoc();
if ($admin) {
    echo "✓ admin 계정 존재\n";
    echo "  - 이름: " . $admin['s3_name'] . "\n";
    echo "  - 레벨: " . $admin['s3_level'] . "\n";
    echo "  - 패스워드: " . $admin['s3_passwd'] . "\n";
    echo "  - MD5(admin123): " . md5('admin123') . "\n";
    echo "  - 일치: " . ($admin['s3_passwd'] === md5('admin123') ? '✓ YES' : '✗ NO') . "\n";
} else {
    echo "✗ admin 계정 없음\n";
}
echo "</pre>";
?>
