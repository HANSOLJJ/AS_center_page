<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

// MySQL 호환성 레이어 로드
require_once 'mysql_compat.php';

// 이미 로그인 상태면 dashboard로 리다이렉트
if (!empty($_SESSION['member_id']) && !empty($_SESSION['member_sid'])) {
    header('Location: dashboard.php');
    exit;
}

// POST로 로그인 요청이 오면
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_id = isset($_POST['login_id']) ? trim($_POST['login_id']) : '';
    $login_pass = isset($_POST['login_pass']) ? trim($_POST['login_pass']) : '';
    
    if ($login_id && $login_pass) {
        // 데이터베이스 연결
        $connect = @mysql_connect('mysql', 'mic4u_user', 'change_me');
        if ($connect) {
            @mysql_select_db('mic4u', $connect);
            
            // 관리자 정보 조회
            $query = "SELECT * FROM `2010_admin_member` WHERE `id` = '$login_id' AND `passwd` = '$login_pass' LIMIT 1";
            $result = @mysql_query($query);
            
            if ($result && mysql_num_rows($result) > 0) {
                $admin = mysql_fetch_assoc($result);
                
                // 세션 설정
                $_SESSION['member_id'] = $admin['id'];
                $_SESSION['member_sid'] = 'sid_' . time() . '_' . rand(1000, 9999);
                $_SESSION['member_level'] = $admin['level'] ?? '0';
                $_SESSION['user_name'] = $admin['name'] ?? $admin['id'];
                
                @mysql_close($connect);
                
                // dashboard로 리다이렉트
                header('Location: dashboard.php');
                exit;
            }
            
            @mysql_close($connect);
            $error_msg = '아이디 또는 비밀번호가 일치하지 않습니다.';
        } else {
            $error_msg = '데이터베이스 연결 오류';
        }
    }
}

// 테스트 계정으로 자동 로그인 (개발용)
// ?auto=1로 접속하면 첫 번째 관리자로 자동 로그인
if (isset($_GET['auto']) && $_GET['auto'] == '1') {
    $connect = @mysql_connect('mysql', 'mic4u_user', 'change_me');
    if ($connect) {
        @mysql_select_db('mic4u', $connect);
        
        $result = @mysql_query("SELECT * FROM `2010_admin_member` LIMIT 1");
        if ($result && mysql_num_rows($result) > 0) {
            $admin = mysql_fetch_assoc($result);
            
            $_SESSION['member_id'] = $admin['id'];
            $_SESSION['member_sid'] = 'sid_' . time() . '_' . rand(1000, 9999);
            $_SESSION['member_level'] = $admin['level'] ?? '0';
            $_SESSION['user_name'] = $admin['name'] ?? $admin['id'];
            
            @mysql_close($connect);
            header('Location: dashboard.php');
            exit;
        }
        @mysql_close($connect);
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AS 시스템 - 관리자 로그인</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header h1 {
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .login-header p {
            color: #999;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .login-button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .login-button:hover {
            background: #5568d3;
        }
        
        .error-message {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
        }
        
        .test-login {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .test-login a {
            display: inline-block;
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
            padding: 8px 16px;
            border: 1px solid #667eea;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .test-login a:hover {
            background: #667eea;
            color: white;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>AS 시스템</h1>
            <p>디지탈컴 After-Sales Center</p>
        </div>
        
        <?php if (isset($error_msg)): ?>
            <div class="error-message"><?php echo $error_msg; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="login_id">아이디</label>
                <input type="text" id="login_id" name="login_id" required autofocus>
            </div>
            
            <div class="form-group">
                <label for="login_pass">비밀번호</label>
                <input type="password" id="login_pass" name="login_pass" required>
            </div>
            
            <button type="submit" class="login-button">로그인</button>
        </form>
        
        <div class="test-login">
            <p style="font-size: 12px; color: #999; margin-bottom: 10px;">개발/테스트 모드</p>
            <a href="?auto=1">첫 관리자로 자동 로그인</a>
        </div>
    </div>
</body>
</html>
